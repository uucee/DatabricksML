# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Lecture — Fundamentals of Data Preparation and Feature Engineering
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This lecture covers the following four conceptual foundations that build on each other:
# MAGIC
# MAGIC - **A. The Data Preparation Workflow**. Where data prep sits in the ML lifecycle, the difference between cleaning and feature engineering
# MAGIC - **B. Feature Engineering and Feature Selection**. Transforming raw data into informative features and selectively removing noise
# MAGIC - **C. Splitting Data**. Train/validation/test splits, cross-validation, and avoiding data leakage
# MAGIC - **D. Sampling Methods**. Random, stratified, and cluster sampling in PySpark
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Describe where data preparation sits in the ML lifecycle and why it dominates project time
# MAGIC - Distinguish cleaning and formatting from feature engineering and feature selection
# MAGIC - Choose an appropriate train/validation/test split strategy and apply cross-validation
# MAGIC - Apply random, stratified, and cluster sampling in PySpark
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. The Data Preparation Workflow

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Where Data Prep Sits in the Machine Learning Lifecycle
# MAGIC
# MAGIC The Machine Learning lifecycle divides into two broad phases: **model development** and **production**.
# MAGIC * This module covers the "Data Preprocessing / Feature Engineering". 
# MAGIC * Module 1 covered data collection (loading data into Delta + UC). 
# MAGIC * Later modules will cover model training, evalution, deployment, and monitoring.
# MAGIC
# MAGIC Practitioners commonly report that **60–80% of project time** is spent on data preparation. Time invested here translates directly into model quality.
# MAGIC
# MAGIC <div style="max-width: 1000px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 800 525" role="img" style="font-family: sans-serif;">
# MAGIC   <title>The Machine Learning Lifecycle — Data Preparation Context</title>
# MAGIC   <desc>Two phases of the Machine Learning lifecycle. Model Development contains Business problem, Data collection, and Data prep / feature engineering in a top row, with Model training and Model evaluation in a bottom row connected by a downward then leftward arrow. An arrow exits Model evaluation rightward into the Production phase, which contains Model deployment, Model monitoring, and Model retrain in sequence.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="mlc-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC
# MAGIC   <!-- Top subgroup: Model Development — fill then dashed outline -->
# MAGIC   <rect x="30" y="52" width="700" height="250" rx="12" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <rect x="30" y="52" width="700" height="250" rx="12" fill="none" stroke="#2272B4" stroke-width="1.5" stroke-dasharray="6 3"/>
# MAGIC   <text x="50" y="200" font-size="13" font-weight="bold" fill="#0b2026">Model Development</text>
# MAGIC   <text x="50" y="215" font-size="11" fill="#618794">(static historical data)</text>
# MAGIC
# MAGIC   <!-- 1st step: Business problem -->
# MAGIC   <rect x="43" y="98" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="100" y="120" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Business</text>
# MAGIC   <text x="100" y="138" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Problem</text>
# MAGIC
# MAGIC   <!-- 2nd step:  Define success criteria -->
# MAGIC   <rect x="175" y="98" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="232" y="120" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Define Success</text>
# MAGIC   <text x="232" y="138" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Criteria</text>
# MAGIC
# MAGIC   <!-- 3rd step: Data collection -->
# MAGIC   <rect x="305" y="98" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="360" y="125" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Data Collection</text>
# MAGIC
# MAGIC   <!-- 4th step: Data prepprocessing / feature engineering (highlighted) -->
# MAGIC   <rect x="435" y="98" width="150" height="52" rx="8" fill="#2E8B57" fill-opacity="0.18" stroke="#2E8B57" stroke-width="1.5"/>
# MAGIC   <text x="510" y="120" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Data Preprocessing /</text>
# MAGIC   <text x="510" y="136" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Feature Engineering</text>
# MAGIC
# MAGIC   <!-- 5th step: Model training -->
# MAGIC   <rect x="605" y="98" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="662" y="130" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Model Training</text>
# MAGIC
# MAGIC   <!-- Arrow from Model Training to Model Evaluation -->
# MAGIC   <path d="M662 150 L662 200" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC   <!-- 6th step: Model evaluation -->
# MAGIC   <rect x="605" y="200" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="662" y="230" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Model Evaluation</text>
# MAGIC
# MAGIC   <!-- Top row arrows -->
# MAGIC   <path d="M158 124 L175 124" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC   <path d="M290 124 L305 124" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC   <path d="M420 124 L435 124" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC   <path d="M585 124 L605 124" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC <!-- Bottom subgroup: Deployment and Production — fill then dashed outline -->
# MAGIC   <rect x="30" y="310" width="700" height="200" rx="12" fill="#00A972" fill-opacity="0.07"/>
# MAGIC   <rect x="30" y="310" width="700" height="200" rx="12" fill="none" stroke="#00A972" stroke-width="1.5" stroke-dasharray="6 3"/>
# MAGIC   <text x="50" y="400"  font-size="13" font-weight="bold" fill="#0b2026">Deployment & Production</text>
# MAGIC   <text x="50" y="415"  font-size="11" fill="#618794">(continuously changing data)</text>
# MAGIC
# MAGIC   <!-- 7th step: Model deployment -->
# MAGIC   <rect x="440" y="350" width="117" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="500" y="380" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Model Deployment</text>
# MAGIC
# MAGIC   <!-- 8th step: Model Monitoring -->
# MAGIC   <rect x="305" y="350" width="115" height="52" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="360" y="380" text-anchor="middle" font-size="12" font-weight="bold" fill="#0b2026">Model Monitoring</text>
# MAGIC
# MAGIC   <!-- Arrow from Model Monitoring (top center) to Data Collection (bottom center) -->
# MAGIC   <path d="M362.5 350 L362.5 150" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC <!-- Bottom row arrows -->
# MAGIC   <path d="M440 375 L420 375" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC   <!-- Feedback: Model Evaluation → Data Preprocessing / Feature Engineering -->
# MAGIC   <path d="M 605 218 C 558 218 510 184 510 150" fill="none" stroke="#1B3139" stroke-width="1.8" stroke-dasharray="5 3" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC   <!-- Feedback: Model Evaluation → Data Collection -->
# MAGIC   <path d="M 605 234 C 555 274 362 274 362 150" fill="none" stroke="#1B3139" stroke-width="1.8" stroke-dasharray="5 3" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC   <!-- Forward: Model Evaluation → Model Deployment -->
# MAGIC   <path d="M 662 252 C 662 308 497 308 497 350" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#mlc-arrow)"/>
# MAGIC
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. The Machine Learning Full Lifecycle
# MAGIC
# MAGIC Building a model is only one stage in a larger workflow. The full lifecycle spans from defining the business problem through deployment and ongoing monitoring.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Stage</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Phase</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Description</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Business Problem</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #1565C0; font-weight: 600;">Development</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Define the business objective and frame it as a machine learning problem.</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Define Success Criteria</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #1565C0; font-weight: 600;">Development</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Establish measurable goals such as accuracy, latency, or revenue impact to determine whether the model meets business needs.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Data Collection &amp; Preprocessing</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #1565C0; font-weight: 600;">Development</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Gather, clean, and transform relevant data into features suitable for model training.</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Model Training</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #1565C0; font-weight: 600;">Development</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Train candidate models on historical data, iterating on algorithms and hyperparameters to optimize performance.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Model Evaluation</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #1565C0; font-weight: 600;">Development</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Assess model performance on held-out data and compare experiments to select the best candidate.</td>
# MAGIC     </tr>
# MAGIC     <tr>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Model Deployment</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #E65100; font-weight: 600;">Production</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Package and serve the selected model in a production environment to generate predictions on continuously arriving new data.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; font-weight: 600;">Model Monitoring</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0; color: #E65100; font-weight: 600;">Production</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #e0e0e0;">Track model performance on live data, detect drift or degradation, and feed insights back into retraining.</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A3. Data Preparation
# MAGIC
# MAGIC Data preparation encompasses two distinct categories of work. Understanding the difference helps you sequence your pipeline correctly.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Category</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Goal</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Typical Operations</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Cleaning &amp; formatting</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Make the data <em>correct and usable</em></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Fix data types, remove outliers, drop empty columns/rows, impute missing values, deduplicate</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Feature engineering</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Make the data <em>informative for the model</em></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Numerical transforms (log, normalize), aggregations, encoding categoricals, generating new features, embedding text/images</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The same dataset usually requires both — and the order matters. **Clean first**, then **engineer**, then **split**, and always **fit transformations on the training set only**.

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Feature Engineering and Feature Selection

# COMMAND ----------

# MAGIC %md
# MAGIC ### B1. Feature Engineering
# MAGIC
# MAGIC **Feature engineering** transforms raw data into a format that lets ML models extract patterns. The goal is not *more* features — it is *more informative* features.
# MAGIC
# MAGIC Common operations include:
# MAGIC
# MAGIC - **Numerical transforms** — log, standardize, bin
# MAGIC - **Encoding categoricals** — one-hot, label, target, embedding
# MAGIC - **Aggregations** — rolling means, group counts, recency
# MAGIC - **Derived features** — ratios, differences, interactions
# MAGIC - **Text / image / audio** — TF-IDF, embeddings, pretrained model outputs
# MAGIC
# MAGIC #### Feature Extraction
# MAGIC
# MAGIC A specialized case of feature engineering: derive a *smaller* set of features that better represent the underlying patterns. Examples include PCA, autoencoders, and learned embeddings.

# COMMAND ----------

# MAGIC %md
# MAGIC ### B2. Feature Selection: Dropping Columns and Rows
# MAGIC
# MAGIC Feature selection is the mirror of engineering — selectively *remove* features (columns) or instances (rows) to streamline the dataset and reduce noise.
# MAGIC
# MAGIC **Reasons to drop columns:**
# MAGIC - High percentage of missing values 
# MAGIC - Irrelevant or redundant features (high correlation with another column)
# MAGIC - Computational efficiency
# MAGIC
# MAGIC **Reasons to drop rows:**
# MAGIC - Too many missing fields per row
# MAGIC - Outliers that reflect data-quality issues, not signal

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Splitting Data

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. Why We Split
# MAGIC
# MAGIC A model cannot be evaluated on the same data it was trained on — it would memorize rather than generalize. Splitting the dataset solves four interconnected problems:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Need</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What Splitting Gives You</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Avoid overfitting</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A held-out test set the model never saw during training</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Hyperparameter tuning</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A validation set you can iterate on without leaking the test set</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Prevent data leakage</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Transformations fit on the training set only, then applied to validation/test</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Honest evaluation</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A final test score that estimates real-world performance</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. Train / Validation / Test
# MAGIC
# MAGIC The two most common split structures are shown below. The demos in this module use the simple 80/20 split.
# MAGIC
# MAGIC <!-- SVG illustrating simple and validation splits -->
# MAGIC <svg width="600" height="180" viewBox="0 0 552 140" xmlns="http://www.w3.org/2000/svg" aria-label="Simple split: Train and Test">
# MAGIC   <!-- Simple split -->
# MAGIC   <text x="10" y="24" font-size="18" font-family="sans-serif" font-weight="600" fill="#1B3139">Simple split:</text>
# MAGIC   <!-- 80% of 400px (train+test) = 320px, 20% = 80px, total = 400px, but scale to 552px width -->
# MAGIC   <rect x="20" y="40" width="352" height="44" rx="6" fill="#2272B4" stroke="#1B3139" stroke-width="2"/>
# MAGIC   <text x="150" y="65" font-size="16" font-family="sans-serif" font-weight="600" fill="#fff">Train 80%</text>
# MAGIC   <rect x="374" y="40" width="88" height="44" rx="6" fill="#2E8B57" stroke="#20734A" stroke-width="2"/>
# MAGIC   <text x="385" y="65" font-size="16" font-family="sans-serif" font-weight="600" fill="#fff">Test 20%</text>
# MAGIC </svg>
# MAGIC
# MAGIC Then, we validate and test the data as follows:
# MAGIC <svg width="600" height="180" viewBox="0 0 552 161" xmlns="http://www.w3.org/2000/svg" aria-label="Split with validation set: Train, Validation, and Test">
# MAGIC   <!-- Validation split -->
# MAGIC   <text x="10" y="100" font-size="18" font-family="sans-serif" font-weight="600" fill="#1B3139">With validation set:</text>
# MAGIC   <rect x="20" y="112" width="264" height="44" rx="6" fill="#2272B4" stroke="#1B3139" stroke-width="2"/>
# MAGIC   <text x="130" y="138" font-size="16" font-family="sans-serif" font-weight="600" fill="#fff">Train 60%</text>
# MAGIC   <rect x="284" y="112" width="88" height="44" rx="6" fill="#FFD700" stroke="#B8860B" stroke-width="2"/>
# MAGIC   <text x="287" y="138" font-size="13" font-family="sans-serif" font-weight="600" fill="#1B3139">Validate 20%</text>
# MAGIC   <rect x="374" y="112" width="88" height="44" rx="6" fill="#2E8B57" stroke="#20734A" stroke-width="2"/>
# MAGIC   <text x="385" y="138" font-size="16" font-family="sans-serif" font-weight="600" fill="#fff">Test 20%</text>
# MAGIC </svg>
# MAGIC
# MAGIC In PySpark, use `randomSplit` to divide a DataFrame into proportional subsets. The `seed` parameter ensures reproducibility across runs.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C3. Train / Test Example
# MAGIC
# MAGIC #### Creating a Synthetic DataFrame
# MAGIC
# MAGIC The following code creates a small synthetic dataset for demonstration purposes.  
# MAGIC `raw_df` is a Spark DataFrame with 1,000 rows, each containing:
# MAGIC
# MAGIC </br>
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>from pyspark.sql import Row</code>
# MAGIC <code>raw_df = spark.createDataFrame([
# MAGIC     Row(id=i, x=float(i), label=i % 2) for i in range(1000)
# MAGIC ])</code></pre>
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC - **id**: a unique integer identifier
# MAGIC - **x**: a float version of the id
# MAGIC - **label**: a binary class (0 or 1), alternating by row
# MAGIC
# MAGIC #### Splitting the Data
# MAGIC
# MAGIC `randomSplit` divides `raw_df` into two subsets:
# MAGIC
# MAGIC - **train_df**: 80% of the data, used for model training
# MAGIC - **test_df**: 20% of the data, held out for evaluation
# MAGIC
# MAGIC The `seed` parameter ensures reproducibility.
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>train_df, test_df = raw_df.randomSplit([0.8, 0.2], seed=42)
# MAGIC print(f"train: {train_df.count():,}   test: {test_df.count():,}")</code></pre>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C4. Cross-Validation
# MAGIC
# MAGIC When the dataset is small, a single train/validation split produces noisy estimates. **Cross-validation** rotates which fold serves as the validation set so that every row is evaluated exactly once.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Strategy</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">When to Use</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">K-Fold</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Default for tabular data</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Stratified K-Fold</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Imbalanced classification — preserves class ratio per fold</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Shuffle Split</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">When you want repeated random splits with a fixed test size</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Nested CV</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">When you tune hyperparameters <em>and</em> report generalization — outer loop for evaluation, inner loop for tuning</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC In Spark ML, use `pyspark.ml.tuning.CrossValidator` (or `TrainValidationSplit` for a single split). You will see this applied in a later module.

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Sampling Methods

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. Three Core Sampling Methods
# MAGIC
# MAGIC Sampling is used when working with a representative subset of a large dataset — for exploration, prototyping, or class balancing. The three core methods and their PySpark implementations are summarized below.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 900px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Method</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">When to Use</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">PySpark API</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Random</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Default; every row is equally likely to be selected</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code style="background: #F0F0F0; padding: 2px 6px; border-radius: 3px;">df.sample(withReplacement=False, fraction=0.05, seed=42)</code></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Stratified</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Imbalanced classes; preserve the class ratio in the sample</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code style="background: #F0F0F0; padding: 2px 6px; border-radius: 3px;">df.sampleBy(col, fractions={...}, seed=42)</code></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Cluster</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Natural groups (stores, regions); sample whole groups rather than individual rows</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Filter by group ID, then randomly select groups</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The following cells demonstrate each method on a synthetic dataset.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### D2. Random Sampling
# MAGIC
# MAGIC Random sampling is the most common and basic sampling technique in machine learning. It randomly selects data points from a dataset without following any specific pattern, assuming that each data point has an equal probability of being chosen.
# MAGIC
# MAGIC <br>
# MAGIC
# MAGIC <!-- SVG: Random sampling from rows -->
# MAGIC <svg width="400" height="200" viewBox="0 0 340 120" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <!-- Four rows of people, each row has 4 different colors -->
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="20" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="70" cy="20" r="12" fill="#FF3621"/>
# MAGIC     <circle cx="110" cy="20" r="12" fill="#00A972"/>
# MAGIC     <circle cx="150" cy="20" r="12" fill="#F9B233"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="50" r="12" fill="#FF3621"/>
# MAGIC     <circle cx="70" cy="50" r="12" fill="#00A972"/>
# MAGIC     <circle cx="110" cy="50" r="12" fill="#F9B233"/>
# MAGIC     <circle cx="150" cy="50" r="12" fill="#2272B4"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="80" r="12" fill="#00A972"/>
# MAGIC     <circle cx="70" cy="80" r="12" fill="#F9B233"/>
# MAGIC     <circle cx="110" cy="80" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="150" cy="80" r="12" fill="#FF3621"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="110" r="12" fill="#F9B233"/>
# MAGIC     <circle cx="70" cy="110" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="110" cy="110" r="12" fill="#FF3621"/>
# MAGIC     <circle cx="150" cy="110" r="12" fill="#00A972"/>
# MAGIC   </g>
# MAGIC   <!-- Horizontal arrow -->
# MAGIC   <defs>
# MAGIC     <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
# MAGIC       <polygon points="0,0 8,4 0,8" fill="#1B3139"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="190" y1="20" x2="280" y2="20" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="50" x2="280" y2="50" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="80" x2="280" y2="80" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="110" x2="280" y2="110" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <!-- Selected person (on right of arrow), color matches one from each row -->
# MAGIC   <circle cx="300" cy="20" r="12" fill="#00A972" stroke="#006B49" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="50" r="12" fill="#F9B233" stroke="#B88C1D" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="80" r="12" fill="#FF3621" stroke="#CC2A1A" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="110" r="12" fill="#2272B4" stroke="#1B3139" stroke-width="2"/>
# MAGIC   <!-- Sampled label -->
# MAGIC   <text x="200" y="8" font-size="13" fill="#1B3139">Sampling</text>
# MAGIC </svg>
# MAGIC
# MAGIC <br>
# MAGIC
# MAGIC An example of random sampling of 5% of the data. 
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code># Random sample — 50 data points from a pandas DataFrame
# MAGIC my_random_sample = my_data.sample(n=50, random_state=42)
# MAGIC print(f"Random sample: {len(my_random_sample):,} rows")</code>
# MAGIC </pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### D3. Stratified Sampling 
# MAGIC
# MAGIC
# MAGIC Stratified sampling is used when a dataset consists of subgroups, ensuring that samples are taken from each. The population is divided into homogeneous subgroups, known as strata, and an appropriate number of instances is selected from each stratum to ensure the sample accurately represents the entire population.
# MAGIC
# MAGIC <br>
# MAGIC
# MAGIC <!-- SVG: Random sampling from rows -->
# MAGIC <svg width="400" height="200" viewBox="0 0 340 120" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <!-- Four rows of people, each row has 4 different colors -->
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="20" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="70" cy="20" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="110" cy="20" r="12" fill="#FF3621"/>
# MAGIC     <circle cx="150" cy="20" r="12" fill="#FF3621"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="50" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="70" cy="50" r="12" fill="#2272B4"/>
# MAGIC     <circle cx="110" cy="50" r="12" fill="#FF3621"/>
# MAGIC     <circle cx="150" cy="50" r="12" fill="#FF3621"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="80" r="12" fill="#00A972"/>
# MAGIC     <circle cx="70" cy="80" r="12" fill="#00A972"/>
# MAGIC     <circle cx="110" cy="80" r="12" fill="#F9B233"/>
# MAGIC     <circle cx="150" cy="80" r="12" fill="#F9B233"/>
# MAGIC   </g>
# MAGIC   <g>
# MAGIC     <circle cx="30" cy="110" r="12" fill="#00A972"/>
# MAGIC     <circle cx="70" cy="110" r="12" fill="#00A972"/>
# MAGIC     <circle cx="110" cy="110" r="12" fill="#F9B233"/>
# MAGIC     <circle cx="150" cy="110" r="12" fill="#F9B233"/>
# MAGIC   </g>
# MAGIC   <!-- Horizontal arrow -->
# MAGIC   <defs>
# MAGIC     <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
# MAGIC       <polygon points="0,0 8,4 0,8" fill="#1B3139"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="190" y1="20" x2="280" y2="20" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="50" x2="280" y2="50" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="80" x2="280" y2="80" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="190" y1="110" x2="280" y2="110" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <!-- Selected person (on right of arrow), color matches one from each row -->
# MAGIC   <circle cx="300" cy="20" r="12" fill="#2272B4" stroke="#1B3139" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="50" r="12" fill="#FF3621" stroke="#CC2A1A" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="80" r="12" fill="#00A972" stroke="#006B49" stroke-width="2"/>
# MAGIC   <circle cx="300" cy="110" r="12" fill="#F9B233" stroke="#B88C1D" stroke-width="2"/>
# MAGIC   <!-- Sampled label -->
# MAGIC   <text x="200" y="8" font-size="13" fill="#1B3139">Sampling</text>
# MAGIC </svg>
# MAGIC
# MAGIC An example of stratified sampling of the data. 
# MAGIC
# MAGIC - Stratified sample by subgroup — using pandas and scikit-learn
# MAGIC - `my_data` is a pandas DataFrame
# MAGIC - `group_label` is the column containing subgroups
# MAGIC
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>from sklearn.model_selection import train_test_split</code>
# MAGIC </br>
# MAGIC <code>stratified_train, stratified_test = train_test_split(
# MAGIC     my_data, test_size=0.2, stratify=my_data['group_label'], random_state=42
# MAGIC )</code>
# MAGIC <code>stratified_test['group_label'].value_counts()</code>
# MAGIC </pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### D4. Cluster Sampling 
# MAGIC
# MAGIC Cluster sampling is a sampling technique where the population is divided into naturally occurring groups, or clusters, and a subset of these clusters is randomly selected for study. Instead of sampling individuals directly, researchers collect data from all individuals within the chosen clusters. 
# MAGIC
# MAGIC <!-- SVG: Cluster sampling illustration -->
# MAGIC <svg width="600" height="260" viewBox="0 0 600 260" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <!-- Large circle (population) -->
# MAGIC   <circle cx="120" cy="120" r="80" fill="#F9F7F4" stroke="#2272B4" stroke-width="3"/>
# MAGIC   <text x="85" y="30" font-size="16" fill="#2272B4" font-weight="bold">Population</text>
# MAGIC   <!-- 30 dots in large circle: 10 blue, 10 orange, 10 green -->
# MAGIC   <!-- Blue dots -->
# MAGIC   <circle cx="90" cy="70" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="110" cy="65" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="130" cy="75" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="80" cy="100" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="100" cy="110" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="120" cy="100" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="140" cy="90" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="100" cy="140" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="120" cy="130" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="140" cy="120" r="5" fill="#2272B4"/>
# MAGIC   <!-- Orange dots -->
# MAGIC   <circle cx="160" cy="70" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="170" cy="100" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="150" cy="110" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="170" cy="130" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="160" cy="150" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="140" cy="150" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="120" cy="160" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="100" cy="170" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="80" cy="150" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="90" cy="170" r="5" fill="#FF3621"/>
# MAGIC   <!-- Green dots -->
# MAGIC   <circle cx="70" cy="120" r="5" fill="#00A972"/>
# MAGIC   <circle cx="80" cy="130" r="5" fill="#00A972"/>
# MAGIC   <circle cx="110" cy="150" r="5" fill="#00A972"/>
# MAGIC   <circle cx="130" cy="170" r="5" fill="#00A972"/>
# MAGIC   <circle cx="150" cy="170" r="5" fill="#00A972"/>
# MAGIC   <circle cx="170" cy="150" r="5" fill="#00A972"/>
# MAGIC   <circle cx="170" cy="80" r="5" fill="#00A972"/>
# MAGIC   <circle cx="150" cy="80" r="5" fill="#00A972"/>
# MAGIC   <circle cx="130" cy="60" r="5" fill="#00A972"/>
# MAGIC   <circle cx="110" cy="80" r="5" fill="#00A972"/>
# MAGIC   <!-- Arrow to clusters -->
# MAGIC   <defs>
# MAGIC     <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto">
# MAGIC       <polygon points="0,0 8,4 0,8" fill="#1B3139"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="200" y1="120" x2="320" y2="60" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="200" y1="120" x2="320" y2="120" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <line x1="200" y1="120" x2="320" y2="180" stroke="#1B3139" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <!-- Cluster 1: blue dots -->
# MAGIC   <text x="400" y="65" font-size="13" fill="#2272B4"font-weight="bold" >Cluster 1</text>
# MAGIC   <circle cx="360" cy="60" r="30" fill="#F9F7F4" stroke="#2272B4" stroke-width="2"/>
# MAGIC   <circle cx="350" cy="50" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="370" cy="50" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="360" cy="40" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="360" cy="60" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="350" cy="70" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="370" cy="70" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="340" cy="60" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="380" cy="60" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="355" cy="80" r="5" fill="#2272B4"/>
# MAGIC   <circle cx="365" cy="80" r="5" fill="#2272B4"/>
# MAGIC   <!-- Cluster 2: orange dots -->
# MAGIC   <text x="400" y="125" font-size="13" fill="#FF3621"font-weight="bold" >Cluster 2</text>
# MAGIC   <circle cx="360" cy="120" r="30" fill="#F9F7F4" stroke="#FF3621" stroke-width="2"/>
# MAGIC   <circle cx="350" cy="110" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="370" cy="110" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="360" cy="100" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="360" cy="120" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="350" cy="130" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="370" cy="130" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="340" cy="120" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="380" cy="120" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="355" cy="140" r="5" fill="#FF3621"/>
# MAGIC   <circle cx="365" cy="140" r="5" fill="#FF3621"/>
# MAGIC   <!-- Cluster 3: green dots -->
# MAGIC   <text x="400" y="185" font-size="13" fill="#00A972"font-weight="bold" >Cluster 3</text>
# MAGIC   <circle cx="360" cy="180" r="30" fill="#F9F7F4" stroke="#00A972" stroke-width="2"/>
# MAGIC   <circle cx="350" cy="170" r="5" fill="#00A972"/>
# MAGIC   <circle cx="370" cy="170" r="5" fill="#00A972"/>
# MAGIC   <circle cx="360" cy="160" r="5" fill="#00A972"/>
# MAGIC   <circle cx="360" cy="180" r="5" fill="#00A972"/>
# MAGIC   <circle cx="350" cy="190" r="5" fill="#00A972"/>
# MAGIC   <circle cx="370" cy="190" r="5" fill="#00A972"/>
# MAGIC   <circle cx="340" cy="180" r="5" fill="#00A972"/>
# MAGIC   <circle cx="380" cy="180" r="5" fill="#00A972"/>
# MAGIC   <circle cx="355" cy="200" r="5" fill="#00A972"/>
# MAGIC   <circle cx="365" cy="200" r="5" fill="#00A972"/>
# MAGIC </svg>
# MAGIC
# MAGIC
# MAGIC </br>
# MAGIC Cluster sampling example: Sample whole groups, not individual rows.
# MAGIC
# MAGIC - `my_data` is a pandas DataFrame
# MAGIC - `my_col` is the column containing subgroup identifiers
# MAGIC -  Randomly select M clusters from the `range 1 to N`
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>import numpy as np</code>
# MAGIC </br>
# MAGIC <code>clusters = np.random.choice(np.arange(1, N+1), size=M, replace=False)</code>
# MAGIC <code>cluster_sample = my_data[my_data['my_col'].isin(clusters)]</code>
# MAGIC </pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the conceptual foundations that underpin every demo and lab in this module:
# MAGIC
# MAGIC 1. **The Data Preparation Workflow** — data preparation (cleaning, engineering, and splitting) typically accounts for 60–80% of total project time and directly determines model quality.
# MAGIC 2. **Feature Engineering and Selection** — cleaning (making data correct and usable) must precede feature engineering (making data informative); selectively removing noisy features reduces overfitting.
# MAGIC 3. **Splitting Data** — transformations must be fit on the training set only, then applied to validation and test sets to prevent data leakage; cross-validation provides more reliable estimates when dataset size is limited.
# MAGIC 4. **Sampling Methods** — PySpark provides `randomSplit`, `sample`, and `sampleBy` for splitting and sampling at scale.
# MAGIC
# MAGIC Together, these concepts form the foundation for robust, reproducible data preparation pipelines on Databricks — making it straightforward to clean, transform, split, and sample data before model training.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>