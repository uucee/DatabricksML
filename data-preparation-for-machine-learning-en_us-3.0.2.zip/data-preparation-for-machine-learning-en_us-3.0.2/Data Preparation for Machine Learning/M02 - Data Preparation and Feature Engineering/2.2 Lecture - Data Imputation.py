# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Lecture — Data Imputation
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC
# MAGIC This lecture covers the following four sections that build on each other:
# MAGIC
# MAGIC - **A. Why Missing Data Matters for Machine Learning**. What data imputation is, how missing values degrade model performance, and why the handling strategy matters
# MAGIC - **B. How to Handle Missing Data**. The three top-level strategies: dropping, treating as a category, and replacing with an estimated value
# MAGIC - **C. Replacement Methods in Practice**. Mean/median/mode, K-nearest neighbors, and regression imputation with worked examples
# MAGIC - **D. Best Practices**. Choosing the right method based on data characteristics, and marking imputed values for traceability
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Explain how missing data degrades model performance through reduced accuracy, biased inferences, and imbalanced representations
# MAGIC - Choose between dropping, encoding-as-category, and replacing missing values based on data type and missingness pattern
# MAGIC - Apply mean/median/mode, KNN, and regression imputation appropriately depending on distribution, outliers, and amount missing
# MAGIC - Mark imputed rows with indicator columns to maintain transparency and traceability in ML pipelines
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Why Missing Data Matters for Machine Learning

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### A1. What Is Data Imputation?
# MAGIC
# MAGIC **Data imputation** is the process of filling in missing values with estimated or predicted values. 
# MAGIC
# MAGIC
# MAGIC <div style="display: flex; flex-direction: column; gap: 24px; align-items: center; margin-top: 16px;">
# MAGIC   <!-- Panel 1: Before Imputation -->
# MAGIC   <div style="width: 500px;">
# MAGIC     <svg width="100%" height="300" viewBox="0 0 420 260" style="background: #F9F7F4; border-radius: 12px;">
# MAGIC       <!-- Panel label -->
# MAGIC       <text x="210" y="28" text-anchor="middle" font-size="18" font-weight="700" fill="#2272B4">Before Imputation</text>
# MAGIC       <!-- Axis lines -->
# MAGIC       <line x1="50" y1="210" x2="370" y2="210" stroke="#B0BEC5" stroke-width="2"/>
# MAGIC       <line x1="50" y1="60" x2="50" y2="210" stroke="#B0BEC5" stroke-width="2"/>
# MAGIC       <!-- X-axis label -->
# MAGIC       <text x="210" y="240" text-anchor="middle" font-size="14" fill="#618794">Annual Income (USD)</text>
# MAGIC       <!-- Histogram bars (bell shape, with gap) -->
# MAGIC       <rect x="70" y="170" width="24" height="40" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="100" y="140" width="24" height="70" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="130" y="110" width="24" height="100" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="160" y="80" width="24" height="130" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="190" y="65" width="24" height="145" fill="#90CAF9" rx="4"/>
# MAGIC       <!-- GAP: missing data -->
# MAGIC       <rect x="220" y="210" width="24" height="0" fill="#FF5F46" rx="4" stroke="#FF5F46" stroke-width="2" stroke-dasharray="4,2"/>
# MAGIC       <text x="232" y="195" text-anchor="middle" font-size="12" fill="#FF5F46" font-weight="600" opacity="0.8">Gap</text>
# MAGIC       <rect x="250" y="80" width="24" height="130" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="280" y="110" width="24" height="100" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="310" y="140" width="24" height="70" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="340" y="170" width="24" height="40" fill="#90CAF9" rx="4"/>
# MAGIC       <!-- KDE curve (smooth bell) -->
# MAGIC       <path d="M70 190 Q120 80 190 60 Q260 80 340 190" fill="none" stroke="#2272B4" stroke-width="3" stroke-linecap="round"/>
# MAGIC       <text x="360" y="50" font-size="12" fill="#2272B4" font-weight="600" opacity="0.8">KDE</text>
# MAGIC     </svg>
# MAGIC   </div>
# MAGIC   <!-- Panel 2: After Mean Imputation -->
# MAGIC   <div style="width: 500px;">
# MAGIC     <svg width="100%" height="300" viewBox="0 0 420 260" style="background: #F9F7F4; border-radius: 12px;">
# MAGIC       <!-- Panel label -->
# MAGIC       <text x="210" y="28" text-anchor="middle" font-size="18" font-weight="700" fill="#2272B4">After Mean Imputation</text>
# MAGIC       <!-- Axis lines -->
# MAGIC       <line x1="50" y1="210" x2="370" y2="210" stroke="#B0BEC5" stroke-width="2"/>
# MAGIC       <line x1="50" y1="60" x2="50" y2="210" stroke="#B0BEC5" stroke-width="2"/>
# MAGIC       <!-- X-axis label -->
# MAGIC       <text x="210" y="240" text-anchor="middle" font-size="14" fill="#618794">Annual Income (USD)</text>
# MAGIC       <!-- Histogram bars (bell shape, gap filled) -->
# MAGIC       <rect x="70" y="170" width="24" height="40" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="100" y="140" width="24" height="70" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="130" y="110" width="24" height="100" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="160" y="80" width="24" height="130" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="190" y="65" width="24" height="145" fill="#90CAF9" rx="4"/>
# MAGIC       <!-- Imputed mean bar (highlighted) -->
# MAGIC       <rect x="220" y="90" width="24" height="120" fill="#FF5F46" rx="4" stroke="#FF5F46" stroke-width="2"/>
# MAGIC       <text x="232" y="85" text-anchor="middle" font-size="12" fill="#FF5F46" font-weight="700">$55,500</text>
# MAGIC       <rect x="250" y="80" width="24" height="130" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="280" y="110" width="24" height="100" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="310" y="140" width="24" height="70" fill="#90CAF9" rx="4"/>
# MAGIC       <rect x="340" y="170" width="24" height="40" fill="#90CAF9" rx="4"/>
# MAGIC       <!-- KDE curve (smooth bell) -->
# MAGIC       <path d="M70 190 Q120 80 190 60 Q260 80 340 190" fill="none" stroke="#2272B4" stroke-width="3" stroke-linecap="round"/>
# MAGIC       <text x="360" y="50" font-size="12" fill="#2272B4" font-weight="600" opacity="0.8">KDE</text>
# MAGIC       <!-- Imputed mean marker -->
# MAGIC       <circle cx="232" cy="150" r="8" fill="#FF5F46" stroke="#2272B4" stroke-width="2"/>
# MAGIC       <!-- <text x="232" y="170" text-anchor="middle" font-size="12" fill="#FF5F46" font-weight="600">Mean</text> -->
# MAGIC     </svg>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Problems Caused by Missing Data
# MAGIC
# MAGIC The right strategy depends on **why** the data is missing (random vs. systematic) and **how much** is missing. 
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Problem</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Why It Hurts the Model</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Reduced performance</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Many algorithms (e.g., gradient-based) cannot accept nulls at all</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Biased inferences</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">If "missing" correlates with the target (e.g., wealthy customers skip income surveys), dropping rows skews the model</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Imbalanced representations</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Subgroups with more missing data become underrepresented</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Complexity in handling</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Each ML library and pipeline stage needs its own missing-value strategy</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## B. How to Handle Missing Data
# MAGIC
# MAGIC There are three top-level strategies on how to handle missing data. Most projects use a mix.
# MAGIC
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1100px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .ds-row { display: flex; gap: 24px; align-items: stretch; flex-wrap: wrap; }
# MAGIC .ds-row > * { flex: 1; min-width: 240px; }
# MAGIC .ds-card { background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); padding: 20px; border-top: 8px solid var(--accent, #4299E0); }
# MAGIC .blue{--accent:#4299E0;} .green{--accent:#00A972;} .coral{--accent:#FF5F46;} .amber{--accent:#FFAB00;} .red{--accent:#98102A;}
# MAGIC .ds-card-title { font-size: 14pt; font-weight: 700; line-height: 1.25; margin: 0 0 8px; }
# MAGIC .ds-card-text { font-size: 12pt; color: #5E7077; line-height: 1.55; margin: 0; }
# MAGIC .ds-card ul, .ds-card ol { margin: 8px 0 0; padding-left: 20px; font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-card li { margin-bottom: 10px; }
# MAGIC .ds-card li:last-child { margin-bottom: 0; }
# MAGIC .tc { text-align: center; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="tc" style="margin-bottom: 18px;">
# MAGIC   <span style="font-size: 18pt; font-weight: 700; color: #FF5F46;">Missing Data Strategies</span>
# MAGIC </div>
# MAGIC <div class="ds-row">
# MAGIC   <div class="ds-card blue">
# MAGIC     <div class="ds-card-title">1. Drop Rows / Columns</div>
# MAGIC     <ul>
# MAGIC       <li>Row-wise (most fields missing)</li>
# MAGIC       <li>Column-wise (&gt; 60% missing)</li>
# MAGIC       <li>Risk: bias if not random</li>
# MAGIC     </ul>
# MAGIC   </div>
# MAGIC   <div class="ds-card green">
# MAGIC     <div class="ds-card-title">2. Treat as a Category</div>
# MAGIC     <ul>
# MAGIC       <li>Encode "missing" as own value</li>
# MAGIC       <li>Fill with "No" / known default</li>
# MAGIC       <li>Best for categorical columns</li>
# MAGIC     </ul>
# MAGIC   </div>
# MAGIC   <div class="ds-card coral">
# MAGIC     <div class="ds-card-title">3. Replace (Impute)</div>
# MAGIC     <ul>
# MAGIC       <li>Mean / Median / Mode</li>
# MAGIC       <li>K-Nearest Neighbors</li>
# MAGIC       <li>Regression / Default value</li>
# MAGIC     </ul>
# MAGIC   </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Drop Columns or Rows
# MAGIC
# MAGIC Use when there is too little signal to be worth recovering:
# MAGIC
# MAGIC - **Drop a column** if it is missing in most rows
# MAGIC - **Drop a row** if most of its fields are missing
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #1B5162; background: #F8F9FC; padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#1B5162; margin-bottom:6px; font-size:15pt;">Note</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     Dropping rows or columns with missing data can introduce bias if the missingness is not random. Always consider whether the missing values share meaningful characteristics—removing them may skew your model and reduce its ability to generalize.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B2. Treat as a Category
# MAGIC
# MAGIC For **categorical** columns, "missing" can be meaningful — for example, a customer who did not select a payment method or skipped a survey question.
# MAGIC
# MAGIC A common approach is to encode missing values as a separate category, such as `"Unknown"` or `"Missing"`. This preserves information and allows models to learn from missingness.
# MAGIC
# MAGIC <div style="max-width: 330px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 250 320" style="font-family: sans-serif;">
# MAGIC   <!-- Before rectangle -->
# MAGIC   <rect x="30" y="30" width="180" height="70" rx="10" fill="#F9F7F4" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="110" y="50" text-anchor="middle" font-size="14" font-weight="700" fill="#2272B4">Before</text>
# MAGIC   <text x="110" y="70" text-anchor="middle" font-size="12" fill="#0b2026">PaymentMethod:</text>
# MAGIC   <text x="110" y="90" text-anchor="middle" font-size="12" fill="#618794">"Credit", "Debit", <tspan fill="#FF5F46">null</tspan></text>
# MAGIC
# MAGIC   <!-- Arrow -->
# MAGIC   <defs>
# MAGIC     <marker id="arrowhead" markerWidth="8" markerHeight="8" refX="6" refY="4" orient="auto">
# MAGIC       <polygon points="0,0 8,4 0,8" fill="#2272B4"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="110" y1="100" x2="110" y2="150" stroke="#2272B4" stroke-width="2" marker-end="url(#arrowhead)"/>
# MAGIC   <text x="175" y="125" text-anchor="middle" font-size="11" fill="#2272B4">Categorical Encoding</text>
# MAGIC
# MAGIC   <!-- After rectangle -->
# MAGIC   <rect x="30" y="160" width="180" height="70" rx="10" fill="#F9F7F4" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="110" y="180" text-anchor="middle" font-size="14" font-weight="700" fill="#2272B4">After</text>
# MAGIC   <text x="110" y="200" text-anchor="middle" font-size="12" fill="#0b2026">PaymentMethod:</text>
# MAGIC   <text x="110" y="220" text-anchor="middle" font-size="12" fill="#618794">"Credit", "Debit", <tspan fill="#FF5F46">"Missing"</tspan></text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### B3. Replace with an Estimated Value (Impute)
# MAGIC
# MAGIC For **numerical** columns, dropping is often too aggressive, and a simple category label doesn't capture the underlying value — so we estimate a replacement.

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Replacement Methods in Practice

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### C1. Mean / Median / Mode
# MAGIC
# MAGIC The simplest method: replace each missing value with a summary statistic computed from the same column.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Statistic</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Use For</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Notes</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Mean</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Numeric, roughly normal distribution</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Sensitive to outliers; reduces variance and can weaken correlations</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Median</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Numeric, skewed or with outliers</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Robust to outliers; also reduces variance and can weaken correlations</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Mode</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Categorical</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Most common value; can overinflate the majority class</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The diagram below illustrates mean imputation — lines show how each observed value contributes to the imputed result:
# MAGIC
# MAGIC <div style="max-width: 480px; margin: 16px 0;">
# MAGIC <svg width="100%" viewBox="0 0 480 320" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>Mean Imputation Visualization</title>
# MAGIC   <desc>Values 10, 15, 20, 25 contribute to the imputed mean of 17.5</desc>
# MAGIC
# MAGIC   <defs>
# MAGIC     <marker id="mean-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#FF3621" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Header bar -->
# MAGIC   <rect x="20" y="10" width="440" height="36" rx="4" fill="#1B3139"/>
# MAGIC   <line x1="20" y1="46" x2="460" y2="46" stroke="#FF3621" stroke-width="3"/>
# MAGIC   <text x="80" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">ID</text>
# MAGIC   <text x="200" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">Before</text>
# MAGIC   <text x="400" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">After (mean)</text>
# MAGIC
# MAGIC   <!-- Row 1: ID=1, value=10 -->
# MAGIC   <rect x="20" y="50" width="440" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="94" x2="460" y2="94" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="80" y="76" text-anchor="middle" font-size="13" fill="#1B3139">1</text>
# MAGIC   <text x="200" y="76" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">10</text>
# MAGIC   <text x="400" y="76" text-anchor="middle" font-size="13" fill="#1B3139">10.0</text>
# MAGIC
# MAGIC   <!-- Row 2: ID=2, value=15 -->
# MAGIC   <rect x="20" y="94" width="440" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="138" x2="460" y2="138" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="80" y="120" text-anchor="middle" font-size="13" fill="#1B3139">2</text>
# MAGIC   <text x="200" y="120" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">15</text>
# MAGIC   <text x="400" y="120" text-anchor="middle" font-size="13" fill="#1B3139">15.0</text>
# MAGIC
# MAGIC   <!-- Row 3: ID=3, missing → 17.5 -->
# MAGIC   <rect x="20" y="138" width="440" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="182" x2="460" y2="182" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="80" y="164" text-anchor="middle" font-size="13" fill="#1B3139">3</text>
# MAGIC   <text x="200" y="164" text-anchor="middle" font-size="13" fill="#618794">—</text>
# MAGIC   <!-- Highlighted imputed value -->
# MAGIC   <rect x="360" y="148" width="80" height="28" rx="4" fill="#FF3621" fill-opacity="0.1" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="400" y="166" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">17.5</text>
# MAGIC
# MAGIC   <!-- Row 4: ID=4, value=20 -->
# MAGIC   <rect x="20" y="182" width="440" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="226" x2="460" y2="226" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="80" y="208" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="200" y="208" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">20</text>
# MAGIC   <text x="400" y="208" text-anchor="middle" font-size="13" fill="#1B3139">20.0</text>
# MAGIC
# MAGIC   <!-- Row 5: ID=5, value=25 -->
# MAGIC   <rect x="20" y="226" width="440" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="270" x2="460" y2="270" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="80" y="252" text-anchor="middle" font-size="13" fill="#1B3139">5</text>
# MAGIC   <text x="200" y="252" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">25</text>
# MAGIC   <text x="400" y="252" text-anchor="middle" font-size="13" fill="#1B3139">25.0</text>
# MAGIC
# MAGIC   <!-- Arrows from each source value to the imputed 17.5 -->
# MAGIC   <path d="M220 76 C280 76, 340 130, 360 160" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#mean-arrow)"/>
# MAGIC   <path d="M220 120 C270 120, 320 140, 360 158" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#mean-arrow)"/>
# MAGIC   <path d="M220 208 C270 208, 320 188, 360 168" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#mean-arrow)"/>
# MAGIC   <path d="M220 252 C280 252, 340 200, 360 170" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#mean-arrow)"/>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1B5162; background: #F8F9FC; padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#1B5162; margin-bottom:6px; font-size:15pt;">Note</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     For columns representing counts or discrete buckets, mean imputation can result in non-integer values that may not be meaningful. In these cases, consider using median, mode, or model-based imputation for more appropriate results.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. K-Nearest Neighbors (KNN) Imputation
# MAGIC
# MAGIC For each row with a missing value, find its *k* nearest neighbors using the **other columns**, then impute as the mean of their values in the missing column.
# MAGIC
# MAGIC <div style="max-width: 620px; margin: 16px 0;">
# MAGIC <svg width="100%" viewBox="0 0 620 370" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>KNN Imputation Visualization (k=2)</title>
# MAGIC   <desc>MonthlyCharges imputed for rows 3 and 6 using Age and Tenure as distance features</desc>
# MAGIC
# MAGIC   <defs>
# MAGIC     <marker id="knn-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#FF3621" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Header bar -->
# MAGIC   <rect x="20" y="10" width="580" height="36" rx="4" fill="#1B3139"/>
# MAGIC   <line x1="20" y1="46" x2="600" y2="46" stroke="#FF3621" stroke-width="3"/>
# MAGIC   <text x="60" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">ID</text>
# MAGIC   <text x="160" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">Age</text>
# MAGIC   <text x="270" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">Tenure</text>
# MAGIC   <text x="430" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">MonthlyCharges</text>
# MAGIC   <text x="560" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">After</text>
# MAGIC
# MAGIC   <!-- Row 1: ID=1, Age=30, Tenure=12, MonthlyCharges=65 -->
# MAGIC   <rect x="20" y="50" width="580" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="94" x2="600" y2="94" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="76" text-anchor="middle" font-size="13" fill="#1B3139">1</text>
# MAGIC   <text x="160" y="76" text-anchor="middle" font-size="13" fill="#1B3139">30</text>
# MAGIC   <text x="270" y="76" text-anchor="middle" font-size="13" fill="#1B3139">12</text>
# MAGIC   <text x="430" y="76" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">65</text>
# MAGIC   <text x="560" y="76" text-anchor="middle" font-size="13" fill="#1B3139">65</text>
# MAGIC
# MAGIC   <!-- Row 2: ID=2, Age=32, Tenure=11, MonthlyCharges=70 -->
# MAGIC   <rect x="20" y="94" width="580" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="138" x2="600" y2="138" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="120" text-anchor="middle" font-size="13" fill="#1B3139">2</text>
# MAGIC   <text x="160" y="120" text-anchor="middle" font-size="13" fill="#1B3139">32</text>
# MAGIC   <text x="270" y="120" text-anchor="middle" font-size="13" fill="#1B3139">11</text>
# MAGIC   <text x="430" y="120" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">70</text>
# MAGIC   <text x="560" y="120" text-anchor="middle" font-size="13" fill="#1B3139">70</text>
# MAGIC
# MAGIC   <!-- Row 3: ID=3, Age=31, Tenure=12, MonthlyCharges=— (imputed → 67.5) -->
# MAGIC   <rect x="20" y="138" width="580" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="182" x2="600" y2="182" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="164" text-anchor="middle" font-size="13" fill="#1B3139">3</text>
# MAGIC   <text x="160" y="164" text-anchor="middle" font-size="13" fill="#1B3139">31</text>
# MAGIC   <text x="270" y="164" text-anchor="middle" font-size="13" fill="#1B3139">12</text>
# MAGIC   <text x="430" y="164" text-anchor="middle" font-size="13" fill="#618794">—</text>
# MAGIC   <rect x="520" y="148" width="80" height="28" rx="4" fill="#FF3621" fill-opacity="0.1" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="560" y="166" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">67.5</text>
# MAGIC
# MAGIC   <!-- Row 4: ID=4, Age=45, Tenure=24, MonthlyCharges=85 -->
# MAGIC   <rect x="20" y="182" width="580" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="226" x2="600" y2="226" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="208" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="160" y="208" text-anchor="middle" font-size="13" fill="#1B3139">45</text>
# MAGIC   <text x="270" y="208" text-anchor="middle" font-size="13" fill="#1B3139">24</text>
# MAGIC   <text x="430" y="208" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">85</text>
# MAGIC   <text x="560" y="208" text-anchor="middle" font-size="13" fill="#1B3139">85</text>
# MAGIC
# MAGIC   <!-- Row 5: ID=5, Age=47, Tenure=22, MonthlyCharges=90 -->
# MAGIC   <rect x="20" y="226" width="580" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="270" x2="600" y2="270" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="252" text-anchor="middle" font-size="13" fill="#1B3139">5</text>
# MAGIC   <text x="160" y="252" text-anchor="middle" font-size="13" fill="#1B3139">47</text>
# MAGIC   <text x="270" y="252" text-anchor="middle" font-size="13" fill="#1B3139">22</text>
# MAGIC   <text x="430" y="252" text-anchor="middle" font-size="13" font-weight="600" fill="#2272B4">90</text>
# MAGIC   <text x="560" y="252" text-anchor="middle" font-size="13" fill="#1B3139">90</text>
# MAGIC
# MAGIC   <!-- Row 6: ID=6, Age=46, Tenure=23, MonthlyCharges=— (imputed → 87.5) -->
# MAGIC   <rect x="20" y="270" width="580" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="314" x2="600" y2="314" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="60" y="296" text-anchor="middle" font-size="13" fill="#1B3139">6</text>
# MAGIC   <text x="160" y="296" text-anchor="middle" font-size="13" fill="#1B3139">46</text>
# MAGIC   <text x="270" y="296" text-anchor="middle" font-size="13" fill="#1B3139">23</text>
# MAGIC   <text x="430" y="296" text-anchor="middle" font-size="13" fill="#618794">—</text>
# MAGIC   <rect x="520" y="280" width="80" height="28" rx="4" fill="#FF3621" fill-opacity="0.1" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="560" y="298" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">87.5</text>
# MAGIC
# MAGIC   <!-- Arrows: row 1 (65) and row 2 (70) → row 3 imputed 67.5 -->
# MAGIC   <path d="M460 76 C490 76, 510 120, 525 152" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#knn-arrow)"/>
# MAGIC   <path d="M460 120 C490 120, 510 140, 525 154" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#knn-arrow)"/>
# MAGIC
# MAGIC   <!-- Arrows: row 4 (85) and row 5 (90) → row 6 imputed 87.5 -->
# MAGIC   <path d="M460 208 C490 208, 510 250, 525 284" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#knn-arrow)"/>
# MAGIC   <path d="M460 252 C490 252, 510 270, 525 286" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#knn-arrow)"/>
# MAGIC
# MAGIC   <!-- Label: distance features -->
# MAGIC   <rect x="120" y="330" width="200" height="26" rx="4" fill="#E3F2FD" stroke="#1976D2" stroke-width="1"/>
# MAGIC   <text x="220" y="347" text-anchor="middle" font-size="11" font-weight="600" fill="#1976D2">↑ Distance features (Age, Tenure)</text>
# MAGIC
# MAGIC   <!-- Label: imputed column -->
# MAGIC   <rect x="380" y="330" width="220" height="26" rx="4" fill="#FFF3E0" stroke="#FF9800" stroke-width="1"/>
# MAGIC   <text x="490" y="347" text-anchor="middle" font-size="11" font-weight="600" fill="#FF9800">↑ Imputed column (MonthlyCharges)</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C3. Regression Imputation
# MAGIC
# MAGIC Train a model on the complete rows, then predict the missing value. The model learns relationships between features — so unlike mean imputation, the predicted value respects inter-column structure.
# MAGIC
# MAGIC <div style="max-width: 560px; margin: 16px 0;">
# MAGIC <svg width="100%" viewBox="0 0 560 320" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>Regression Imputation Visualization</title>
# MAGIC   <desc>A linear model trained on complete rows predicts the missing value in row 5</desc>
# MAGIC
# MAGIC   <defs>
# MAGIC     <marker id="reg-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#FF3621" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Header bar -->
# MAGIC   <rect x="20" y="10" width="520" height="36" rx="4" fill="#1B3139"/>
# MAGIC   <line x1="20" y1="46" x2="540" y2="46" stroke="#FF3621" stroke-width="3"/>
# MAGIC   <text x="70" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">ID</text>
# MAGIC   <text x="170" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">x₁</text>
# MAGIC   <text x="270" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">x₂</text>
# MAGIC   <text x="390" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">y (observed)</text>
# MAGIC   <text x="500" y="33" text-anchor="middle" font-size="13" font-weight="600" fill="#ffffff">y (imputed)</text>
# MAGIC
# MAGIC   <!-- Row 1: x1=2, x2=4, y=12 -->
# MAGIC   <rect x="20" y="50" width="520" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="94" x2="540" y2="94" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="70" y="76" text-anchor="middle" font-size="13" fill="#1B3139">1</text>
# MAGIC   <text x="170" y="76" text-anchor="middle" font-size="13" fill="#1B3139">2</text>
# MAGIC   <text x="270" y="76" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="390" y="76" text-anchor="middle" font-size="13" fill="#1B3139">12</text>
# MAGIC   <text x="500" y="76" text-anchor="middle" font-size="13" fill="#1B3139">12</text>
# MAGIC
# MAGIC   <!-- Row 2: x1=3, x2=6, y=17 -->
# MAGIC   <rect x="20" y="94" width="520" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="138" x2="540" y2="138" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="70" y="120" text-anchor="middle" font-size="13" fill="#1B3139">2</text>
# MAGIC   <text x="170" y="120" text-anchor="middle" font-size="13" fill="#1B3139">3</text>
# MAGIC   <text x="270" y="120" text-anchor="middle" font-size="13" fill="#1B3139">6</text>
# MAGIC   <text x="390" y="120" text-anchor="middle" font-size="13" fill="#1B3139">17</text>
# MAGIC   <text x="500" y="120" text-anchor="middle" font-size="13" fill="#1B3139">17</text>
# MAGIC
# MAGIC   <!-- Row 3: x1=4, x2=8, y=22 -->
# MAGIC   <rect x="20" y="138" width="520" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="182" x2="540" y2="182" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="70" y="164" text-anchor="middle" font-size="13" fill="#1B3139">3</text>
# MAGIC   <text x="170" y="164" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="270" y="164" text-anchor="middle" font-size="13" fill="#1B3139">8</text>
# MAGIC   <text x="390" y="164" text-anchor="middle" font-size="13" fill="#1B3139">22</text>
# MAGIC   <text x="500" y="164" text-anchor="middle" font-size="13" fill="#1B3139">22</text>
# MAGIC
# MAGIC   <!-- Row 4: x1=5, x2=2, y=19 -->
# MAGIC   <rect x="20" y="182" width="520" height="44" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="226" x2="540" y2="226" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="70" y="208" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="170" y="208" text-anchor="middle" font-size="13" fill="#1B3139">5</text>
# MAGIC   <text x="270" y="208" text-anchor="middle" font-size="13" fill="#1B3139">2</text>
# MAGIC   <text x="390" y="208" text-anchor="middle" font-size="13" fill="#1B3139">19</text>
# MAGIC   <text x="500" y="208" text-anchor="middle" font-size="13" fill="#1B3139">19</text>
# MAGIC
# MAGIC   <!-- Row 5: x1=4, x2=5, y=— → imputed 19 -->
# MAGIC   <rect x="20" y="226" width="520" height="44" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="270" x2="540" y2="270" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="70" y="252" text-anchor="middle" font-size="13" fill="#1B3139">5</text>
# MAGIC   <text x="170" y="252" text-anchor="middle" font-size="13" fill="#1B3139">4</text>
# MAGIC   <text x="270" y="252" text-anchor="middle" font-size="13" fill="#1B3139">5</text>
# MAGIC   <text x="390" y="252" text-anchor="middle" font-size="13" fill="#618794">—</text>
# MAGIC   <rect x="462" y="236" width="76" height="28" rx="4" fill="#FF3621" fill-opacity="0.1" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="500" y="254" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">19</text>
# MAGIC
# MAGIC   <!-- Arrows from complete rows to imputed value -->
# MAGIC   <path d="M420 76 C450 76, 460 180, 468 240" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#reg-arrow)"/>
# MAGIC   <path d="M420 120 C445 120, 455 180, 468 242" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#reg-arrow)"/>
# MAGIC   <path d="M420 164 C445 164, 455 200, 468 244" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#reg-arrow)"/>
# MAGIC   <path d="M420 208 C445 208, 455 220, 468 244" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="4 2" marker-end="url(#reg-arrow)"/>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC Learned model from rows 1–4:
# MAGIC
# MAGIC $$\hat{y} = 2 + 3x_1 + 1x_2$$
# MAGIC
# MAGIC For row 5:
# MAGIC
# MAGIC $$\hat{y} = 2 + 3(4) + 1(5) = 19$$
# MAGIC
# MAGIC The prediction uses the actual relationships between columns — unlike mean imputation, which would give (12+17+22+19)/4 = 17.5 regardless of what x₁ and x₂ say about row 5.

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Best Practices

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. Choosing the Right Method
# MAGIC
# MAGIC There is no single best approach. The choice depends on several factors:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Factor</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Implication</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Data type</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Categorical → mode or new category; continuous → mean/median/regression</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Distribution</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Skewed or with outliers → prefer median over mean</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Amount missing</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">High missingness (~30%+) → consider KNN or model-based imputation over single-value methods; the right threshold depends on context</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Missingness pattern</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Missing at random vs. systematic — if systematic, an indicator column is essential</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Domain knowledge</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A missing <code>OnlineSecurity</code> <em>means</em> "not subscribed" — fill with "No", not the mode</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D2. Mark Imputed Values
# MAGIC
# MAGIC **Best practice:** add an indicator column for each imputed feature. This preserves the fact that a value was originally missing and lets the model learn from missingness patterns directly.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 500px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">ID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Name</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Age</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Age_imputed</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">Alice</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">25.0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">Bob</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">30.0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">Charlie</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #FF3621;">26.0</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #FF3621;">1</strong></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">David</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">28.0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC Indicator columns are useful for:
# MAGIC
# MAGIC - **Model evaluation** — segment performance by imputed vs. observed values
# MAGIC - **Transparency** — auditors can distinguish observed values from filled-in ones

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the key concepts and techniques for handling missing data in machine learning pipelines:
# MAGIC
# MAGIC 1. **Why Missing Data Matters** — missing values degrade model performance, introduce bias, create imbalanced representations, and add complexity to every pipeline stage.
# MAGIC 2. **How to Handle Missing Data** — the three top-level strategies are dropping rows or columns, treating missingness as a category, and replacing with an estimated value (imputation); most projects use a mix.
# MAGIC 3. **Replacement Methods in Practice** — mean/median/mode imputation is simple but insensitive to relationships between features; KNN captures inter-column dependencies; regression imputation models uncertainty directly.
# MAGIC 4. **Best Practices** — the right method depends on data type, distribution, amount missing, and domain knowledge; always mark imputed values with indicator columns for transparency and traceability.

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>