# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Lecture — Data Standardization
# MAGIC
# MAGIC This lecture covers the following four sections that build on each other:
# MAGIC
# MAGIC - **A. What Standardization Is and Why It Matters**. The definition of standardization (z-score, min–max, robust scaling), its four key benefits, and a worked example showing how raw feature scales distort coefficient interpretation
# MAGIC - **B. When Standardization Is Required**. Which model families are sensitive vs. robust to feature scale, and the concrete signals that indicate you need to standardize
# MAGIC - **C. The Standardization Process in Spark ML**. The correct order of operations to avoid data leakage, the three Spark ML scalers, and where standardization fits in the demo pipeline
# MAGIC - **D. Drawbacks and Trade-offs**. Loss of original interpretation, challenges with interaction terms, and the normality assumption underlying z-score scaling
# MAGIC - **E. Conclusion**. Summary of key concepts and practical guidance
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Define data standardization and explain its four benefits: improved interpretability, prevention of model bias, enhanced convergence, and effective regularization
# MAGIC - Identify which models are sensitive to feature scale (linear, SVM, KNN, neural networks, K-Means, PCA) vs. robust (tree-based, ensemble)
# MAGIC - Apply `StandardScaler`, `MinMaxScaler`, and `RobustScaler` in a Spark ML pipeline with `VectorAssembler`
# MAGIC - Explain why the scaler must be fit on training data only to prevent data leakage
# MAGIC - Recognize the interpretation costs and assumption risks of standardization
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. What Standardization Is and Why It Matters

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Definition
# MAGIC
# MAGIC **Data standardization** is the process of transforming data into a consistent format that meets predefined standards. This is especially important when data comes from different sources or has different scales — standardization brings everything to the same scale and format.
# MAGIC
# MAGIC **Purpose:** Ensures data consistency and optimizes model performance by allowing models to interpret features correctly and equitably.
# MAGIC
# MAGIC The most common form replaces each value with its *z-score*, which is computed by subtracting the feature mean and dividing by its standard deviation. This centers the data at zero and scales it to unit variance.
# MAGIC
# MAGIC <div style="margin: 16px 0; text-align: center;">
# MAGIC     <strong>Z-score standardization formula:</strong><br>
# MAGIC     \[
# MAGIC         z = \frac{\text{value} - \mu_{\text{feature}}}{\sigma_{\text{feature}}}
# MAGIC     \]
# MAGIC </div>
# MAGIC
# MAGIC After standardization, the column has mean ≈ 0 and std ≈ 1. Other variants are summarized below:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Variant</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What it produces</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Best for</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Standardization (z-score)</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Mean 0, std 1</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Roughly Gaussian features</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Min–max scaling</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Range [0, 1]</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Bounded inputs (image pixels, percentages)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Robust scaling</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Centered on median, scaled by IQR</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Features with outliers</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <div style="border-left: 4px solid #00A972; background: rgba(0,169,114,0.10); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#00A972; margin-bottom:6px; font-size:15pt;">Success</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Best Practice:</b> Standardize features <b>before model training</b> by fitting the scaler on the <b>training data only</b>. Then apply the same scaling parameters (mean and std) to the test set. This ensures consistent feature scaling and prevents data leakage, leading to reliable model evaluation and improved performance.
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A1.1 Raw Data Before Standardization
# MAGIC
# MAGIC <svg viewBox="0 0 400 250" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="400" height="250" fill="white"/>
# MAGIC   <text x="200" y="20" text-anchor="middle" font-size="11" font-weight="bold" fill="#333">Raw Data (Before Standardization)</text>
# MAGIC   <line x1="60" y1="210" x2="370" y2="210" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="60" y1="30" x2="60" y2="210" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="60" y1="170" x2="370" y2="170" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="60" y1="90" x2="370" y2="90" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="60" y1="50" x2="370" y2="50" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <text x="52" y="214" text-anchor="end" font-size="9" fill="#555">-50</text>
# MAGIC   <text x="52" y="174" text-anchor="end" font-size="9" fill="#555">250</text>
# MAGIC   <text x="52" y="124" text-anchor="end" font-size="9" fill="#555">500</text>
# MAGIC   <text x="52" y="94" text-anchor="end" font-size="9" fill="#555">700</text>
# MAGIC   <text x="52" y="54" text-anchor="end" font-size="9" fill="#555">900</text>
# MAGIC   <text x="90" y="225" text-anchor="middle" font-size="9" fill="#555">1</text>
# MAGIC   <text x="152" y="225" text-anchor="middle" font-size="9" fill="#555">3</text>
# MAGIC   <text x="214" y="225" text-anchor="middle" font-size="9" fill="#555">5</text>
# MAGIC   <text x="276" y="225" text-anchor="middle" font-size="9" fill="#555">7</text>
# MAGIC   <text x="338" y="225" text-anchor="middle" font-size="9" fill="#555">9</text>
# MAGIC   <text x="215" y="242" text-anchor="middle" font-size="10" fill="#333">Sample Index</text>
# MAGIC   <text x="15" y="125" text-anchor="middle" font-size="9" fill="#333" transform="rotate(-90,15,125)">Value</text>
# MAGIC   <circle cx="90" cy="200" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="121" cy="198" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="152" cy="201" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="183" cy="202" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="214" cy="200" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="245" cy="198" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="276" cy="202" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="307" cy="201" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="338" cy="200" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="90" cy="90" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="121" cy="74" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="152" cy="112" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="183" cy="60" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="214" cy="138" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="245" cy="85" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="276" cy="97" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="307" cy="70" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="338" cy="94" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <rect x="70" y="28" width="200" height="36" fill="white" stroke="#ddd" stroke-width="0.5" rx="3"/>
# MAGIC   <circle cx="80" cy="40" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <text x="88" y="43" font-size="9" fill="#333">Feature A (scale: 0–10)</text>
# MAGIC   <circle cx="80" cy="55" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <text x="88" y="58" font-size="9" fill="#333">Feature B (scale: 0–1000)</text>
# MAGIC </svg>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A1.2 Standardized Data After Z-Score Normalization
# MAGIC
# MAGIC <svg viewBox="0 0 400 250" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="400" height="250" fill="white"/>
# MAGIC   <text x="200" y="20" text-anchor="middle" font-size="11" font-weight="bold" fill="#333">Standardized Data (After Z-Score Normalization)</text>
# MAGIC   <line x1="60" y1="210" x2="370" y2="210" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="60" y1="30" x2="60" y2="210" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="60" y1="170" x2="370" y2="170" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="60" y1="90" x2="370" y2="90" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="60" y1="50" x2="370" y2="50" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- Dashed line at Mean = 0 -->
# MAGIC   <line x1="60" y1="120" x2="370" y2="120" stroke="gray" stroke-width="1" stroke-dasharray="5,4" opacity="0.7"/>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="52" y="214" text-anchor="end" font-size="9" fill="#555">-3.5</text>
# MAGIC   <text x="52" y="174" text-anchor="end" font-size="9" fill="#555">-1.5</text>
# MAGIC   <text x="52" y="124" text-anchor="end" font-size="9" fill="#555">0</text>
# MAGIC   <text x="52" y="94" text-anchor="end" font-size="9" fill="#555">1.5</text>
# MAGIC   <text x="52" y="54" text-anchor="end" font-size="9" fill="#555">3.5</text>
# MAGIC   <!-- X-axis labels -->
# MAGIC   <text x="90" y="225" text-anchor="middle" font-size="9" fill="#555">1</text>
# MAGIC   <text x="152" y="225" text-anchor="middle" font-size="9" fill="#555">3</text>
# MAGIC   <text x="214" y="225" text-anchor="middle" font-size="9" fill="#555">5</text>
# MAGIC   <text x="276" y="225" text-anchor="middle" font-size="9" fill="#555">7</text>
# MAGIC   <text x="338" y="225" text-anchor="middle" font-size="9" fill="#555">9</text>
# MAGIC   <text x="215" y="242" text-anchor="middle" font-size="10" fill="#333">Sample Index</text>
# MAGIC   <text x="15" y="125" text-anchor="middle" font-size="9" fill="#333" transform="rotate(-90,15,125)">Standardized Value (z-score)</text>
# MAGIC   <!-- Feature A standardized (scattered around 0) -->
# MAGIC   <circle cx="90" cy="133" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="121" cy="89" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="152" cy="141" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="183" cy="112" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="214" cy="81" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="245" cy="146" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="276" cy="102" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="307" cy="153" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <circle cx="338" cy="97" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <!-- Feature B standardized (scattered around 0) -->
# MAGIC   <circle cx="90" cy="99" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="121" cy="159" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="152" cy="112" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="183" cy="74" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="214" cy="138" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="245" cy="94" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="276" cy="151" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="307" cy="107" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <circle cx="338" cy="128" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <!-- Legend -->
# MAGIC   <rect x="70" y="28" width="200" height="36" fill="white" stroke="#ddd" stroke-width="0.5" rx="3"/>
# MAGIC   <circle cx="80" cy="40" r="4" fill="#2196F3" opacity="0.8"/>
# MAGIC   <text x="88" y="43" font-size="9" fill="#333">Feature A (standardized)</text>
# MAGIC   <circle cx="80" cy="55" r="4" fill="#FF5722" opacity="0.8"/>
# MAGIC   <text x="88" y="58" font-size="9" fill="#333">Feature B (standardized)</text>
# MAGIC   <!-- Mean = 0 label -->
# MAGIC   <text x="372" y="117" font-size="8" fill="gray">Mean = 0</text>
# MAGIC   <!-- Formula annotation -->
# MAGIC   <rect x="295" y="192" width="75" height="18" fill="lightyellow" stroke="gray" stroke-width="0.5" rx="3"/>
# MAGIC   <text x="332" y="204" text-anchor="middle" font-size="8" fill="#333">z = (x - u) / s</text>
# MAGIC </svg>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A1.3 Histogram: Before vs After Standardization
# MAGIC
# MAGIC <svg viewBox="0 0 360 198" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="360" height="198" fill="white"/>
# MAGIC   <text x="180" y="16" text-anchor="middle" font-size="10" font-weight="bold" fill="#333">Feature B — Before Standardization</text>
# MAGIC   <!-- Axes -->
# MAGIC   <line x1="54" y1="162" x2="333" y2="162" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="54" y1="27" x2="54" y2="162" stroke="#333" stroke-width="1"/>
# MAGIC   <!-- Y gridlines -->
# MAGIC   <line x1="54" y1="135" x2="333" y2="135" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="108" x2="333" y2="108" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="81" x2="333" y2="81" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="54" x2="333" y2="54" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="47" y="166" text-anchor="end" font-size="8" fill="#555">0</text>
# MAGIC   <text x="47" y="135" text-anchor="end" font-size="8" fill="#555">2</text>
# MAGIC   <text x="47" y="108" text-anchor="end" font-size="8" fill="#555">4</text>
# MAGIC   <text x="47" y="81" text-anchor="end" font-size="8" fill="#555">6</text>
# MAGIC   <text x="47" y="54" text-anchor="end" font-size="8" fill="#555">8</text>
# MAGIC   <!-- X-axis labels -->
# MAGIC   <text x="81" y="179" text-anchor="middle" font-size="8" fill="#555">200</text>
# MAGIC   <text x="144" y="179" text-anchor="middle" font-size="8" fill="#555">350</text>
# MAGIC   <text x="207" y="179" text-anchor="middle" font-size="8" fill="#555">500</text>
# MAGIC   <text x="270" y="179" text-anchor="middle" font-size="8" fill="#555">650</text>
# MAGIC   <text x="333" y="179" text-anchor="middle" font-size="8" fill="#555">800</text>
# MAGIC   <!-- Axis labels -->
# MAGIC   <text x="193" y="191" text-anchor="middle" font-size="9" fill="#333">Value</text>
# MAGIC   <text x="16" y="99" text-anchor="middle" font-size="8" fill="#333" transform="rotate(-90,16,99)">Frequency</text>
# MAGIC   <!-- Histogram bars (orange) -->
# MAGIC   <rect x="67" y="149" width="22" height="13" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="89" y="136" width="22" height="26" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="111" y="123" width="22" height="39" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="133" y="108" width="22" height="54" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="155" y="81" width="22" height="81" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="177" y="54" width="22" height="108" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="199" y="68" width="22" height="94" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="221" y="81" width="22" height="81" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="243" y="108" width="22" height="54" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="265" y="123" width="22" height="39" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="287" y="136" width="22" height="26" fill="#FF5722" opacity="0.7"/>
# MAGIC   <rect x="309" y="149" width="22" height="13" fill="#FF5722" opacity="0.7"/>
# MAGIC   <!-- Mean dashed line -->
# MAGIC   <line x1="196" y1="27" x2="196" y2="162" stroke="black" stroke-width="1.5" stroke-dasharray="5,4"/>
# MAGIC   <!-- Legend -->
# MAGIC   <rect x="239" y="29" width="95" height="16" fill="white" stroke="#ddd" stroke-width="0.5" rx="3"/>
# MAGIC   <line x1="245" y="37" x2="257" y="37" stroke="black" stroke-width="1.5" stroke-dasharray="4,3"/>
# MAGIC   <text x="261" y="40" font-size="7" fill="#333">Mean = 500</text>
# MAGIC </svg>
# MAGIC
# MAGIC --- 
# MAGIC <svg viewBox="0 0 360 198" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="360" height="198" fill="white"/>
# MAGIC   <text x="180" y="16" text-anchor="middle" font-size="10" font-weight="bold" fill="#333">Feature B — After Standardization</text>
# MAGIC   <!-- Axes -->
# MAGIC   <line x1="54" y1="162" x2="333" y2="162" stroke="#333" stroke-width="1"/>
# MAGIC   <line x1="54" y1="27" x2="54" y2="162" stroke="#333" stroke-width="1"/>
# MAGIC   <!-- Y gridlines -->
# MAGIC   <line x1="54" y1="135" x2="333" y2="135" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="108" x2="333" y2="108" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="81" x2="333" y2="81" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="54" y1="54" x2="333" y2="54" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="47" y="166" text-anchor="end" font-size="8" fill="#555">0</text>
# MAGIC   <text x="47" y="135" text-anchor="end" font-size="8" fill="#555">2</text>
# MAGIC   <text x="47" y="108" text-anchor="end" font-size="8" fill="#555">4</text>
# MAGIC   <text x="47" y="81" text-anchor="end" font-size="8" fill="#555">6</text>
# MAGIC   <text x="47" y="54" text-anchor="end" font-size="8" fill="#555">8</text>
# MAGIC   <!-- X-axis labels -->
# MAGIC   <text x="81" y="179" text-anchor="middle" font-size="8" fill="#555">-3.5</text>
# MAGIC   <text x="144" y="179" text-anchor="middle" font-size="8" fill="#555">-1.75</text>
# MAGIC   <text x="207" y="179" text-anchor="middle" font-size="8" fill="#555">0</text>
# MAGIC   <text x="270" y="179" text-anchor="middle" font-size="8" fill="#555">1.75</text>
# MAGIC   <text x="333" y="179" text-anchor="middle" font-size="8" fill="#555">3.5</text>
# MAGIC   <!-- Axis labels -->
# MAGIC   <text x="193" y="191" text-anchor="middle" font-size="9" fill="#333">Standardized Value (z-score)</text>
# MAGIC   <text x="16" y="99" text-anchor="middle" font-size="8" fill="#333" transform="rotate(-90,16,99)">Frequency</text>
# MAGIC   <!-- Histogram bars (green) -->
# MAGIC   <rect x="67" y="149" width="22" height="13" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="89" y="136" width="22" height="26" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="111" y="123" width="22" height="39" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="133" y="108" width="22" height="54" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="155" y="81" width="22" height="81" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="177" y="54" width="22" height="108" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="199" y="68" width="22" height="94" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="221" y="81" width="22" height="81" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="243" y="108" width="22" height="54" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="265" y="123" width="22" height="39" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="287" y="136" width="22" height="26" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <rect x="309" y="149" width="22" height="13" fill="#4CAF50" opacity="0.7"/>
# MAGIC   <!-- Mean dashed line at 0 -->
# MAGIC   <line x1="196" y1="27" x2="196" y2="162" stroke="black" stroke-width="1.5" stroke-dasharray="5,4"/>
# MAGIC   <!-- Legend -->
# MAGIC   <rect x="239" y="29" width="86" height="16" fill="white" stroke="#ddd" stroke-width="0.5" rx="3"/>
# MAGIC   <line x1="245" y="37" x2="257" y="37" stroke="black" stroke-width="1.5" stroke-dasharray="4,3"/>
# MAGIC   <text x="261" y="40" font-size="7" fill="#333">Mean = 0</text>
# MAGIC </svg>
# MAGIC
# MAGIC <p style="text-align:center; font-size:11px; font-style:italic; color:#555; margin-top:8px;">The standardized version has mean \~ 0 and standard deviation \~ 1, enabling fair comparison across features.</p>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Benefits
# MAGIC
# MAGIC Standardizing features offers four concrete advantages:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Benefit</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Why</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Improved interpretability</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Coefficients on a common scale are directly comparable — larger absolute value ⇒ stronger effect</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Prevention of model bias</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A feature with a huge magnitude won't dominate the loss just because of its units</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Enhanced convergence</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Gradient descent converges faster on well-scaled features</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Effective regularization</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">L1/L2 penalties assume features are on a similar scale</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A2.1 Improved Interpretability
# MAGIC
# MAGIC Raw coefficient magnitude reflects feature scale, not predictive power:
# MAGIC
# MAGIC ---
# MAGIC <svg viewBox="0 0 360 180" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="360" height="180" fill="white"/>
# MAGIC   <!-- Title -->
# MAGIC   <text x="216" y="16" text-anchor="middle" font-size="10" font-weight="bold" fill="#333">Before Standardization — Raw Coefficients</text>
# MAGIC   <!-- X-axis -->
# MAGIC   <line x1="86" y1="144" x2="338" y2="144" stroke="#ddd" stroke-width="1"/>
# MAGIC   <!-- Vertical zero line -->
# MAGIC   <line x1="86" y1="31.5" x2="86" y2="144" stroke="#999" stroke-width="0.6"/>
# MAGIC   <!-- X gridlines -->
# MAGIC   <line x1="149" y1="31.5" x2="149" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="212" y1="31.5" x2="212" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="275" y1="31.5" x2="275" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="338" y1="31.5" x2="338" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- X-axis labels: 0, 10k, 20k, 30k, 40k -->
# MAGIC   <text x="86" y="157" text-anchor="middle" font-size="7" fill="#555">0</text>
# MAGIC   <text x="149" y="157" text-anchor="middle" font-size="7" fill="#555">10k</text>
# MAGIC   <text x="212" y="157" text-anchor="middle" font-size="7" fill="#555">20k</text>
# MAGIC   <text x="275" y="157" text-anchor="middle" font-size="7" fill="#555">30k</text>
# MAGIC   <text x="338" y="157" text-anchor="middle" font-size="7" fill="#555">40k</text>
# MAGIC   <!-- X-axis title -->
# MAGIC   <text x="211.5" y="172" text-anchor="middle" font-size="8" fill="#555">Raw Coefficient Value ($)</text>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="81" y="52.2" text-anchor="end" font-size="8" fill="#555">Sq. Footage</text>
# MAGIC   <text x="81" y="61.2" text-anchor="end" font-size="6.3" fill="#888">(0–5,000)</text>
# MAGIC   <text x="81" y="88.2" text-anchor="end" font-size="8" fill="#555">Bedrooms</text>
# MAGIC   <text x="81" y="97.2" text-anchor="end" font-size="6.3" fill="#888">(1–6)</text>
# MAGIC   <text x="81" y="124.2" text-anchor="end" font-size="8" fill="#555">House Age</text>
# MAGIC   <text x="81" y="133.2" text-anchor="end" font-size="6.3" fill="#888">(0–80 yrs)</text>
# MAGIC   <!-- Bars (coral #FF6B6B) -->
# MAGIC   <!-- Sq. Footage: 150 → (150/40000)*252 = ~1px -->
# MAGIC   <rect x="86" y="42.3" width="1" height="19.8" fill="#FF6B6B" opacity="0.9" rx="0"/>
# MAGIC   <text x="91" y="55.8" font-size="8" font-weight="bold" fill="#444">150</text>
# MAGIC   <!-- Bedrooms: 35,000 → (35000/40000)*252 = 220px -->
# MAGIC   <rect x="86" y="78.3" width="220" height="19.8" fill="#FF6B6B" opacity="0.9" rx="2.7"/>
# MAGIC   <text x="309" y="91.8" font-size="8" font-weight="bold" fill="#444">35,000</text>
# MAGIC   <!-- House Age: 800 → (800/40000)*252 = 5px -->
# MAGIC   <rect x="86" y="114.3" width="5" height="19.8" fill="#FF6B6B" opacity="0.9" rx="1"/>
# MAGIC   <text x="95" y="127.8" font-size="8" font-weight="bold" fill="#444">800</text>
# MAGIC   <!-- Warning callout -->
# MAGIC   <rect x="216" y="106.2" width="135" height="28.8" fill="#fdecea" stroke="#e74c3c" stroke-width="0.72" rx="3.6" opacity="0.85"/>
# MAGIC   <text x="223.2" y="118.8" font-size="6.75" fill="#c0392b" font-style="italic">⚠ Bedrooms looks dominant —</text>
# MAGIC   <text x="225.9" y="128.7" font-size="6.75" fill="#c0392b" font-style="italic">but that's just its small scale</text>
# MAGIC </svg>
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <svg viewBox="0 0 360 180" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="360" height="180" fill="white"/>
# MAGIC   <!-- Title -->
# MAGIC   <text x="207" y="16" text-anchor="middle" font-size="10" font-weight="bold" fill="#333">After Standardization — Coefficients on Common Scale</text>
# MAGIC   <!-- X-axis -->
# MAGIC   <line x1="54" y1="144" x2="333" y2="144" stroke="#ddd" stroke-width="1"/>
# MAGIC   <!-- Vertical zero line -->
# MAGIC   <line x1="157.5" y1="31.5" x2="157.5" y2="144" stroke="#999" stroke-width="0.6"/>
# MAGIC   <!-- X gridlines -->
# MAGIC   <line x1="54" y1="31.5" x2="54" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="105.3" y1="31.5" x2="105.3" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="208.8" y1="31.5" x2="208.8" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="261" y1="31.5" x2="261" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="312.3" y1="31.5" x2="312.3" y2="144" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- X-axis labels: -1.0, -0.5, 0, 0.5, 1.0, 1.5 -->
# MAGIC   <text x="54" y="157" text-anchor="middle" font-size="7" fill="#555">-1.0</text>
# MAGIC   <text x="105.3" y="157" text-anchor="middle" font-size="7" fill="#555">-0.5</text>
# MAGIC   <text x="157.5" y="157" text-anchor="middle" font-size="7" fill="#555">0</text>
# MAGIC   <text x="208.8" y="157" text-anchor="middle" font-size="7" fill="#555">0.5</text>
# MAGIC   <text x="261" y="157" text-anchor="middle" font-size="7" fill="#555">1.0</text>
# MAGIC   <text x="312.3" y="157" text-anchor="middle" font-size="7" fill="#555">1.5</text>
# MAGIC   <!-- X-axis title -->
# MAGIC   <text x="193.5" y="172" text-anchor="middle" font-size="8" fill="#555">Standardized Coefficient (relative importance)</text>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="49.5" y="54" text-anchor="end" font-size="8" fill="#555">Sq. Footage</text>
# MAGIC   <text x="49.5" y="90" text-anchor="end" font-size="8" fill="#555">Bedrooms</text>
# MAGIC   <text x="49.5" y="126" text-anchor="end" font-size="8" fill="#555">House Age</text>
# MAGIC   <!-- Bars (coral #FF6B6B) -->
# MAGIC   <!-- Sq. Footage: +1.35 → 1.35 * 103.3 = 139px right of zero -->
# MAGIC   <rect x="157.5" y="44.1" width="139" height="19.8" fill="#FF6B6B" opacity="0.9" rx="2.7"/>
# MAGIC   <text x="296.1" y="57.6" font-size="8" font-weight="bold" fill="#444">+1.35</text>
# MAGIC   <!-- Bedrooms: +0.45 → 46.5px right of zero -->
# MAGIC   <rect x="157.5" y="79.2" width="46.5" height="19.8" fill="#FF6B6B" opacity="0.9" rx="2.7"/>
# MAGIC   <text x="208" y="92.7" font-size="8" font-weight="bold" fill="#444">+0.45</text>
# MAGIC   <!-- House Age: +0.15 → 15.5px right of zero -->
# MAGIC   <rect x="157.5" y="114.3" width="15.5" height="19.8" fill="#FF6B6B" opacity="0.9" rx="2.7"/>
# MAGIC   <text x="177" y="127.8" font-size="8" font-weight="bold" fill="#444">+0.15</text>
# MAGIC   <!-- Insight callout -->
# MAGIC   <rect x="214" y="108" width="132" height="28.8" fill="#e8f8f5" stroke="#4ECDC4" stroke-width="0.72" rx="3.6" opacity="0.85"/>
# MAGIC   <text x="220" y="120.6" font-size="6.3" fill="#1a7a6d" font-style="italic">✓ Sq. Footage actually matters most</text>
# MAGIC   <text x="222" y="130.5" font-size="6.3" fill="#1a7a6d" font-style="italic">— hidden by its large raw scale</text>
# MAGIC </svg>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A2.2 Prevention of Model Bias
# MAGIC
# MAGIC Training spends a **budget** setting each feature's coefficient. Because a coefficient multiplies the feature's raw value, the size it needs depends on scale:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Feature</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Scale</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Coefficient needed</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Cost to adjust</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Sq. Footage</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">large (0–5,000)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">~150 (tiny)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">✓ cheap → dominates</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">House Age</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">medium (0–80)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">~800</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">~ moderate</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Bedrooms</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">small (1–6)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">~35,000 (large)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">✗ expensive → ignored</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The model leans on whatever is **cheapest to adjust** — the tiny coefficients of large-scale features — so they dominate by scale, not by predictive power. Standardization puts every coefficient on equal footing.
# MAGIC
# MAGIC *Distance-based models (KNN, K-Means) show the same bias: the large-scale feature dominates the distance calculation.*

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A2.3 Enhanced Convergence
# MAGIC
# MAGIC Gradient descent converges faster when features share a common scale:
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <svg viewBox="0 0 400 250" xmlns="http://www.w3.org/2000/svg">
# MAGIC   <rect width="400" height="250" fill="white"/>
# MAGIC   <!-- Title -->
# MAGIC   <text x="200" y="18" text-anchor="middle" font-size="11" font-weight="bold" fill="#333">Training Loss Convergence — Effect of Standardization</text>
# MAGIC   <!-- Axes -->
# MAGIC   <line x1="55" y1="210" x2="375" y2="210" stroke="#ddd" stroke-width="1"/>
# MAGIC   <line x1="55" y1="30" x2="55" y2="210" stroke="#ddd" stroke-width="1"/>
# MAGIC   <!-- Y gridlines -->
# MAGIC   <line x1="55" y1="170" x2="375" y2="170" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="55" y1="130" x2="375" y2="130" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="55" y1="90" x2="375" y2="90" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="55" y1="50" x2="375" y2="50" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- X gridlines -->
# MAGIC   <line x1="135" y1="30" x2="135" y2="210" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="215" y1="30" x2="215" y2="210" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="295" y1="30" x2="295" y2="210" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <line x1="375" y1="30" x2="375" y2="210" stroke="#eee" stroke-width="0.5"/>
# MAGIC   <!-- Y-axis labels -->
# MAGIC   <text x="48" y="214" text-anchor="end" font-size="8" fill="#555">0</text>
# MAGIC   <text x="48" y="174" text-anchor="end" font-size="8" fill="#555">0.8</text>
# MAGIC   <text x="48" y="134" text-anchor="end" font-size="8" fill="#555">1.6</text>
# MAGIC   <text x="48" y="94" text-anchor="end" font-size="8" fill="#555">2.4</text>
# MAGIC   <text x="48" y="54" text-anchor="end" font-size="8" fill="#555">3.2</text>
# MAGIC   <!-- X-axis labels -->
# MAGIC   <text x="55" y="224" text-anchor="middle" font-size="8" fill="#555">0</text>
# MAGIC   <text x="135" y="224" text-anchor="middle" font-size="8" fill="#555">10</text>
# MAGIC   <text x="215" y="224" text-anchor="middle" font-size="8" fill="#555">20</text>
# MAGIC   <text x="295" y="224" text-anchor="middle" font-size="8" fill="#555">30</text>
# MAGIC   <text x="375" y="224" text-anchor="middle" font-size="8" fill="#555">40</text>
# MAGIC   <!-- Axis titles -->
# MAGIC   <text x="215" y="240" text-anchor="middle" font-size="9" fill="#555">Iteration (Epoch)</text>
# MAGIC   <text x="15" y="120" text-anchor="middle" font-size="9" fill="#555" transform="rotate(-90,15,120)">Training Loss</text>
# MAGIC   <!-- Without Standardization line (coral, erratic) -->
# MAGIC   <polyline fill="none" stroke="#FF6B6B" stroke-width="2" opacity="0.9"
# MAGIC     points="55,42 63,55 71,48 79,62 87,55 95,68 103,58 111,72 119,65 127,78 135,70 143,82 151,88 159,78 167,92 175,85 183,95 191,105 199,95 207,110 215,100 223,115 231,105 239,118 247,125 255,115 263,128 271,135 279,125 287,138 295,142 303,135 311,145 319,150 327,142 335,148 343,155 351,150 359,158 367,155"/>
# MAGIC   <!-- With Standardization line (teal, smooth fast convergence) -->
# MAGIC   <polyline fill="none" stroke="#4ECDC4" stroke-width="2" opacity="0.9"
# MAGIC     points="55,42 63,60 71,78 79,95 87,110 95,125 103,138 111,148 119,156 127,163 135,168 143,172 151,176 159,179 167,181 175,183 183,185 191,186 199,187 207,188 215,189 223,189 231,190 239,190 247,190 255,191 263,191 271,191 279,191 287,192 295,192 303,192 311,192 319,192 327,192 335,192 343,192 351,192 359,192 367,192"/>
# MAGIC   <!-- Legend -->
# MAGIC   <rect x="240" y="32" width="135" height="32" fill="white" stroke="#ddd" stroke-width="0.5" rx="3"/>
# MAGIC   <line x1="248" y1="43" x2="268" y2="43" stroke="#FF6B6B" stroke-width="2"/>
# MAGIC   <text x="272" y="46" font-size="8" fill="#333">Without Standardization</text>
# MAGIC   <line x1="248" y1="57" x2="268" y2="57" stroke="#4ECDC4" stroke-width="2"/>
# MAGIC   <text x="272" y="60" font-size="8" fill="#333">With Standardization</text>
# MAGIC   <!-- Annotation: Converged -->
# MAGIC   <rect x="225" y="175" width="100" height="16" fill="#e8f8f5" stroke="#4ECDC4" stroke-width="0.8" rx="3" opacity="0.85"/>
# MAGIC   <text x="275" y="186" text-anchor="middle" font-size="7.5" fill="#1a7a6d" font-style="italic">Converged ≈ epoch 20</text>
# MAGIC   <line x1="215" y1="189" x2="225" y2="183" stroke="#4ECDC4" stroke-width="1"/>
# MAGIC   <!-- Annotation: Still oscillating -->
# MAGIC   <rect x="295" y="108" width="85" height="16" fill="#fdecea" stroke="#e74c3c" stroke-width="0.8" rx="3" opacity="0.85"/>
# MAGIC   <text x="337" y="119" text-anchor="middle" font-size="7.5" fill="#c0392b" font-style="italic">Still oscillating</text>
# MAGIC   <line x1="319" y1="142" x2="320" y2="124" stroke="#FF6B6B" stroke-width="1"/>
# MAGIC </svg>
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### A2.4 Effective Regularization
# MAGIC
# MAGIC L1 and L2 regularization penalize large coefficients. On raw features, a small-scale feature like Bedrooms may need a much larger coefficient than Sq. Footage to have a comparable effect, so it takes a disproportionate share of the penalty.
# MAGIC
# MAGIC After standardization, coefficients become comparable. The penalty is then distributed more in line with each feature's actual contribution, rather than with the arbitrary scale of the input column.
# MAGIC
# MAGIC <svg viewBox="0 0 720 520" xmlns="http://www.w3.org/2000/svg" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <rect width="720" height="520" fill="white"/>
# MAGIC   <text x="200" y="30" text-anchor="middle" font-size="12" font-weight="700" fill="#1B3139">Learned Coefficient</text>
# MAGIC   <text x="540" y="30" text-anchor="middle" font-size="12" font-weight="700" fill="#1B3139">L2 Penalty Contribution (share of total)</text>
# MAGIC   <line x1="360" y1="44" x2="360" y2="480" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <line x1="40" y1="262" x2="700" y2="262" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="24" y="160" text-anchor="middle" font-size="10.5" font-weight="700" fill="#FF6B6B" transform="rotate(-90,24,160)">BEFORE standardization</text>
# MAGIC   <text x="210" y="62" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Raw coefficients — wildly different scales</text>
# MAGIC   <text x="138" y="89.0" text-anchor="end" font-size="9.5" fill="#618794">Sq. Footage</text>
# MAGIC   <rect x="144" y="70" width="0.6" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="150.6" y="89.0" font-size="9.5" font-weight="bold" fill="#444">$150</text>
# MAGIC   <text x="138" y="135.0" text-anchor="end" font-size="9.5" fill="#618794">House Age</text>
# MAGIC   <rect x="144" y="116" width="3.2" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="153.2" y="135.0" font-size="9.5" font-weight="bold" fill="#444">$800</text>
# MAGIC   <text x="138" y="181.0" text-anchor="end" font-size="9.5" fill="#618794">Bedrooms</text>
# MAGIC   <rect x="144" y="162" width="140.0" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="290.0" y="181.0" font-size="9.5" font-weight="bold" fill="#444">$35,000</text>
# MAGIC   <text x="550" y="62" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Penalty falls almost entirely on Bedrooms</text>
# MAGIC   <text x="478" y="89.0" text-anchor="end" font-size="9.5" fill="#618794">Sq. Footage</text>
# MAGIC   <rect x="484" y="70" width="0.6" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="490.6" y="89.0" font-size="9.5" font-weight="bold" fill="#444">0.00%</text>
# MAGIC   <text x="478" y="135.0" text-anchor="end" font-size="9.5" fill="#618794">House Age</text>
# MAGIC   <rect x="484" y="116" width="0.6" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="490.6" y="135.0" font-size="9.5" font-weight="bold" fill="#444">0.05%</text>
# MAGIC   <text x="478" y="181.0" text-anchor="end" font-size="9.5" fill="#618794">Bedrooms</text>
# MAGIC   <rect x="484" y="162" width="139.9" height="30" rx="3" fill="#FF6B6B" opacity="0.9"/>
# MAGIC   <text x="629.9" y="181.0" font-size="9.5" font-weight="bold" fill="#444">100%</text>
# MAGIC   <text x="24" y="378" text-anchor="middle" font-size="10.5" font-weight="700" fill="#4ECDC4" transform="rotate(-90,24,378)">AFTER standardization</text>
# MAGIC   <text x="210" y="280" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Coefficients now comparable</text>
# MAGIC   <text x="138" y="307.0" text-anchor="end" font-size="9.5" fill="#618794">Sq. Footage</text>
# MAGIC   <rect x="144" y="288" width="140.0" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="290.0" y="307.0" font-size="9.5" font-weight="bold" fill="#444">1.35</text>
# MAGIC   <text x="138" y="353.0" text-anchor="end" font-size="9.5" fill="#618794">House Age</text>
# MAGIC   <rect x="144" y="334" width="15.6" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="165.6" y="353.0" font-size="9.5" font-weight="bold" fill="#444">0.15</text>
# MAGIC   <text x="138" y="399.0" text-anchor="end" font-size="9.5" fill="#618794">Bedrooms</text>
# MAGIC   <rect x="144" y="380" width="46.7" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="196.7" y="399.0" font-size="9.5" font-weight="bold" fill="#444">0.45</text>
# MAGIC   <text x="550" y="280" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Penalty tracks predictive value, not scale</text>
# MAGIC   <text x="478" y="307.0" text-anchor="end" font-size="9.5" fill="#618794">Sq. Footage</text>
# MAGIC   <rect x="484" y="288" width="124.6" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="614.6" y="307.0" font-size="9.5" font-weight="bold" fill="#444">89%</text>
# MAGIC   <text x="478" y="353.0" text-anchor="end" font-size="9.5" fill="#618794">House Age</text>
# MAGIC   <rect x="484" y="334" width="1.5" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="491.5" y="353.0" font-size="9.5" font-weight="bold" fill="#444">1%</text>
# MAGIC   <text x="478" y="399.0" text-anchor="end" font-size="9.5" fill="#618794">Bedrooms</text>
# MAGIC   <rect x="484" y="380" width="13.8" height="30" rx="3" fill="#4ECDC4" opacity="0.9"/>
# MAGIC   <text x="503.8" y="399.0" font-size="9.5" font-weight="bold" fill="#444">10%</text>
# MAGIC </svg>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. When Standardization Is Required

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Models Sensitive vs. Robust to Feature Scale
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Sensitive to scale → standardize</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Robust to scale → optional</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Linear / logistic regression (regularized)</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Decision Trees</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Support Vector Machines (SVM)</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Random Forests</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">K-Nearest Neighbors (KNN)</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Gradient-Boosted Trees</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Neural Networks</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Ensemble Models</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">K-Means clustering</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Principal Component Analysis (PCA)</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### B2. Signs You Need to Standardize
# MAGIC
# MAGIC Look for features that vary in **magnitude** by one or more orders of magnitude. Concrete signals include:
# MAGIC
# MAGIC - **Feature scale disparities** — `MonthlyCharges` ($20-$120) alongside `tenure` (0-72 months). The model will weight one far more than the other if you don't scale.
# MAGIC - **Gradient-based optimizers running slowly** — large condition numbers slow convergence.
# MAGIC - **Distance-based methods (KNN, K-Means) giving counter-intuitive neighbors** — usually one dominant-scale column hijacking the distance metric.
# MAGIC - **Regularized linear models penalizing the wrong features** — small-scale features accumulate large coefficients and get over-penalised by L1/L2.

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. The Standardization Process in Spark ML

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. Process Overview
# MAGIC
# MAGIC The diagram below shows the correct order of operations. Following this sequence avoids data leakage — a critical concern when fitting any preprocessing stage.
# MAGIC
# MAGIC <div class="stp-wrap">
# MAGIC <style>
# MAGIC .stp-wrap { font-family: sans-serif; max-width: 1000px; margin: 16px auto; color: #0b2026; }
# MAGIC .stp-wrap * { box-sizing: border-box; }
# MAGIC .stp-track { display: flex; align-items: center; justify-content: space-between; position: relative; margin: 8px 0 22px; }
# MAGIC .stp-track::before { content: ""; position: absolute; top: 22px; left: 22px; right: 22px; height: 3px; background: #E4E7E9; z-index: 0; }
# MAGIC .stp-node { position: relative; z-index: 1; display: flex; flex-direction: column; align-items: center; gap: 8px; cursor: pointer; flex: 1; }
# MAGIC .stp-dot { width: 44px; height: 44px; border-radius: 50%; background: #FFFFFF; border: 3px solid #C7CFD3; color: #5E7077; font-size: 15pt; font-weight: 800; display: flex; align-items: center; justify-content: center; transition: all 0.2s; }
# MAGIC .stp-node.done .stp-dot { background: #00A972; border-color: #00A972; color: #fff; }
# MAGIC .stp-node.active .stp-dot { background: #00A972; border-color: #00A972; color: #fff; box-shadow: 0 0 0 5px rgba(0,169,114,0.20); }
# MAGIC .stp-label { font-size: 12pt; font-weight: 700; color: #5E7077; text-align: center; max-width: 130px; line-height: 1.3; }
# MAGIC .stp-node.active .stp-label { color: #00794F; }
# MAGIC .stp-nav { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
# MAGIC .stp-btn { font-size: 14pt; font-weight: 700; padding: 8px 20px; border-radius: 8px; border: 1px solid #DCE0E2; background: #FFFFFF; color: #1B3139; cursor: pointer; }
# MAGIC .stp-btn:hover { background: #F8F9FC; }
# MAGIC .stp-counter { font-size: 13pt; font-weight: 700; color: #5E7077; }
# MAGIC .stp-body { background: #FFFFFF; border: 1px solid #DCE0E2; border-radius: 12px; border-left: 6px solid #00A972; padding: 20px 24px; box-shadow: 0 2px 10px rgba(27,49,57,0.06); }
# MAGIC .stp-title { font-size: 15pt; font-weight: 800; margin-bottom: 10px; }
# MAGIC .stp-content { font-size: 13pt; line-height: 1.6; }
# MAGIC .stp-content ul { margin: 8px 0 0; padding-left: 20px; }
# MAGIC .stp-content li { margin-bottom: 6px; }
# MAGIC .stp-code { background: #272822; color: #F8F8F2; font-family: Menlo, Consolas, monospace; font-size: 13pt; border-radius: 8px; padding: 12px 16px; margin-top: 12px; white-space: pre; overflow-x: auto; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="stp-track" id="stp-track"></div>
# MAGIC <div class="stp-nav">
# MAGIC   <button class="stp-btn" id="stp-back">&#8592; Back</button>
# MAGIC   <button class="stp-btn" id="stp-next">Next &#8594;</button>
# MAGIC   <span class="stp-counter" id="stp-counter"></span>
# MAGIC </div>
# MAGIC <div class="stp-body" id="stp-body"></div>
# MAGIC
# MAGIC <script>
# MAGIC (function () {
# MAGIC   var STEPS = [
# MAGIC     {
# MAGIC       label: "Assess",
# MAGIC       title: "Assess distributions & decide which features need scaling",
# MAGIC       body: "<p>Review feature distributions and identify those with large scale disparities or skew. Only scale features where necessary to avoid unnecessary transformation.</p>"
# MAGIC     },
# MAGIC     {
# MAGIC       label: "Split",
# MAGIC       title: "Split train / test (so the scaler never sees test data)",
# MAGIC       body: "<p>Divide your dataset into training and test sets <b>before</b> fitting any scaler. This prevents data leakage and ensures honest evaluation.</p>"
# MAGIC     },
# MAGIC     {
# MAGIC       label: "Build",
# MAGIC       title: "Build a Spark ML pipeline with a Scaler stage",
# MAGIC       body: "<p>Construct a pipeline that includes a scaler (e.g., StandardScaler, MinMaxScaler, RobustScaler) after assembling numeric features. This ensures consistent preprocessing.</p>"
# MAGIC     },
# MAGIC     {
# MAGIC       label: "Fit & Transform",
# MAGIC       title: "Fit the pipeline on TRAIN → transform TRAIN and TEST",
# MAGIC       body: "<p>Fit the pipeline (including the scaler) <b>only</b> on the training set. Then use the fitted pipeline to transform both train and test sets.</p>"
# MAGIC     },
# MAGIC     {
# MAGIC       label: "Persist (Optional)",
# MAGIC       title: "Persist the fitted features via Feature Engineering in Unity Catalog",
# MAGIC       body: "<p>Optionally, save the transformed features for downstream use, reproducibility, or sharing across teams.</p>"
# MAGIC     }
# MAGIC   ];
# MAGIC   var idx = 0;
# MAGIC   var track = document.getElementById("stp-track");
# MAGIC   var body = document.getElementById("stp-body");
# MAGIC   var counter = document.getElementById("stp-counter");
# MAGIC
# MAGIC   STEPS.forEach(function (s, i) {
# MAGIC     var node = document.createElement("div");
# MAGIC     node.className = "stp-node";
# MAGIC     node.innerHTML = '<div class="stp-dot">' + (i + 1) + '</div><div class="stp-label">' + s.label + '</div>';
# MAGIC     node.onclick = function () { idx = i; render(); };
# MAGIC     track.appendChild(node);
# MAGIC   });
# MAGIC
# MAGIC   function render() {
# MAGIC     track.querySelectorAll(".stp-node").forEach(function (n, i) {
# MAGIC       n.classList.toggle("active", i === idx);
# MAGIC       n.classList.toggle("done", i < idx);
# MAGIC     });
# MAGIC     var s = STEPS[idx];
# MAGIC     counter.textContent = "STEP " + (idx + 1) + " of " + STEPS.length;
# MAGIC     body.innerHTML = '<div class="stp-title">' + s.title + '</div><div class="stp-content">' + s.body + (s.code ? '<div class="stp-code">' + s.code + '</div>' : '') + '</div>';
# MAGIC   }
# MAGIC
# MAGIC   document.getElementById("stp-back").onclick = function () { idx = (idx - 1 + STEPS.length) % STEPS.length; render(); };
# MAGIC   document.getElementById("stp-next").onclick = function () { idx = (idx + 1) % STEPS.length; render(); };
# MAGIC   render();
# MAGIC })();
# MAGIC </script>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #FFAB00; background: rgba(255,171,0,0.12); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#0b2026; margin-bottom:6px; font-size:15pt;">Warning</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Never fit the scaler on the full dataset or test set.</b> This leaks information from the test set into training, causing your model to look better than it really is. Always fit the scaler <b>only on the training set</b> to avoid data leakage and ensure honest evaluation.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. Three Spark ML Scalers
# MAGIC
# MAGIC Spark ML scalers all take a **vector column** as input, so you must first assemble the columns to scale into a single vector using `VectorAssembler`.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Scaler</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What it does</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Spark ML class</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">StandardScaler</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Mean 0, std 1 (z-score)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>pyspark.ml.feature.StandardScaler</code></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">MinMaxScaler</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Scale to [0, 1]</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>pyspark.ml.feature.MinMaxScaler</code></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">RobustScaler</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Center on median, scale by IQR — outlier-resistant</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>pyspark.ml.feature.RobustScaler</code></td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <div style="border-left: 4px solid #FFAB00; background: rgba(255,171,0,0.12); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#0b2026; margin-bottom:6px; font-size:15pt;">Warning</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Spark's StandardScaler defaults differ from scikit-learn.</b><br>
# MAGIC     By default, <code>StandardScaler</code> in Spark ML uses <code>withMean=False</code> and <code>withStd=True</code>, so it <b>scales by standard deviation only</b> and does <b>not</b> center the data. This is different from scikit-learn, which centers and scales by default.<br><br>
# MAGIC     <b>Why?</b> Centering a sparse vector makes it dense, which can cause memory issues for high-dimensional data. If your features are dense (typical for tabular ML), set <code>withMean=True</code> to get classic z-score scaling: <em>z = (x − μ) / σ</em>.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C3. Where Standardization Fits in the Demo Pipeline
# MAGIC
# MAGIC The demo wires these stages into a single `Pipeline`. Standardization sits **after imputation** and **before final assembly**:
# MAGIC
# MAGIC <br>
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1000px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .lf-card { max-width: 1200px; width: 100%; background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); padding: 18px 22px; position: relative; box-sizing: border-box; color: #0b2026; }
# MAGIC .lf-card::before { content: ""; position: absolute; top: 0; left: 0; width: 100%; height: 8px; background: #1B5162; border-top-left-radius: 8px; border-top-right-radius: 8px; }
# MAGIC .lf-card-label { font-weight: 700; font-size: 14pt; letter-spacing: 2px; text-transform: uppercase; color: #1B5162; margin-top: 6px; }
# MAGIC .lf-card-title { font-size: 16pt; font-weight: 700; color: #0b2026; margin: 2px 0 6px 0; line-height: 1.3; }
# MAGIC .lf-card-sub { font-size: 14pt; color: #5E7077; line-height: 1.5; margin-bottom: 10px; }
# MAGIC .lf-diagram { background: #FFFFFF; border-radius: 6px; padding: 16px; margin: 10px 0 0; display: flex; justify-content: center; align-items: center; }
# MAGIC .lf-diagram svg { width: 100%; height: auto; max-width: 1100px; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="lf-card">
# MAGIC <div class="lf-card-label">Pipeline</div>
# MAGIC <div class="lf-card-title">Standardization Pipeline Flow</div>
# MAGIC <div class="lf-card-sub">Stages are ordered to prevent data leakage and ensure correct feature engineering.</div>
# MAGIC <div class="lf-diagram">
# MAGIC <svg viewBox="0 0 960 360" xmlns="http://www.w3.org/2000/svg" font-family="sans-serif">
# MAGIC <defs>
# MAGIC <marker id="lf-arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto">
# MAGIC   <path d="M 0 0 L 10 5 L 0 10 z" fill="#4299E0"/>
# MAGIC </marker>
# MAGIC </defs>
# MAGIC <!-- Horizontal pipeline stages -->
# MAGIC <rect x="40" y="60" width="150" height="70" rx="8" fill="#FFFFFF" stroke="#4299E0" stroke-width="2"/>
# MAGIC <rect x="40" y="60" width="150" height="8" fill="#4299E0"/>
# MAGIC <text x="115" y="90" text-anchor="middle" font-size="13" font-weight="700" fill="#4299E0" letter-spacing="1.5">StringIndexer</text>
# MAGIC <text x="115" y="115" text-anchor="middle" font-size="11" fill="#5E7077">Categorical encoding</text>
# MAGIC
# MAGIC <rect x="220" y="60" width="170" height="70" rx="8" fill="#FFFFFF" stroke="#00A972" stroke-width="2"/>
# MAGIC <rect x="220" y="60" width="170" height="8" fill="#00A972"/>
# MAGIC <text x="305" y="90" text-anchor="middle" font-size="13" font-weight="700" fill="#00A972" letter-spacing="1.5">OneHotEncoder</text>
# MAGIC <text x="305" y="115" text-anchor="middle" font-size="11" fill="#5E7077">One-hot vectors</text>
# MAGIC
# MAGIC <rect x="420" y="60" width="120" height="70" rx="8" fill="#FFFFFF" stroke="#FFAB00" stroke-width="2"/>
# MAGIC <rect x="420" y="60" width="120" height="8" fill="#FFAB00"/>
# MAGIC <text x="480" y="90" text-anchor="middle" font-size="13" font-weight="700" fill="#FFAB00" letter-spacing="1.5">Imputer</text>
# MAGIC <text x="480" y="115" text-anchor="middle" font-size="11" fill="#5E7077">Fill missing values</text>
# MAGIC
# MAGIC <rect x="570" y="60" width="180" height="70" rx="8" fill="#FFFFFF" stroke="#2272B4" stroke-width="2"/>
# MAGIC <rect x="570" y="60" width="180" height="8" fill="#2272B4"/>
# MAGIC <text x="660" y="90" text-anchor="middle" font-size="13" font-weight="700" fill="#2272B4" letter-spacing="1.5">VectorAssembler</text>
# MAGIC <text x="660" y="115" text-anchor="middle" font-size="11" fill="#618794">(numeric)</text>
# MAGIC
# MAGIC <!-- Horizontal arrows -->
# MAGIC <line x1="190" y1="95" x2="220" y2="95" stroke="#4299E0" stroke-width="2" marker-end="url(#lf-arrow)"/>
# MAGIC <line x1="390" y1="95" x2="420" y2="95" stroke="#00A972" stroke-width="2" marker-end="url(#lf-arrow)"/>
# MAGIC <line x1="540" y1="95" x2="570" y2="95" stroke="#FFAB00" stroke-width="2" marker-end="url(#lf-arrow)"/>
# MAGIC
# MAGIC <!-- Down arrow to StandardScaler -->
# MAGIC <line x1="660" y1="130" x2="660" y2="180" stroke="#FF3621" stroke-width="2" marker-end="url(#lf-arrow)"/>
# MAGIC
# MAGIC <rect x="570" y="180" width="180" height="60" rx="8" fill="#FFFFFF" stroke="#FF3621" stroke-width="2"/>
# MAGIC <rect x="570" y="180" width="180" height="8" fill="#FF3621"/>
# MAGIC <text x="660" y="205" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621" letter-spacing="1.5">StandardScaler</text>
# MAGIC <text x="660" y="225" text-anchor="middle" font-size="11" fill="#5E7077">Standardize numeric vector</text>
# MAGIC
# MAGIC <!-- Down arrow to VectorAssembler (all_features) -->
# MAGIC <line x1="660" y1="240" x2="660" y2="280" stroke="#2272B4" stroke-width="2" marker-end="url(#lf-arrow)"/>
# MAGIC
# MAGIC <rect x="570" y="280" width="180" height="60" rx="8" fill="#FFFFFF" stroke="#2272B4" stroke-width="2"/>
# MAGIC <rect x="570" y="280" width="180" height="8" fill="#2272B4"/>
# MAGIC <text x="660" y="305" text-anchor="middle" font-size="13" font-weight="700" fill="#2272B4" letter-spacing="1.5">VectorAssembler</text>
# MAGIC <text x="660" y="325" text-anchor="middle" font-size="11" fill="#618794">(all_features)</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC This ordering is intentional:
# MAGIC
# MAGIC - **Encode before assembling** — the assembler concatenates encoded vectors with scaled numeric vectors
# MAGIC - **Impute before scaling** — the scaler cannot compute statistics on `null` values
# MAGIC - **Scale only the numeric vector**, then concatenate with the one-hot vectors at the end

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Drawbacks and Trade-offs

# COMMAND ----------

# MAGIC %md
# MAGIC ### D1. Loss of Original Interpretation
# MAGIC
# MAGIC After standardization, "tenure = 1.4" no longer means "1.4 months." If business stakeholders need to read the model's inputs directly — for example, for compliance review — keep an unscaled copy of the data alongside the scaled one, or **inverse-transform** scaled values before display.

# COMMAND ----------

# MAGIC %md
# MAGIC ### D2. Sensitivity to Outliers (for Z-score)
# MAGIC
# MAGIC Standard `StandardScaler` (mean / std) assumes the feature is roughly symmetric. For heavily skewed columns or outlier-heavy distributions, prefer one of the following alternatives:
# MAGIC
# MAGIC - **`RobustScaler`** — uses median and IQR, making it resistant to outliers
# MAGIC - **Log-transform first**, then standardize
# MAGIC - **`MinMaxScaler`** when you need a bounded range (e.g., for neural network inputs) — but note that MinMaxScaler is itself highly sensitive to outliers, since a single extreme value compresses all other data into a narrow band

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the key concepts and techniques for bringing numeric features onto a comparable scale before model training:
# MAGIC
# MAGIC 1. **What Standardization Is and Why It Matters** — standardization transforms features to a consistent scale (most commonly z-scores: mean 0, std 1). This enables direct coefficient comparison, prevents large-magnitude features from dominating the loss, speeds gradient descent convergence, and makes regularization penalties fair across features.
# MAGIC 2. **When Standardization Is Required** — distance-based and gradient-based models (linear regression, SVM, KNN, neural networks, K-Means, PCA) require standardization; tree-based models and ensemble methods are robust to scale and do not. Look for features that differ by orders of magnitude as a concrete signal.
# MAGIC 3. **The Standardization Process in Spark ML** — three scalers (`StandardScaler`, `MinMaxScaler`, `RobustScaler`) each suit different distribution shapes. The scaler must be fit on training data only — fitting on the full dataset leaks test-set statistics into training.
# MAGIC 4. **Drawbacks and Trade-offs** — standardization removes the original units from features ("tenure = 1.4" no longer means months), complicates interpretation of interaction terms, and z-score scaling assumes approximate symmetry. Use `RobustScaler` or log-transforms for skewed or outlier-heavy columns.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>