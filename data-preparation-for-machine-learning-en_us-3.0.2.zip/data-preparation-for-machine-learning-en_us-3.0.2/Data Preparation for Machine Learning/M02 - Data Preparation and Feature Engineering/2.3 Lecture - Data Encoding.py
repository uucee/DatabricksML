# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Lecture — Data Encoding
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This lecture covers the following five sections that build on each other:
# MAGIC
# MAGIC - **A. Why Encoding Matters for ML**. Why most algorithms need numerical input, the three recurring categorical-feature challenges (high cardinality, missing values, string types), and practical solutions for each
# MAGIC - **B. One-Hot Encoding**. How it works, its drawbacks at high cardinality, and how to apply it in Spark ML with `StringIndexer` → `OneHotEncoder`
# MAGIC - **C. Label and Target Encoding**. Label encoding for ordinal features, target encoding for high-cardinality categoricals, and the risks of each approach
# MAGIC - **D. Embeddings**. What embeddings are, how they are produced, and how categorical embeddings transform discrete categories into dense, semantic vector representations
# MAGIC - **E. Conclusion**. Summary of when to use each encoding method and key takeaways
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Explain why most ML algorithms require numerical input and why encoding categorical features is essential
# MAGIC - Identify and address the three main categorical-feature challenges: high cardinality, missing values, and string types
# MAGIC - Apply one-hot, label, and target encoding appropriately depending on feature type, cardinality, and model requirements
# MAGIC - Use Spark ML's `StringIndexer` and `OneHotEncoder` together in a pipeline with `handleInvalid="keep"`
# MAGIC - Recognize when categorical embeddings outperform classical encodings and describe the embedding lookup process
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Why Encoding Matters for ML

# COMMAND ----------

# MAGIC %md
# MAGIC ### A1. Most Algorithms Need Numbers
# MAGIC
# MAGIC The vast majority of ML algorithms — linear models, gradient boosting, neural networks — accept **numerical input only**. Categorical features like `Contract = "Month-to-month"` or `City = "Paris"` must be converted to numbers before training.
# MAGIC
# MAGIC The sections below cover three encoding families — one-hot, label/target, and embeddings — each suited to different feature types and model requirements.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A2. Three Categorical-Feature Challenges
# MAGIC
# MAGIC Categorical features present three recurring challenges in ML workflows. The table below summarizes each challenge, why it's difficult, and where it is typically addressed.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">The challenge</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">The issue</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">The solution</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">High cardinality</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Many unique values in a categorical feature can lead to increased dimensionality and potential overfitting.</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Group rare categories, top-N selection, target encoding, embeddings</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Missing values</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Categorical features often have missing values, which need to be addressed before model training</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Mode imputation, constant imputation, treat as a separate category</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">String types</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">ML models reject strings. Models require numerical input, and categorical variables need to be encoded.</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">One-hot encoding, label encoding, target encoding, embeddings</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A3. High Cardinality Issues and Solutions
# MAGIC
# MAGIC **Issue: Large set of categories**
# MAGIC
# MAGIC Many unique values in a categorical feature lead to large numbers of dummy variables, increased sparsity, and potential overfitting — especially when some categories appear only a few times.
# MAGIC
# MAGIC **Possible Solutions:**
# MAGIC
# MAGIC <div style="display: flex; gap: 32px; flex-wrap: wrap; margin: 16px 0;">
# MAGIC
# MAGIC <!-- Left table: Group Rare Categories -->
# MAGIC <div style="flex: 1; min-width: 300px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 320px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Group Rare Categories</div>
# MAGIC <table style="border-collapse: collapse; width: 320px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Category</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Count</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Grouped</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">1</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1200</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">2</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">980</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">870</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">12</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">8</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">6</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Rare categories (count &lt; threshold) are collapsed into a single group (0).</p>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Right table: Top-N Categories -->
# MAGIC <div style="flex: 1; min-width: 300px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 320px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Top-N Categories</div>
# MAGIC <table style="border-collapse: collapse; width: 320px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Category</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Count</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Kept?</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">1</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1200</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 600; color: #00A972;">✓ Top 3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">2</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">980</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 600; color: #00A972;">✓ Top 3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">870</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 600; color: #00A972;">✓ Top 3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">12</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">✗ Dropped</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">8</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">✗ Dropped</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">6</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">✗ Dropped</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Only the top-N most frequent categories are kept; the rest are removed or masked.</p>
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A4. Missing Values Issues and Solutions
# MAGIC
# MAGIC **Issue: Categorical gaps**
# MAGIC
# MAGIC Categorical features often contain missing values which need to be converted to numbers before model training. Unlike numeric columns, you cannot simply compute a mean — you need a strategy that respects the discrete nature of the data.
# MAGIC
# MAGIC **Possible Solutions:**
# MAGIC
# MAGIC <div style="display: flex; gap: 32px; flex-wrap: wrap; margin: 16px 0;">
# MAGIC
# MAGIC <!-- Left table: Imputation -->
# MAGIC <div style="flex: 1; min-width: 300px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 320px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Imputation</div>
# MAGIC <table style="border-collapse: collapse; width: 320px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">ID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Value</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Imputed</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">7</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">7</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">NaN</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">NaN</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">3</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Replace missing values with the mode (most frequent value) or a constant.</p>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Right table: Consider Missing as a Separate Category -->
# MAGIC <div style="flex: 1; min-width: 300px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 320px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Missing as a Separate Category</div>
# MAGIC <table style="border-collapse: collapse; width: 320px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">ID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Value</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Filled</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">7</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">7</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">NaN</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">-1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; color: #618794;">NaN</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">-1</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Treat missingness as informative — encode it as a new numeric category (−1).</p>
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A5. Encoding Issues and Solutions
# MAGIC
# MAGIC **Issue: String types**
# MAGIC
# MAGIC Models require numerical input, and categorical variables stored as strings must be converted to numbers before training. The choice of encoding method depends on the nature of the categories and the model being used.
# MAGIC
# MAGIC **Possible Solutions:**
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 16px 0;">
# MAGIC
# MAGIC <!-- Left table: One-Hot Encoding -->
# MAGIC <div style="flex: 1; min-width: 240px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 300px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">One-Hot Encoding</div>
# MAGIC <table style="border-collapse: collapse; width: 300px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">City</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">NY</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Paris</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">London</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">London</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">One binary column per category. No ordinal relationship implied.</p>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Middle table: Label Encoding -->
# MAGIC <div style="flex: 1; min-width: 200px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 240px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Label Encoding</div>
# MAGIC <table style="border-collapse: collapse; width: 240px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">City</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Label</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">London</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">2</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Each category gets a unique integer. Simple but may imply false ordering.</p>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Right table: Ordinal Encoding -->
# MAGIC <div style="flex: 1; min-width: 200px; display: flex; flex-direction: column; align-items: center; text-align: center;">
# MAGIC <div style="width: 240px; text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 15px;">Ordinal Encoding</div>
# MAGIC <table style="border-collapse: collapse; width: 240px; margin: 0 auto; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Size</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 10px 12px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Ordinal</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Small</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Medium</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">2</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Large</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">3</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Small</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Large</strong></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 10px 12px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">3</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Like label encoding, but the order is meaningful (Small &lt; Medium &lt; Large).</p>
# MAGIC </div>
# MAGIC
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. One-Hot Encoding

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. How It Works
# MAGIC
# MAGIC One-hot encoding adds **one binary column per category**. Each row has a `1` in exactly one column and `0` in the rest.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 680px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">ID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">City</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">New York</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Paris</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">London</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">London</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">5</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md
# MAGIC ### B2. Drawbacks
# MAGIC
# MAGIC While one-hot encoding is widely used, it introduces several practical limitations:
# MAGIC
# MAGIC - **Sparsity and memory overhead** — most entries are zero, inflating dataset size
# MAGIC - **Poor scaling with cardinality** — feature space explodes as the number of categories grows
# MAGIC - **Obscured feature importance** — a single concept is split across many columns

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B3. In Spark ML: `StringIndexer` → `OneHotEncoder`
# MAGIC
# MAGIC Spark ML one-hot encoding is a **two-step** process:
# MAGIC
# MAGIC 1. **`StringIndexer`** — converts strings to numeric indices (`"Month-to-month"` → `0.0`, `"One year"` → `1.0`, …)
# MAGIC 2. **`OneHotEncoder`** — converts those indices to sparse binary vectors
# MAGIC
# MAGIC <div style="border-left: 4px solid #4299E0; background: rgba(66,153,224,0.10); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#2272B4; margin-bottom:6px; font-size:15pt;">Info</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <code>handleInvalid="keep"</code> is a key option for robust pipelines. It tells <code>StringIndexer</code> and <code>OneHotEncoder</code> to assign a special index for any category (including nulls) that appears at transform time but was not seen during training. This prevents errors and ensures your model can handle new or missing values gracefully—especially important in production or when scoring on unseen data.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #FFAB00; background: rgba(255,171,0,0.12); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#0b2026; margin-bottom:6px; font-size:15pt;">Warning</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <code>OneHotEncoder</code> drops the last binary column by default (<code>dropLast=True</code>). For a feature with 3 categories, only 2 columns are output—the third is implied when both are zero. This prevents perfect multicollinearity (the "dummy variable trap").<br><br>
# MAGIC     <b>Be careful:</b> If your model requires all categories to be explicit (e.g., tree-based models), set <code>dropLast=False</code>. Otherwise, you may lose information or misinterpret results.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Label and Target Encoding

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. Label Encoding (String Indexing)
# MAGIC
# MAGIC `StringIndexer` assigns each category an integer **by frequency** — the most common category gets index 0, the next most common gets 1, and so on. The indices have no ordinal meaning.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 600px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">ID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Contract</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">→</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Contract_idx</th>
# MAGIC       <th style="padding: 12px 16px; text-align: center; color: #ffffff; border-bottom: 3px solid #FF3621;">Why this index?</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Month-to-month</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-size: 12px; color: #618794;">Most frequent</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">One year</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-size: 12px; color: #618794;">2nd most frequent</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">3</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Two year</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">2</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-size: 12px; color: #618794;">Least frequent</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;">4</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Month-to-month</strong></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0</td>
# MAGIC       <td style="padding: 12px 16px; text-align: center; border-bottom: 1px solid #E8E8E8; font-size: 12px; color: #618794;">Same as row 1</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <details style="margin: 8px 0;">
# MAGIC <summary style="background: linear-gradient(135deg, #1B3139, #2272B4); color: white; padding: 10px 16px; cursor: pointer; font-weight: 600; font-size: 13pt; border-radius: 8px; user-select: none;">
# MAGIC When to use / not use StringIndexer for label encoding
# MAGIC </summary>
# MAGIC <div style="border: 2px solid #1B3139; border-top: none; border-radius: 0 0 8px 8px; padding: 12px 16px; background: #F9F7F4; font-size: 13pt; line-height: 1.6; color: #333;">
# MAGIC <ul style="margin: 4px 0 0 16px;">
# MAGIC <li><strong>When to use</strong> — In Spark ML, this is standard practice for nominal features fed into tree-based models such as Random Forest and GBT. Trees split on thresholds, so this approach is commonly used in Spark pipelines even though the labels are assigned arbitrarily.</li>
# MAGIC <li><strong>Important nuance</strong> — The encoded integers still impose an arbitrary numeric ordering, so this guidance is specific to Spark ML tree-model workflows and should not be generalized to sklearn-style pipelines or libraries with native categorical handling.</li>
# MAGIC <li><strong>When NOT to use</strong> — Linear models will infer a numeric relationship between indices (0 &lt; 1 &lt; 2) that doesn't exist. Outside Spark ML, other tree libraries may prefer one-hot encoding or native categorical support instead.</li>
# MAGIC </ul>
# MAGIC </div>
# MAGIC </details>
# MAGIC <div style="border-left: 4px solid #FFAB00; background: rgba(255,171,0,0.12); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#0b2026; margin-bottom:6px; font-size:15pt;">Warning</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Ordinal encoding is <u>not</u> handled by StringIndexer.</b><br>
# MAGIC     If your categories have a true order (e.g., Freshman &lt; Sophomore &lt; Junior &lt; Senior), <b>do not use StringIndexer</b>—it assigns indices by frequency, not order. You must map ordered categories manually (e.g., with <code>when().otherwise()</code> or a mapping DataFrame). Using StringIndexer here can mislead your model and invalidate results.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. Target Encoding
# MAGIC
# MAGIC Target encoding replaces each category with the **mean of the target variable** for all rows belonging to that category.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 540px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">City</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Target (Clicked)</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Mean</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">New York</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">[1, 0]</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0.5</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Paris</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">[0, 1]</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">0.5</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">London</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">[1]</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; font-weight: 700; color: #FF3621;">1.0</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <div style="border-left: 4px solid #FFAB00; background: rgba(255,171,0,0.12); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#0b2026; margin-bottom:6px; font-size:15pt;">Warning</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Target leakage is a critical risk with target encoding.</b><br>
# MAGIC     Never compute category means using the full dataset (including validation or test data)—this leaks future information into your training features and invalidates model evaluation. <br>
# MAGIC     <b>Always compute means on the training set only</b>, then apply those means to validation and test sets. For categories not seen during training, use the global training-set target mean as a fallback.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC **Other drawbacks:**
# MAGIC - **Overfitting risk** — small categories yield over-confident mean estimates
# MAGIC - **Target distribution dependency** — concept drift in the target invalidates stored means
# MAGIC
# MAGIC <div style="border-left: 4px solid #1B5162; background: #F8F9FC; padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#1B5162; margin-bottom:6px; font-size:15pt;">Note</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     Spark ML does <b>not</b> provide a built-in <code>TargetEncoder</code> transformer. To apply target encoding, compute per-category means on your training set, save them, and join to your features using <code>withColumn</code> or a lookup table. This manual approach ensures you avoid target leakage and maintain proper separation between training and validation/test data.
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Embeddings

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. What Embeddings Are
# MAGIC
# MAGIC **Embeddings** are dense, low-dimensional vector representations of data. Unlike one-hot encoding's sparse, high-dimensional binary vectors, embeddings place **similar items close together** in a continuous vector space.
# MAGIC
# MAGIC Embeddings are used widely in **text, categorical features, images, and audio**. The table below contrasts one-hot and embedding representations for a small product catalog:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Item</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">One-Hot Vector</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Embedding Vector</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Note</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">TV</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[1, 0, 0, 0]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0.5, 1.2, -0.8]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Laptop</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0, 1, 0, 0]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0.6, 1.1, -0.7]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Close to TV in embedding space</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Book</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0, 0, 1, 0]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0.2, -0.4, 1.5]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Mug</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0, 0, 0, 1]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>[0.7, -0.5, 0.4]</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Dimensions</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">4 — one per category</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">3 — fixed regardless of catalog size</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Embeddings scale better with cardinality</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The scatter plot below shows how embeddings place **similar items close together** in a 2D projection of the vector space. TV and Laptop (both electronics with screens) cluster nearby, while Book and Mug occupy distinct regions.
# MAGIC
# MAGIC <div style="max-width: 500px; margin: 24px auto;">
# MAGIC <svg width="100%" viewBox="0 0 460 360" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>Embedding Space Visualization</title>
# MAGIC   <desc>TV and Laptop are close together in embedding space; Book and Mug are far apart</desc>
# MAGIC
# MAGIC   <!-- Background -->
# MAGIC   <rect x="40" y="20" width="400" height="300" rx="8" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC
# MAGIC   <!-- Grid lines -->
# MAGIC   <line x1="140" y1="20" x2="140" y2="320" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC   <line x1="240" y1="20" x2="240" y2="320" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC   <line x1="340" y1="20" x2="340" y2="320" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC   <line x1="40" y1="95" x2="440" y2="95" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC   <line x1="40" y1="170" x2="440" y2="170" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC   <line x1="40" y1="245" x2="440" y2="245" stroke="#E8E8E8" stroke-width="0.5" stroke-dasharray="4 3"/>
# MAGIC
# MAGIC   <!-- Axes -->
# MAGIC   <line x1="40" y1="320" x2="440" y2="320" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <line x1="40" y1="20" x2="40" y2="320" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="240" y="348" text-anchor="middle" font-size="12" fill="#618794">Dimension 1</text>
# MAGIC   <text x="16" y="170" text-anchor="middle" font-size="12" fill="#618794" transform="rotate(-90, 16, 170)">Dimension 2</text>
# MAGIC
# MAGIC   <!-- Cluster highlight: TV + Laptop -->
# MAGIC   <ellipse cx="320" cy="80" rx="65" ry="45" fill="#2272B4" fill-opacity="0.08" stroke="#2272B4" stroke-width="1" stroke-dasharray="4 2"/>
# MAGIC
# MAGIC   <!-- TV point -->
# MAGIC   <circle cx="300" cy="70" r="8" fill="#FF3621" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="300" y="55" text-anchor="middle" font-size="13" font-weight="600" fill="#1B3139">TV</text>
# MAGIC
# MAGIC   <!-- Laptop point (close to TV) -->
# MAGIC   <circle cx="340" cy="90" r="8" fill="#FF3621" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="358" y="82" text-anchor="start" font-size="13" font-weight="600" fill="#1B3139">Laptop</text>
# MAGIC
# MAGIC   <!-- Book point (far from electronics) -->
# MAGIC   <circle cx="120" cy="220" r="8" fill="#2272B4" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="120" y="245" text-anchor="middle" font-size="13" font-weight="600" fill="#1B3139">Book</text>
# MAGIC
# MAGIC   <!-- Mug point (lower right: high dim1, low dim2) -->
# MAGIC   <circle cx="385" cy="235" r="8" fill="#00A972" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="385" y="258" text-anchor="middle" font-size="13" font-weight="600" fill="#1B3139">Mug</text>
# MAGIC
# MAGIC   <!-- Distance annotation -->
# MAGIC   <line x1="305" y1="73" x2="335" y2="87" stroke="#FF3621" stroke-width="1.5" stroke-dasharray="3 2"/>
# MAGIC   <text x="330" y="110" text-anchor="middle" font-size="11" fill="#618794" font-style="italic">close = similar</text>
# MAGIC
# MAGIC </svg>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D2. How Embeddings Are Produced
# MAGIC
# MAGIC Embeddings can be sourced in three ways. Once produced, they are typically persisted as features, indexed for similarity search, and served in real time.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Source</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Examples</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Learned during training</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Neural network embedding layers — common for recommendation systems and deep tabular models</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Pretrained models</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Word2Vec, FastText, sentence transformers, image encoders — pre-computed on large corpora</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Foundation model APIs</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Embedding endpoints on Databricks Model Serving</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC Once you have embeddings, the typical workflow is:
# MAGIC
# MAGIC 1. **Persist them as features** in Feature Engineering in Unity Catalog
# MAGIC 2. **Index them** in Databricks Vector Search for similarity lookups
# MAGIC 3. **Serve them in real time** via Feature Serving or Model Serving for downstream models

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### D3. Categorical Embedding
# MAGIC
# MAGIC **Transforming categorical variables into meaningful continuous vectors**
# MAGIC
# MAGIC Categorical embeddings replace standard encoding methods with learned dense vectors that capture relationships between categories automatically.
# MAGIC
# MAGIC **Steps:**
# MAGIC 1. Convert categorical variables to integer indices
# MAGIC 2. Pass through an embedding layer (a learned lookup table)
# MAGIC 3. The result is a dense vector representation for each category
# MAGIC
# MAGIC <div style="display: flex; align-items: center; gap: 8px; flex-wrap: wrap; max-width: 900px; margin: 24px auto;">
# MAGIC
# MAGIC <!-- Step 1: Categorical Input -->
# MAGIC <div style="flex: 0 0 auto;">
# MAGIC <svg width="150" viewBox="0 0 150 260" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="75" y="16" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Categorical Input</text>
# MAGIC   <rect x="5" y="24" width="140" height="220" rx="8" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="20" y="44" width="110" height="32" rx="4" fill="#ffffff" stroke="#2272B4" stroke-width="1.2"/>
# MAGIC   <text x="75" y="65" text-anchor="middle" font-size="12" font-weight="600" fill="#2272B4">New York</text>
# MAGIC   <rect x="20" y="86" width="110" height="32" rx="4" fill="#ffffff" stroke="#2272B4" stroke-width="1.2"/>
# MAGIC   <text x="75" y="107" text-anchor="middle" font-size="12" font-weight="600" fill="#2272B4">Paris</text>
# MAGIC   <rect x="20" y="128" width="110" height="32" rx="4" fill="#ffffff" stroke="#2272B4" stroke-width="1.2"/>
# MAGIC   <text x="75" y="149" text-anchor="middle" font-size="12" font-weight="600" fill="#2272B4">London</text>
# MAGIC   <rect x="20" y="170" width="110" height="32" rx="4" fill="#ffffff" stroke="#2272B4" stroke-width="1.2"/>
# MAGIC   <text x="75" y="191" text-anchor="middle" font-size="12" font-weight="600" fill="#2272B4">Toronto</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Arrow 1 -->
# MAGIC <div style="flex: 0 0 auto; font-size: 24px; color: #1B3139;">→</div>
# MAGIC
# MAGIC <!-- Step 2: Integer Indices -->
# MAGIC <div style="flex: 0 0 auto;">
# MAGIC <svg width="100" viewBox="0 0 100 260" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="50" y="16" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Index</text>
# MAGIC   <rect x="5" y="24" width="90" height="220" rx="8" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="15" y="44" width="70" height="32" rx="4" fill="#ffffff" stroke="#FF3621" stroke-width="1.2"/>
# MAGIC   <text x="50" y="65" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">0</text>
# MAGIC   <rect x="15" y="86" width="70" height="32" rx="4" fill="#ffffff" stroke="#FF3621" stroke-width="1.2"/>
# MAGIC   <text x="50" y="107" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">1</text>
# MAGIC   <rect x="15" y="128" width="70" height="32" rx="4" fill="#ffffff" stroke="#FF3621" stroke-width="1.2"/>
# MAGIC   <text x="50" y="149" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">2</text>
# MAGIC   <rect x="15" y="170" width="70" height="32" rx="4" fill="#ffffff" stroke="#FF3621" stroke-width="1.2"/>
# MAGIC   <text x="50" y="191" text-anchor="middle" font-size="13" font-weight="700" fill="#FF3621">3</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Arrow 2 -->
# MAGIC <div style="flex: 0 0 auto; font-size: 24px; color: #1B3139;">→</div>
# MAGIC
# MAGIC <!-- Step 3: Embedding Layer -->
# MAGIC <div style="flex: 0 0 auto;">
# MAGIC <svg width="140" viewBox="0 0 140 260" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="70" y="16" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Embedding Layer</text>
# MAGIC   <rect x="5" y="24" width="130" height="220" rx="8" fill="#2272B4" fill-opacity="0.08" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="70" y="50" text-anchor="middle" font-size="10" fill="#618794">(learned lookup table)</text>
# MAGIC   <rect x="15" y="62" width="110" height="26" rx="3" fill="#ffffff" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="70" y="80" text-anchor="middle" font-size="10" fill="#1B3139">idx 0 → [w₀₁, w₀₂, w₀₃]</text>
# MAGIC   <rect x="15" y="96" width="110" height="26" rx="3" fill="#ffffff" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="70" y="114" text-anchor="middle" font-size="10" fill="#1B3139">idx 1 → [w₁₁, w₁₂, w₁₃]</text>
# MAGIC   <rect x="15" y="130" width="110" height="26" rx="3" fill="#ffffff" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="70" y="148" text-anchor="middle" font-size="10" fill="#1B3139">idx 2 → [w₂₁, w₂₂, w₂₃]</text>
# MAGIC   <rect x="15" y="164" width="110" height="26" rx="3" fill="#ffffff" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="70" y="182" text-anchor="middle" font-size="10" fill="#1B3139">idx 3 → [w₃₁, w₃₂, w₃₃]</text>
# MAGIC   <text x="70" y="218" text-anchor="middle" font-size="10" font-style="italic" fill="#618794">Weights learned</text>
# MAGIC   <text x="70" y="234" text-anchor="middle" font-size="10" font-style="italic" fill="#618794">during training</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Arrow 3 -->
# MAGIC <div style="flex: 0 0 auto; font-size: 24px; color: #1B3139;">→</div>
# MAGIC
# MAGIC <!-- Step 4: Dense Vectors Output -->
# MAGIC <div style="flex: 0 0 auto;">
# MAGIC <svg width="180" viewBox="0 0 180 260" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="90" y="16" text-anchor="middle" font-size="11" font-weight="700" fill="#1B3139">Dense Vectors</text>
# MAGIC   <rect x="5" y="24" width="170" height="220" rx="8" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="15" y="44" width="150" height="32" rx="4" fill="#ffffff" stroke="#00A972" stroke-width="1.2"/>
# MAGIC   <text x="90" y="65" text-anchor="middle" font-size="11" font-weight="600" fill="#1B3139">[0.6, 1.2, -0.8]</text>
# MAGIC   <rect x="15" y="86" width="150" height="32" rx="4" fill="#ffffff" stroke="#00A972" stroke-width="1.2"/>
# MAGIC   <text x="90" y="107" text-anchor="middle" font-size="11" font-weight="600" fill="#1B3139">[0.3, -0.5, 0.9]</text>
# MAGIC   <rect x="15" y="128" width="150" height="32" rx="4" fill="#ffffff" stroke="#00A972" stroke-width="1.2"/>
# MAGIC   <text x="90" y="149" text-anchor="middle" font-size="11" font-weight="600" fill="#1B3139">[-0.2, 0.8, 0.4]</text>
# MAGIC   <rect x="15" y="170" width="150" height="32" rx="4" fill="#ffffff" stroke="#00A972" stroke-width="1.2"/>
# MAGIC   <text x="90" y="191" text-anchor="middle" font-size="11" font-weight="600" fill="#1B3139">[-0.9, 0.1, 1.3]</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC <p style="text-align: center; font-size: 12px; color: #618794; margin-top: 4px;">Each category gets a unique index and a learned dense vector (e.g. Paris → 1 → [0.3, -0.5, 0.9])</p>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D4. Embeddings vs. One-Hot Encoding
# MAGIC
# MAGIC The table below compares the two approaches across key properties to help you choose the right encoding for your use case.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Property</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">One-Hot Encoding</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Embeddings</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Representation</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Sparse binary vectors (high-dimensional)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Dense numeric vectors (low-dimensional)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Captures semantics?</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Yes — similar items end up close in vector space</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Scales with cardinality</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Poorly</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Well</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Best for</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Simple models, low-cardinality features</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Neural networks, large vocabularies, recommender systems</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC **Rule of thumb:**
# MAGIC - **One-hot encoding** — fewer than ~50 unique values with classical models (linear, tree, GBM); ~50 is a practical guideline for training cost and interpretability, not a hard limit — Spark handles sparse vectors efficiently
# MAGIC - **Label encoding** — ordinal features with a meaningful natural order
# MAGIC - **Embeddings** — high-cardinality categoricals (IDs, products, locations) or any text and image features

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the key concepts and techniques for encoding categorical features into the numeric representations that ML algorithms require:
# MAGIC
# MAGIC 1. **Why Encoding Matters** — most ML algorithms accept only numerical input; categorical features stored as strings must be transformed before training. The three recurring challenges — high cardinality, missing values, and string types — each have targeted solutions (grouping rare categories, imputation or treating as a separate category, and choosing the right encoding method).
# MAGIC 2. **One-Hot Encoding** — creates one binary column per category; simple and effective for low-cardinality nominal features, but induces sparsity and scales poorly. In Spark ML, this is a two-step pipeline: `StringIndexer` → `OneHotEncoder`.
# MAGIC 3. **Label and Target Encoding** — label encoding maps categories to integers and is appropriate for ordinal features with a natural order; target encoding replaces categories with per-category target means, which is powerful for high cardinality but requires careful handling to avoid leakage and overfitting.
# MAGIC 4. **Embeddings** — dense, low-dimensional vector representations that place similar categories close together in vector space; scale well with cardinality and capture semantic relationships between categories through a learned embedding layer.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>