# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Lecture — Feature Engineering in Unity Catalog
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This lecture covers the following three sections that build on each other:
# MAGIC
# MAGIC - **A. Why a Feature Store?**. The Databricks Feature Store architecture, its key functionalities (featurization and feature tables), and the three downstream workflows it supports: training dataset creation, batch scoring, and online serving
# MAGIC - **B. Feature Engineering in Unity Catalog**. How feature tables are Delta tables with primary keys, the unified permission model, unified lineage, integration with MLflow and Model Serving, and how UC Feature Store replaces the legacy Workspace Feature Store
# MAGIC - **C. Conclusion**. Summary of key takeaways and how the components fit together
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Explain what a feature store is and the four problems it solves (discovery, lineage, train/serve skew, and online serving)
# MAGIC - Distinguish Workspace Feature Store from Feature Engineering in Unity Catalog and identify the recommended path for new work
# MAGIC - Describe how feature tables are regular Delta tables with a primary key, inheriting all UC capabilities automatically
# MAGIC - Explain how feature tables integrate with MLflow and Model Serving for batch and online inference
# MAGIC - Use `FeatureEngineeringClient` to create, read, update, time-travel, and drop a feature table

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Why a Feature Store?

# COMMAND ----------

# MAGIC %md
# MAGIC ### A1. What a Feature Actually Is
# MAGIC
# MAGIC A **feature** is any value used as input to an ML model. For a churn model, features might be:
# MAGIC
# MAGIC - Aggregations of raw data over time windows (e.g., *trailing 7-day purchases*)
# MAGIC - Joined combinations of datasets (e.g., *customer demographics joined to transactions*)
# MAGIC - Complex derived values (e.g., *estimated customer lifetime value*)
# MAGIC
# MAGIC The process of producing these values from raw data is **feature engineering**. Earlier modules of this course covered the mechanics — loading data, imputing, encoding, scaling. This module covers what to do once you have features worth keeping: **store them in a way the rest of your team and your production models can use**.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### A2. What is a Feature Store?
# MAGIC
# MAGIC A **feature store** manages features, or input data to a machine learning model. It lets us **store, retrieve, and share** features — ensuring that the same data used for model training is also used for inference. This reduces duplication of work and promotes collaboration across teams.
# MAGIC
# MAGIC *An example of a recommendation system:*
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 16px 0;">
# MAGIC
# MAGIC <!-- Left table: Raw Data -->
# MAGIC <div style="flex: 1; min-width: 220px;">
# MAGIC <div style="text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 14px;">Raw Data</div>
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 10px 14px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Source</th>
# MAGIC       <th style="padding: 10px 14px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Examples</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">User Data</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">Age, location, signup date</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Product Data</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">Category, price, rating</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Transaction Data</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">Purchases, clicks, timestamps</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Right table: Types of Features -->
# MAGIC <div style="flex: 1; min-width: 220px;">
# MAGIC <div style="text-align: center; font-weight: 700; color: #1B3139; margin-bottom: 8px; font-size: 14px;">Types of Features</div>
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 10px 14px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Type</th>
# MAGIC       <th style="padding: 10px 14px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Example</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Transformations</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">Log price, age buckets</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Aggregations</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">7-day purchase count, avg rating</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Embeddings</strong></td>
# MAGIC       <td style="padding: 10px 14px; border-bottom: 1px solid #E8E8E8;">User vector, product vector</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC <!-- Flow SVG: Raw Data → Feature Engineering → Feature Store → ML Model → Outcome (new style) -->
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 160" role="img" style="font-family: sans-serif;">
# MAGIC   <defs>
# MAGIC     <marker id="dgb-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <!-- Raw Data -->
# MAGIC   <rect x="5" y="45" width="140" height="70" rx="8" fill="#ffffff" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="77" y="74" text-anchor="middle" font-size="15" font-weight="600" fill="#1B3139">Raw Data</text>
# MAGIC   <text x="77" y="93" text-anchor="middle" font-size="12" fill="#618794">Users, Products,</text>
# MAGIC   <text x="77" y="104" text-anchor="middle" font-size="12" fill="#618794">and Transactions</text>
# MAGIC   <path d="M145 77 L172 77" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#dgb-arrow)"/>
# MAGIC   <!-- Feature Engineering -->
# MAGIC   <rect x="172" y="45" width="180" height="70" rx="8" fill="#2272B4" fill-opacity="0.12" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="263" y="74" text-anchor="middle" font-size="15" font-weight="600" fill="#2272B4">Feature Engineering</text>
# MAGIC   <text x="263" y="93" text-anchor="middle" font-size="12" fill="#618794">Transforms, Aggregates,</text>
# MAGIC   <text x="263" y="104" text-anchor="middle" font-size="12" fill="#618794">and Embeddings</text>
# MAGIC   <path d="M352 77 L376 77" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#dgb-arrow)"/>
# MAGIC   <!-- Feature Store -->
# MAGIC   <rect x="376" y="45" width="160" height="75" rx="8" fill="#FF3621" fill-opacity="0.12" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="458" y="74" text-anchor="middle" font-size="15" font-weight="600" fill="#FF3621">Feature Store</text>
# MAGIC   <text x="458" y="93" text-anchor="middle" font-size="12" fill="#618794">Governed and</text>
# MAGIC   <text x="458" y="104" text-anchor="middle" font-size="12" fill="#618794">Discoverable Features</text>
# MAGIC   <path d="M536 77 L563 77" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#dgb-arrow)"/>
# MAGIC   <!-- ML Model -->
# MAGIC   <rect x="563" y="45" width="125" height="70" rx="8" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="625" y="74" text-anchor="middle" font-size="15" font-weight="600" fill="#1B3139">ML Model</text>
# MAGIC   <text x="625" y="93" text-anchor="middle" font-size="12" fill="#618794">Training & Inference</text>
# MAGIC   <path d="M688 77 L725 77" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#dgb-arrow)"/>
# MAGIC   <!-- Outcome -->
# MAGIC   <rect x="725" y="45" width="120" height="70" rx="8" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="785" y="74" text-anchor="middle" font-size="15" font-weight="600" fill="#00A972">Outcome</text>
# MAGIC   <text x="785" y="93" text-anchor="middle" font-size="12" fill="#618794">Recommendations</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A3. Four Problems a Feature Store Solves
# MAGIC
# MAGIC Without a feature store, every team rebuilds the same features independently, leading to divergent definitions and silent production issues. A feature store gives you **one shared source of truth** for features — discoverable, governed, and reusable across batch and online.
# MAGIC
# MAGIC <br>
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1100px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .ds-row { display: flex; gap: 24px; align-items: stretch; flex-wrap: wrap; }
# MAGIC .ds-row > * { flex: 1; min-width: 280px; }
# MAGIC .ds-card { background: #F9F7F4; border-radius: 8px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); padding: 20px; border-top: 8px solid var(--accent, #4299E0); }
# MAGIC .green{--accent:#00A972;} .coral{--accent:#FF5F46;}
# MAGIC .ds-card ul { margin: 8px 0 0; padding-left: 20px; font-size: 13pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-card li { margin-bottom: 12px; }
# MAGIC .ds-card li:last-child { margin-bottom: 0; }
# MAGIC .dd-head { font-size: 18pt; font-weight: 700; margin: 4px 0 12px; color: var(--accent); }
# MAGIC </style>
# MAGIC
# MAGIC <div class="ds-row">
# MAGIC   <div class="ds-card coral">
# MAGIC     <div class="dd-head">Without a Feature Store</div>
# MAGIC     <ul>
# MAGIC       <li><strong style="color:#2272B4;">Discovery:</strong> Multiple teams invent the same feature with different definitions. No one knows what already exists.</li>
# MAGIC       <li><strong style="color:#2272B4;">Lineage:</strong> At audit time, no one can answer <em>"how was this feature computed, and from what data?"</em></li>
# MAGIC       <li><strong style="color:#2272B4;">Skew:</strong> Training and serving features are computed by different pipelines — small differences cause silent model degradation in production.</li>
# MAGIC       <li><strong style="color:#2272B4;">Online Serving:</strong> Features computed in pandas/Spark during training cannot be served at low latency in production.</li>
# MAGIC     </ul>
# MAGIC   </div>
# MAGIC   <div class="ds-card green">
# MAGIC     <div class="dd-head">With a Feature Store</div>
# MAGIC     <ul>
# MAGIC       <li><strong style="color:#2272B4;">Discovery:</strong> A searchable catalog lets teams find and reuse existing features instead of rebuilding them.</li>
# MAGIC       <li><strong style="color:#2272B4;">Lineage:</strong> Automatically tracks data sources, notebooks, jobs, and models associated with each feature — essential for audits.</li>
# MAGIC       <li><strong style="color:#2272B4;">Skew:</strong> Single source of truth — the same feature logic serves both training and inference, eliminating divergence by design.</li>
# MAGIC       <li><strong style="color:#2272B4;">Online Serving:</strong> Publishes feature tables to a low-latency online store for real-time lookup, without rewriting logic.</li>
# MAGIC     </ul>
# MAGIC   </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC <br>
# MAGIC
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #1B5162; background: #F8F9FC; padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#1B5162; margin-bottom:6px; font-size:15pt;">Note</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     Databricks uses two names for its feature store: <strong>Databricks Feature Store</strong> (main documentation) and <strong>Feature Engineering in Unity Catalog</strong> (API/SDK documentation). The legacy <strong>Workspace Feature Store</strong> is deprecated and accessed via <code>FeatureStoreClient</code> from <code>databricks.feature_store</code>. For new work, use the Unity Catalog–backed feature store with <code>FeatureEngineeringClient</code> from <code>databricks.feature_engineering</code>.
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### A4. Databricks Feature Store
# MAGIC
# MAGIC The Databricks Feature Store provides an end-to-end platform for defining, storing, and serving features. It has two core capabilities — **Featurization** and **Feature Tables** — and supports three downstream workflows: training dataset creation, batch scoring, and online serving.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### Key Functionalities
# MAGIC
# MAGIC <div style="display: flex; gap: 32px; flex-wrap: wrap; margin: 24px 0;">
# MAGIC
# MAGIC <!-- Featurization -->
# MAGIC <div style="flex: 1; min-width: 300px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Featurization</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 30%;"><strong style="color: #2272B4;">Languages</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Python, SQL, Scala, R</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Purpose</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Define reusable and shareable feature logic to ensure consistency and efficiency in feature engineering</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Feature Tables -->
# MAGIC <div style="flex: 1; min-width: 300px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Feature Tables</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 30%;"><strong style="color: #2272B4;">Built on</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Delta Lake — ACID transactions, versioning, and performance optimizations</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Organization</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Features organized logically into tables (e.g., Customer Features, Item Features) to simplify management and access</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A4.1 Workflow Overview
# MAGIC
# MAGIC <!-- Architecture SVG -->
# MAGIC <div style="max-width: 900px; margin: 24px auto;">
# MAGIC <svg width="100%" viewBox="0 0 630 275" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Databricks Feature Store Architecture</title>
# MAGIC
# MAGIC   <defs>
# MAGIC     <marker id="a4-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Left: Featurization -->
# MAGIC   <rect x="10" y="68" width="140" height="100" rx="8" fill="#2272B4" fill-opacity="0.12" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="80" y="106" text-anchor="middle" font-size="15" font-weight="600" fill="#0b2026">Featurization</text>
# MAGIC   <text x="80" y="127" text-anchor="middle" font-size="12" fill="#618794">Python · SQL · Scala · R</text>
# MAGIC   <text x="80" y="145" text-anchor="middle" font-size="12" fill="#618794">Reusable feature logic</text>
# MAGIC
# MAGIC   <!-- Arrow: Featurization → Feature Tables -->
# MAGIC   <path d="M150 118 L193 118" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#a4-arrow)"/>
# MAGIC
# MAGIC   <!-- Center: Feature Tables -->
# MAGIC   <rect x="198" y="48" width="180" height="140" rx="12" fill="#FF3621" fill-opacity="0.08" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <text x="288" y="82" text-anchor="middle" font-size="15" font-weight="600" fill="#0b2026">Feature Tables</text>
# MAGIC   <text x="288" y="103" text-anchor="middle" font-size="14" fill="#618794">Delta Lake</text>
# MAGIC   <line x1="228" y1="113" x2="348" y2="113" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="288" y="133" text-anchor="middle" font-size="12" fill="#618794">Customer Features</text>
# MAGIC   <text x="288" y="151" text-anchor="middle" font-size="12" fill="#618794">Item Features</text>
# MAGIC   <text x="288" y="169" text-anchor="middle" font-size="12" fill="#618794">Transaction Features</text>
# MAGIC
# MAGIC   <!-- Arrows: Feature Tables → workflows -->
# MAGIC   <path d="M378 88 L425 41" fill="none" stroke="#1B3139" stroke-width="1.5" marker-end="url(#a4-arrow)"/>
# MAGIC   <path d="M378 118 L425 118" fill="none" stroke="#1B3139" stroke-width="1.5" marker-end="url(#a4-arrow)"/>
# MAGIC   <path d="M378 150 L425 195" fill="none" stroke="#1B3139" stroke-width="1.5" marker-end="url(#a4-arrow)"/>
# MAGIC
# MAGIC   <!-- Training Dataset Creation -->
# MAGIC   <rect x="433" y="12" width="185" height="58" rx="8" fill="#EEEDE9" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="525" y="36" text-anchor="middle" font-size="15" font-weight="600" fill="#0b2026">Training Dataset</text>
# MAGIC   <text x="525" y="56" text-anchor="middle" font-size="12" fill="#618794">Snapshot features → MLflow</text>
# MAGIC
# MAGIC   <!-- Batch Scoring -->
# MAGIC   <rect x="433" y="89" width="185" height="58" rx="8" fill="#EEEDE9" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <text x="525" y="113" text-anchor="middle" font-size="15" font-weight="600" fill="#0b2026">Batch Scoring</text>
# MAGIC   <text x="525" y="133" text-anchor="middle" font-size="12" fill="#618794">Scheduled predictions</text>
# MAGIC
# MAGIC   <!-- Online Serving -->
# MAGIC   <rect x="433" y="166" width="185" height="58" rx="8" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="525" y="190" text-anchor="middle" font-size="15" font-weight="600" fill="#0b2026">Online Serving</text>
# MAGIC   <text x="525" y="210" text-anchor="middle" font-size="12" fill="#618794">Low-latency feature lookup</text>
# MAGIC
# MAGIC   <!-- Bottom: summary bar -->
# MAGIC   <rect x="80" y="240" width="470" height="30" rx="6" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="315" y="259" text-anchor="middle" font-size="12" fill="#0b2026">One platform: define features once → use everywhere (training, batch, real-time)</text>
# MAGIC
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### A4.2 Workflow Details
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Workflow</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Process</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Use Case</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Training Dataset Creation</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Features are snapshot and packaged into datasets, ready for training with tools like MLflow. Supports on-demand feature computation at query time.</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Model development &amp; experimentation</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Batch Scoring</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Features are loaded and utilized for scoring in batch processing scenarios. The same feature definitions used in training are applied at inference time.</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Scheduled predictions, reporting pipelines</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #00A972;">Online Serving</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Publish features for real-time model inference. Feature tables are synced to low-latency stores for dynamic, responsive ML applications.</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Fraud detection, recommendations, loan approval</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Feature Engineering in Unity Catalog

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. A Feature Table Is Just a Delta Table with Rules
# MAGIC
# MAGIC On Databricks, a **feature table** is a regular Delta table in Unity Catalog that satisfies two requirements:
# MAGIC
# MAGIC 1. A **primary key** column (or columns) with a `PRIMARY KEY` constraint
# MAGIC 2. The primary key column(s) must be `NOT NULL`
# MAGIC
# MAGIC That's it. Any Unity Catalog table with a primary key is automatically a feature table you can use for model training and inference. You can also promote an existing Delta table by adding a `PRIMARY KEY` constraint — no registration step.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### Feature Table Structure
# MAGIC
# MAGIC <div style="max-width: 1000px; margin: 32px auto;">
# MAGIC <svg width="100%" viewBox="0 0 980 340" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>Feature Table as a UC Delta Table</title>
# MAGIC
# MAGIC   <defs>
# MAGIC     <linearGradient id="b1-grad" x1="0%" y1="0%" x2="0%" y2="100%">
# MAGIC       <stop offset="0%" style="stop-color:#2272B4;stop-opacity:0.08"/>
# MAGIC       <stop offset="100%" style="stop-color:#2272B4;stop-opacity:0.02"/>
# MAGIC     </linearGradient>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Three-level namespace header -->
# MAGIC   <rect x="30" y="15" width="660" height="36" rx="6" fill="#1B3139"/>
# MAGIC   <text x="350" y="38" text-anchor="middle" font-size="13" font-weight="700" fill="#e3f2fd">catalog.schema.customer_features</text>
# MAGIC   <text x="720" y="38" font-size="13" fill="#FF3621" font-weight="600">← UC three-level namespace</text>
# MAGIC
# MAGIC   <!-- Main table box -->
# MAGIC   <rect x="30" y="55" width="660" height="200" rx="8" fill="url(#b1-grad)" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC
# MAGIC   <!-- Column rows -->
# MAGIC   <rect x="50" y="68" width="620" height="28" rx="4" fill="#FF3621" fill-opacity="0.08" stroke="#FF3621" stroke-width="1"/>
# MAGIC   <text x="65" y="87" font-size="14" font-weight="700" fill="#111111">customerID</text>
# MAGIC   <text x="190" y="87" font-size="12" fill="#FF3621" font-weight="600">PK, NOT NULL</text>
# MAGIC   <text x="720" y="87" font-size="13" fill="#FF3621" font-weight="600">← primary key requirement</text>
# MAGIC
# MAGIC   <rect x="50" y="102" width="620" height="26" rx="4" fill="#ffffff" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="65" y="120" font-size="14" fill="#111111">tenure</text>
# MAGIC   <text x="190" y="120" font-size="12" fill="#222222">INT</text>
# MAGIC
# MAGIC   <rect x="50" y="132" width="620" height="26" rx="4" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="65" y="150" font-size="14" fill="#111111">MonthlyCharges</text>
# MAGIC   <text x="190" y="150" font-size="12" fill="#222222">DOUBLE</text>
# MAGIC
# MAGIC   <rect x="50" y="162" width="620" height="26" rx="4" fill="#ffffff" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="65" y="180" font-size="14" fill="#111111">TotalCharges</text>
# MAGIC   <text x="190" y="180" font-size="12" fill="#222222">DOUBLE</text>
# MAGIC
# MAGIC   <rect x="50" y="192" width="620" height="26" rx="4" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="65" y="210" font-size="14" fill="#111111">tenure_group</text>
# MAGIC   <text x="190" y="210" font-size="12" fill="#222222">STRING</text>
# MAGIC   <text x="720" y="210" font-size="13" fill="#2272B4" font-weight="600">← derived feature</text>
# MAGIC
# MAGIC   <!-- Bottom layers -->
# MAGIC   <rect x="30" y="232" width="660" height="22" rx="0" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1"/>
# MAGIC   <text x="350" y="247" text-anchor="middle" font-size="12" font-weight="600" fill="#006622">Underneath: Delta Lake</text>
# MAGIC
# MAGIC   <!-- Top capabilities bar -->
# MAGIC   <rect x="60" y="270" width="600" height="50" rx="8" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="350" y="290" text-anchor="middle" font-size="14" font-weight="600" fill="#111111">On top: Unity Catalog governance</text>
# MAGIC   <text x="350" y="308" text-anchor="middle" font-size="12" fill="#222222">Security · Lineage · Discovery · ACLs · Time Travel · Tagging · Cross-workspace Access</text>
# MAGIC
# MAGIC </svg>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### B1.1 Feature Tables = UC Tables + Metadata
# MAGIC
# MAGIC Feature tables behave like regular Unity Catalog tables but include additional metadata for feature management. The Feature Store integrates fully with Unity Catalog, meaning any UC table can be used as a feature table.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Feature Store Property</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Unity Catalog Equivalent</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Benefit</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Feature table description</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Table comment (<code>COMMENT ON TABLE</code>)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Discoverable in Catalog Explorer search</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Feature table schema</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Table schema (columns &amp; types)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Schema evolution, enforcement, versioning</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Namespace</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Three-level: <code>catalog.schema.table</code></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Consistent cross-platform access</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Access control</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">UC permissions (<code>GRANT</code> / <code>REVOKE</code>)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Single permission model, cross-workspace</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Lineage &amp; auditing</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">UC lineage graph + audit logs</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Trace which jobs, models, and dashboards use each feature</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1100px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .ds-callout { border-left: 6px solid var(--accent, #1B5162); border-radius: 8px; padding: 18px 24px; background: var(--tint, #F8F9FC); box-shadow: 0 2px 8px rgba(27,49,57,0.06); font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-eyebrow { font-size: 14pt; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: var(--accent, #1B5162); margin-bottom: 6px; }
# MAGIC .ds-callout ul { margin: 0; padding-left: 20px; font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-callout li { margin-bottom: 10px; } .ds-callout li:last-child { margin-bottom: 0; }
# MAGIC .info    { --accent:#1B5162; --tint:#F8F9FC; }
# MAGIC .caution { --accent:#FFAB00; --tint:rgba(255,171,0,0.12); }
# MAGIC .danger  { --accent:#FF5F46; --tint:rgba(255,95,70,0.10); }
# MAGIC .success { --accent:#00A972; --tint:rgba(0,169,114,0.10); }
# MAGIC .ds-callout-title { font-size: 14pt; font-weight: 700; color: #0b2026; margin-bottom: 10px; line-height: 1.3; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="ds-callout caution">
# MAGIC   <div class="ds-eyebrow">Key Takeaway</div>
# MAGIC   <div class="ds-callout-title">Any Unity Catalog table with a primary key is automatically a feature table.</div>
# MAGIC   <ul>
# MAGIC     <li>No registration step required—just add a <code>PRIMARY KEY</code> constraint.</li>
# MAGIC     <li>Existing Delta tables can be promoted to feature tables by adding a primary key.</li>
# MAGIC     <li>Feature tables inherit all UC capabilities: governance, lineage, permissions, and cross-workspace access.</li>
# MAGIC   </ul>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### B2. Unified Permission Model
# MAGIC
# MAGIC **Purpose:** Establish a consistent and secure management system for data access across Databricks Feature Store and Unity Catalog — ensuring that governance policies are uniformly applied.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 24px 0;">
# MAGIC
# MAGIC <!-- Left: Key points -->
# MAGIC <div style="flex: 1; min-width: 320px;">
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Secure features with built-in governance</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 28%;"><strong style="color: #2272B4;">Permission Model</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Feature data and metadata are governed by the Unity Catalog permission model — the same security and governance rules used for other UC tables apply to feature tables</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Centralized Control</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Permissions managed across catalogs, schemas, tables, and views from a central platform — applicable across all workspaces</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Future-Proof</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Any future improvements to data governance in Unity Catalog will automatically extend to feature data</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC #### B2.1 Example of Permission Grants on a Feature Table
# MAGIC
# MAGIC <div style="max-width: 780px; margin: 24px auto;">
# MAGIC <svg width="100%" viewBox="0 0 760 330" role="img" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <title>Unified Permission Model — UC Grants on Feature Tables</title>
# MAGIC
# MAGIC   <!-- Background -->
# MAGIC   <rect x="0" y="0" width="760" height="330" rx="10" fill="#F9F7F4" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC
# MAGIC   <!-- Title bar -->
# MAGIC   <rect x="0" y="0" width="760" height="40" rx="10" fill="#1B3139"/>
# MAGIC   <rect x="0" y="20" width="760" height="20" fill="#1B3139"/>
# MAGIC   <text x="24" y="26" font-size="13" font-weight="700" fill="#111111">Permissions — catalog.ml_features.customer_features</text>
# MAGIC   <text x="580" y="26" font-size="10" fill="#222222">Unity Catalog</text>
# MAGIC
# MAGIC   <!-- Table header row -->
# MAGIC   <rect x="20" y="52" width="720" height="30" rx="4" fill="#ffffff" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <text x="40" y="72" font-size="11" font-weight="700" fill="#111111">Principal</text>
# MAGIC   <text x="220" y="72" font-size="11" font-weight="700" fill="#111111">Type</text>
# MAGIC   <text x="340" y="72" font-size="11" font-weight="700" fill="#111111">Privilege</text>
# MAGIC   <text x="500" y="72" font-size="11" font-weight="700" fill="#111111">Inherited From</text>
# MAGIC   <text x="660" y="72" font-size="11" font-weight="700" fill="#111111">Status</text>
# MAGIC
# MAGIC   <!-- Row 1: data_scientists group -->
# MAGIC   <rect x="20" y="84" width="720" height="28" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="112" x2="740" y2="112" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <circle cx="36" cy="98" r="7" fill="#2272B4" fill-opacity="0.15" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="50" y="102" font-size="10" fill="#111111">data_scientists</text>
# MAGIC   <text x="220" y="102" font-size="10" fill="#222222">Group</text>
# MAGIC   <rect x="340" y="90" width="60" height="18" rx="3" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="0.8"/>
# MAGIC   <text x="352" y="103" font-size="10" font-weight="600" fill="#006622">SELECT</text>
# MAGIC   <text x="500" y="102" font-size="11" fill="#222222">catalog.ml_features</text>
# MAGIC   <circle cx="676" cy="98" r="5" fill="#00A972"/>
# MAGIC   <text x="686" y="102" font-size="10" fill="#006622">Active</text>
# MAGIC
# MAGIC   <!-- Row 2: ml_engineers group -->
# MAGIC   <rect x="20" y="112" width="720" height="28" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="140" x2="740" y2="140" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <circle cx="36" cy="126" r="7" fill="#2272B4" fill-opacity="0.15" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="50" y="130" font-size="10" fill="#111111">ml_engineers</text>
# MAGIC   <text x="220" y="130" font-size="10" fill="#222222">Group</text>
# MAGIC   <rect x="340" y="118" width="60" height="18" rx="3" fill="#FF3621" fill-opacity="0.10" stroke="#FF3621" stroke-width="0.8"/>
# MAGIC   <text x="350" y="131" font-size="10" font-weight="600" fill="#B71C1C">MODIFY</text>
# MAGIC   <text x="500" y="130" font-size="10" fill="#222222">Direct grant</text>
# MAGIC   <circle cx="676" cy="126" r="5" fill="#00A972"/>
# MAGIC   <text x="686" y="130" font-size="10" fill="#006622">Active</text>
# MAGIC
# MAGIC   <!-- Row 3: ml_engineers SELECT -->
# MAGIC   <rect x="20" y="140" width="720" height="28" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="168" x2="740" y2="168" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <circle cx="36" cy="154" r="7" fill="#2272B4" fill-opacity="0.15" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="50" y="158" font-size="10" fill="#111111">ml_engineers</text>
# MAGIC   <text x="220" y="158" font-size="10" fill="#222222">Group</text>
# MAGIC   <rect x="340" y="146" width="60" height="18" rx="3" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="0.8"/>
# MAGIC   <text x="352" y="159" font-size="10" font-weight="600" fill="#006622">SELECT</text>
# MAGIC   <text x="500" y="158" font-size="10" fill="#222222">catalog.ml_features</text>
# MAGIC   <circle cx="676" cy="154" r="5" fill="#00A972"/>
# MAGIC   <text x="686" y="158" font-size="10" fill="#006622">Active</text>
# MAGIC
# MAGIC   <!-- Row 4: pipeline_svc -->
# MAGIC   <rect x="20" y="168" width="720" height="28" fill="#F9F7F4"/>
# MAGIC   <line x1="20" y1="196" x2="740" y2="196" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <circle cx="36" cy="182" r="7" fill="#FF3621" fill-opacity="0.15" stroke="#FF3621" stroke-width="1"/>
# MAGIC   <text x="50" y="186" font-size="10" fill="#111111">pipeline_svc_principal</text>
# MAGIC   <text x="220" y="186" font-size="10" fill="#222222">Service Principal</text>
# MAGIC   <rect x="340" y="174" width="60" height="18" rx="3" fill="#FF3621" fill-opacity="0.10" stroke="#FF3621" stroke-width="0.8"/>
# MAGIC   <text x="350" y="187" font-size="10" font-weight="600" fill="#B71C1C">MODIFY</text>
# MAGIC   <text x="500" y="186" font-size="10" fill="#222222">Direct grant</text>
# MAGIC   <circle cx="676" cy="182" r="5" fill="#00A972"/>
# MAGIC   <text x="686" y="186" font-size="10" fill="#006622">Active</text>
# MAGIC
# MAGIC   <!-- Row 5: analysts -->
# MAGIC   <rect x="20" y="196" width="720" height="28" fill="#ffffff"/>
# MAGIC   <line x1="20" y1="224" x2="740" y2="224" stroke="#E8E8E8" stroke-width="1"/>
# MAGIC   <circle cx="36" cy="210" r="7" fill="#2272B4" fill-opacity="0.15" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="50" y="214" font-size="10" fill="#111111">analysts</text>
# MAGIC   <text x="220" y="214" font-size="10" fill="#222222">Group</text>
# MAGIC   <rect x="340" y="202" width="60" height="18" rx="3" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="0.8"/>
# MAGIC   <text x="352" y="215" font-size="10" font-weight="600" fill="#006622">SELECT</text>
# MAGIC   <text x="500" y="214" font-size="10" fill="#222222">catalog.ml_features</text>
# MAGIC   <circle cx="676" cy="210" r="5" fill="#00A972"/>
# MAGIC   <text x="686" y="214" font-size="10" fill="#006622">Active</text>
# MAGIC
# MAGIC   <!-- Separator -->
# MAGIC   <line x1="20" y1="234" x2="740" y2="234" stroke="#2272B4" stroke-width="0.5" stroke-dasharray="4,3"/>
# MAGIC
# MAGIC   <!-- Bottom annotation -->
# MAGIC   <rect x="40" y="248" width="680" height="66" rx="8" fill="#2272B4" fill-opacity="0.05" stroke="#2272B4" stroke-width="1"/>
# MAGIC   <text x="380" y="270" text-anchor="middle" font-size="12" font-weight="700" fill="#111111">How it works</text>
# MAGIC   <text x="380" y="288" text-anchor="middle" font-size="11" fill="#222222">GRANT SELECT ON TABLE catalog.ml_features.customer_features TO `data_scientists`;</text>
# MAGIC   <text x="380" y="304" text-anchor="middle" font-size="11" fill="#222222">GRANT MODIFY ON TABLE catalog.ml_features.customer_features TO `ml_engineers`;</text>
# MAGIC
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1100px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .ds-callout { border-left: 6px solid var(--accent, #1B5162); border-radius: 8px; padding: 18px 24px; background: var(--tint, #F8F9FC); box-shadow: 0 2px 8px rgba(27,49,57,0.06); font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-eyebrow { font-size: 14pt; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: var(--accent, #1B5162); margin-bottom: 6px; }
# MAGIC .ds-callout ul { margin: 0; padding-left: 20px; font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-callout li { margin-bottom: 10px; } .ds-callout li:last-child { margin-bottom: 0; }
# MAGIC .info    { --accent:#1B5162; --tint:#F8F9FC; }
# MAGIC .caution { --accent:#FFAB00; --tint:rgba(255,171,0,0.12); }
# MAGIC .danger  { --accent:#FF5F46; --tint:rgba(255,95,70,0.10); }
# MAGIC .success { --accent:#00A972; --tint:rgba(0,169,114,0.10); }
# MAGIC .ds-callout-title { font-size: 14pt; font-weight: 700; color: #0b2026; margin-bottom: 10px; line-height: 1.3; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="ds-callout caution">
# MAGIC   <div class="ds-eyebrow">Key Takeaway</div>
# MAGIC   <div class="ds-callout-title">Feature Store permissions are managed with Unity Catalog's unified permission model.</div>
# MAGIC   <ul>
# MAGIC     <li>Access to feature tables is controlled using standard UC <code>GRANT</code> and <code>REVOKE</code> SQL.</li>
# MAGIC     <li>Privileges like <code>SELECT</code> and <code>MODIFY</code> can be assigned to user groups, service principals, or roles at the catalog, schema, or table level.</li>
# MAGIC     <li>Feature data and metadata governance is consistent with all other UC assets—no special rules or exceptions.</li>
# MAGIC   </ul>
# MAGIC </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### B3. Unified Data Lineage
# MAGIC
# MAGIC **Feature Store lineage and Unity Catalog lineage become one.** Lineage information — the data flow and dependencies between tables, views, notebooks, workflows, and dashboards — is combined into a single unified view.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 24px 0;">
# MAGIC
# MAGIC <!-- Key points -->
# MAGIC <div style="flex: 1; min-width: 320px;">
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What unified lineage provides</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 28%;"><strong style="color: #2272B4;">Single View</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Feature tables, their source data, and downstream usage are all tracked in one place within UC</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Full Traceability</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Trace how data flows — from raw inputs through transformations to final feature tables and models</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Dependency Insight</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Understand dependencies between assets to ensure consistency across the workflow</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Asset Coverage</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Tables, views, notebooks, workflows, dashboards, and ML models — all connected in one lineage graph</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC <div class="cw">
# MAGIC <style>
# MAGIC .cw { font-family: sans-serif; max-width: 1100px; margin: 0 auto; color: #0b2026; }
# MAGIC .cw * { box-sizing: border-box; }
# MAGIC .ds-callout { border-left: 6px solid var(--accent, #1B5162); border-radius: 8px; padding: 18px 24px; background: var(--tint, #F8F9FC); box-shadow: 0 2px 8px rgba(27,49,57,0.06); font-size: 14pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-eyebrow { font-size: 14pt; font-weight: 700; letter-spacing: 1.5px; text-transform: uppercase; color: var(--accent, #1B5162); margin-bottom: 6px; }
# MAGIC .ds-callout ul { margin: 0; padding-left: 20px; font-size: 12pt; line-height: 1.55; color: #0b2026; }
# MAGIC .ds-callout li { margin-bottom: 10px; } .ds-callout li:last-child { margin-bottom: 0; }
# MAGIC .info    { --accent:#1B5162; --tint:#F8F9FC; }
# MAGIC .caution { --accent:#FFAB00; --tint:rgba(255,171,0,0.12); }
# MAGIC .danger  { --accent:#FF5F46; --tint:rgba(255,95,70,0.10); }
# MAGIC .success { --accent:#00A972; --tint:rgba(0,169,114,0.10); }
# MAGIC .ds-callout-title { font-size: 14pt; font-weight: 700; color: #0b2026; margin-bottom: 10px; line-height: 1.3; }
# MAGIC </style>
# MAGIC
# MAGIC <div class="ds-callout caution">
# MAGIC   <div class="ds-eyebrow">Key Takeaway</div>
# MAGIC   <div class="ds-callout-title">Feature Store lineage is fully integrated with Unity Catalog lineage.</div>
# MAGIC   <ul>
# MAGIC     <li>Visualize the full data flow: from raw inputs, through transformation notebooks, into feature tables, and out to models, dashboards, and scoring pipelines.</li>
# MAGIC     <li>All lineage is accessible from a single lineage explorer in Unity Catalog.</li>
# MAGIC     <li>Traceability and dependency insight across tables, notebooks, workflows, and ML models.</li>
# MAGIC   </ul>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC #### B3.1 Lineage Graph: From Raw Data to Model Inference
# MAGIC
# MAGIC The unified lineage view traces data flow across four stages — from raw sources through transformation notebooks into feature tables and finally to downstream consumers.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <div style="max-width: 860px; margin: 24px auto;">
# MAGIC
# MAGIC <!-- Full flow diagram with separate grouped SVGs connected by arrows -->
# MAGIC <div style="display: flex; align-items: center; gap: 0; flex-wrap: nowrap; overflow-x: auto; padding: 16px 0;">
# MAGIC
# MAGIC <!-- ======== STAGE 1: RAW SOURCES ======== -->
# MAGIC <div style="flex: 0 0 155px;">
# MAGIC <svg width="155" height="260" viewBox="0 0 155 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="77" y="16" text-anchor="middle" font-size="9" font-weight="700" fill="#2272B4">RAW SOURCES</text>
# MAGIC   <line x1="20" y1="24" x2="135" y2="24" stroke="#2272B4" stroke-width="1" opacity="0.3"/>
# MAGIC
# MAGIC   <!-- raw_customers -->
# MAGIC   <rect x="10" y="40" width="130" height="52" rx="7" fill="#ffffff" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="40" width="130" height="16" rx="7" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="50" width="130" height="6" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="49" r="4" fill="#2272B4" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="51" text-anchor="middle" font-size="7" font-weight="600" fill="#2272B4">TABLE</text>
# MAGIC   <text x="77" y="72" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">raw_customers</text>
# MAGIC   <text x="77" y="85" text-anchor="middle" font-size="8" fill="#618794">demographics, tenure</text>
# MAGIC
# MAGIC   <!-- raw_transactions -->
# MAGIC   <rect x="10" y="108" width="130" height="52" rx="7" fill="#ffffff" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="108" width="130" height="16" rx="7" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="118" width="130" height="6" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="117" r="4" fill="#2272B4" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="119" text-anchor="middle" font-size="7" font-weight="600" fill="#2272B4">TABLE</text>
# MAGIC   <text x="77" y="140" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">raw_transactions</text>
# MAGIC   <text x="77" y="153" text-anchor="middle" font-size="8" fill="#618794">charges, payments</text>
# MAGIC
# MAGIC   <!-- raw_items -->
# MAGIC   <rect x="10" y="176" width="130" height="52" rx="7" fill="#ffffff" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="176" width="130" height="16" rx="7" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="186" width="130" height="6" fill="#2272B4" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="185" r="4" fill="#2272B4" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="187" text-anchor="middle" font-size="7" font-weight="600" fill="#2272B4">TABLE</text>
# MAGIC   <text x="77" y="208" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">raw_items</text>
# MAGIC   <text x="77" y="221" text-anchor="middle" font-size="8" fill="#618794">product catalog</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== ARROW 1: Sources → Notebooks ======== -->
# MAGIC <div style="flex: 0 0 50px; display: flex; align-items: center; justify-content: center;">
# MAGIC <svg width="50" height="260" viewBox="0 0 50 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <defs>
# MAGIC     <marker id="arr1" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
# MAGIC       <path d="M1 1L9 5L1 9" fill="none" stroke="#2272B4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <!-- Multiple flow lines -->
# MAGIC   <line x1="5" y1="66" x2="42" y2="90" stroke="#2272B4" stroke-width="1.5" marker-end="url(#arr1)"/>
# MAGIC   <line x1="5" y1="134" x2="42" y2="110" stroke="#2272B4" stroke-width="1.5" marker-end="url(#arr1)"/>
# MAGIC   <line x1="5" y1="134" x2="42" y2="180" stroke="#2272B4" stroke-width="1.5" marker-end="url(#arr1)"/>
# MAGIC   <line x1="5" y1="202" x2="42" y2="190" stroke="#2272B4" stroke-width="1.5" marker-end="url(#arr1)"/>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== STAGE 2: NOTEBOOKS ======== -->
# MAGIC <div style="flex: 0 0 155px;">
# MAGIC <svg width="155" height="260" viewBox="0 0 155 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="77" y="16" text-anchor="middle" font-size="9" font-weight="700" fill="#FF3621">NOTEBOOKS</text>
# MAGIC   <line x1="20" y1="24" x2="135" y2="24" stroke="#FF3621" stroke-width="1" opacity="0.3"/>
# MAGIC
# MAGIC   <!-- feature_engineering -->
# MAGIC   <rect x="10" y="56" width="130" height="68" rx="7" fill="#ffffff" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="56" width="130" height="16" rx="7" fill="#FF3621" fill-opacity="0.06"/>
# MAGIC   <rect x="10" y="66" width="130" height="6" fill="#FF3621" fill-opacity="0.06"/>
# MAGIC   <circle cx="24" cy="65" r="4" fill="#FF3621" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="67" text-anchor="middle" font-size="7" font-weight="600" fill="#FF3621">NOTEBOOK</text>
# MAGIC   <text x="77" y="88" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">feature_engineering</text>
# MAGIC   <text x="77" y="103" text-anchor="middle" font-size="8" fill="#618794">compute customer &amp;</text>
# MAGIC   <text x="77" y="115" text-anchor="middle" font-size="8" fill="#618794">transaction features</text>
# MAGIC
# MAGIC   <!-- item_feature_pipe -->
# MAGIC   <rect x="10" y="148" width="130" height="68" rx="7" fill="#ffffff" stroke="#FF3621" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="148" width="130" height="16" rx="7" fill="#FF3621" fill-opacity="0.06"/>
# MAGIC   <rect x="10" y="158" width="130" height="6" fill="#FF3621" fill-opacity="0.06"/>
# MAGIC   <circle cx="24" cy="157" r="4" fill="#FF3621" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="159" text-anchor="middle" font-size="7" font-weight="600" fill="#FF3621">NOTEBOOK</text>
# MAGIC   <text x="77" y="180" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">item_feature_pipe</text>
# MAGIC   <text x="77" y="195" text-anchor="middle" font-size="8" fill="#618794">item enrichment &amp;</text>
# MAGIC   <text x="77" y="207" text-anchor="middle" font-size="8" fill="#618794">catalog features</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== ARROW 2: Notebooks → Feature Tables ======== -->
# MAGIC <div style="flex: 0 0 50px; display: flex; align-items: center; justify-content: center;">
# MAGIC <svg width="50" height="260" viewBox="0 0 50 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <defs>
# MAGIC     <marker id="arr2" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
# MAGIC       <path d="M1 1L9 5L1 9" fill="none" stroke="#FF3621" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="5" y1="80" x2="42" y2="66" stroke="#FF3621" stroke-width="1.5" marker-end="url(#arr2)"/>
# MAGIC   <line x1="5" y1="100" x2="42" y2="134" stroke="#FF3621" stroke-width="1.5" marker-end="url(#arr2)"/>
# MAGIC   <line x1="5" y1="182" x2="42" y2="202" stroke="#FF3621" stroke-width="1.5" marker-end="url(#arr2)"/>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== STAGE 3: FEATURE TABLES ======== -->
# MAGIC <div style="flex: 0 0 155px;">
# MAGIC <svg width="155" height="260" viewBox="0 0 155 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="77" y="16" text-anchor="middle" font-size="9" font-weight="700" fill="#00A972">FEATURE TABLES</text>
# MAGIC   <line x1="20" y1="24" x2="135" y2="24" stroke="#00A972" stroke-width="1" opacity="0.3"/>
# MAGIC
# MAGIC   <!-- customer_features -->
# MAGIC   <rect x="10" y="40" width="130" height="52" rx="7" fill="#ffffff" stroke="#00A972" stroke-width="1.8"/>
# MAGIC   <rect x="10" y="40" width="130" height="16" rx="7" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="50" width="130" height="6" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="49" r="4" fill="#00A972" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="51" text-anchor="middle" font-size="7" font-weight="600" fill="#00A972">FEATURE TABLE</text>
# MAGIC   <text x="77" y="72" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">customer_features</text>
# MAGIC   <text x="77" y="85" text-anchor="middle" font-size="8" fill="#618794">PK: customerID</text>
# MAGIC
# MAGIC   <!-- txn_features -->
# MAGIC   <rect x="10" y="108" width="130" height="52" rx="7" fill="#ffffff" stroke="#00A972" stroke-width="1.8"/>
# MAGIC   <rect x="10" y="108" width="130" height="16" rx="7" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="118" width="130" height="6" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="117" r="4" fill="#00A972" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="119" text-anchor="middle" font-size="7" font-weight="600" fill="#00A972">FEATURE TABLE</text>
# MAGIC   <text x="77" y="140" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">txn_features</text>
# MAGIC   <text x="77" y="153" text-anchor="middle" font-size="8" fill="#618794">PK: txn_id</text>
# MAGIC
# MAGIC   <!-- item_features -->
# MAGIC   <rect x="10" y="176" width="130" height="52" rx="7" fill="#ffffff" stroke="#00A972" stroke-width="1.8"/>
# MAGIC   <rect x="10" y="176" width="130" height="16" rx="7" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <rect x="10" y="186" width="130" height="6" fill="#00A972" fill-opacity="0.08"/>
# MAGIC   <circle cx="24" cy="185" r="4" fill="#00A972" fill-opacity="0.4"/>
# MAGIC   <text x="77" y="187" text-anchor="middle" font-size="7" font-weight="600" fill="#00A972">FEATURE TABLE</text>
# MAGIC   <text x="77" y="208" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">item_features</text>
# MAGIC   <text x="77" y="221" text-anchor="middle" font-size="8" fill="#618794">PK: item_id</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== ARROW 3: Feature Tables → Downstream ======== -->
# MAGIC <div style="flex: 0 0 50px; display: flex; align-items: center; justify-content: center;">
# MAGIC <svg width="50" height="260" viewBox="0 0 50 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <defs>
# MAGIC     <marker id="arr3" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="6" markerHeight="6" orient="auto">
# MAGIC       <path d="M1 1L9 5L1 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC   <line x1="5" y1="66" x2="42" y2="66" stroke="#1B3139" stroke-width="1.5" stroke-dasharray="4,2" marker-end="url(#arr3)"/>
# MAGIC   <line x1="5" y1="134" x2="42" y2="134" stroke="#1B3139" stroke-width="1.5" stroke-dasharray="4,2" marker-end="url(#arr3)"/>
# MAGIC   <line x1="5" y1="202" x2="42" y2="202" stroke="#1B3139" stroke-width="1.5" stroke-dasharray="4,2" marker-end="url(#arr3)"/>
# MAGIC   <!-- cross-connections -->
# MAGIC   <line x1="5" y1="66" x2="42" y2="134" stroke="#1B3139" stroke-width="1" stroke-dasharray="3,3" opacity="0.35" marker-end="url(#arr3)"/>
# MAGIC   <line x1="5" y1="134" x2="42" y2="202" stroke="#1B3139" stroke-width="1" stroke-dasharray="3,3" opacity="0.35" marker-end="url(#arr3)"/>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <!-- ======== STAGE 4: DOWNSTREAM ======== -->
# MAGIC <div style="flex: 0 0 155px;">
# MAGIC <svg width="155" height="260" viewBox="0 0 155 260" style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;">
# MAGIC   <text x="77" y="16" text-anchor="middle" font-size="9" font-weight="700" fill="#1B3139">DOWNSTREAM</text>
# MAGIC   <line x1="20" y1="24" x2="135" y2="24" stroke="#1B3139" stroke-width="1" opacity="0.3"/>
# MAGIC
# MAGIC   <!-- ML Model -->
# MAGIC   <rect x="10" y="40" width="130" height="52" rx="7" fill="#ffffff" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="40" width="130" height="16" rx="7" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <rect x="10" y="50" width="130" height="6" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <circle cx="24" cy="49" r="4" fill="#1B3139" fill-opacity="0.3"/>
# MAGIC   <text x="77" y="51" text-anchor="middle" font-size="7" font-weight="600" fill="#1B3139">MODEL</text>
# MAGIC   <text x="77" y="72" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">churn_predictor</text>
# MAGIC   <text x="77" y="85" text-anchor="middle" font-size="8" fill="#618794">v3 · Production</text>
# MAGIC
# MAGIC   <!-- Dashboard -->
# MAGIC   <rect x="10" y="108" width="130" height="52" rx="7" fill="#ffffff" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="108" width="130" height="16" rx="7" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <rect x="10" y="118" width="130" height="6" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <circle cx="24" cy="117" r="4" fill="#1B3139" fill-opacity="0.3"/>
# MAGIC   <text x="77" y="119" text-anchor="middle" font-size="7" font-weight="600" fill="#1B3139">DASHBOARD</text>
# MAGIC   <text x="77" y="140" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">Feature Monitoring</text>
# MAGIC   <text x="77" y="153" text-anchor="middle" font-size="8" fill="#618794">drift &amp; freshness</text>
# MAGIC
# MAGIC   <!-- Workflow -->
# MAGIC   <rect x="10" y="176" width="130" height="52" rx="7" fill="#ffffff" stroke="#1B3139" stroke-width="1.5"/>
# MAGIC   <rect x="10" y="176" width="130" height="16" rx="7" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <rect x="10" y="186" width="130" height="6" fill="#1B3139" fill-opacity="0.06"/>
# MAGIC   <circle cx="24" cy="185" r="4" fill="#1B3139" fill-opacity="0.3"/>
# MAGIC   <text x="77" y="187" text-anchor="middle" font-size="7" font-weight="600" fill="#1B3139">WORKFLOW</text>
# MAGIC   <text x="77" y="208" text-anchor="middle" font-size="10" font-weight="600" fill="#1B3139">scoring_pipeline</text>
# MAGIC   <text x="77" y="221" text-anchor="middle" font-size="8" fill="#618794">batch inference</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC <!-- Legend -->
# MAGIC <div style="margin-top: 8px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 12px;">
# MAGIC   <tr style="background-color: #ffffff;">
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;"><span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #2272B4; opacity: 0.6; vertical-align: middle;"></span> <strong style="color: #2272B4;">Source Table</strong></td>
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;"><span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #FF3621; opacity: 0.6; vertical-align: middle;"></span> <strong style="color: #FF3621;">Notebook</strong></td>
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;"><span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #00A972; opacity: 0.6; vertical-align: middle;"></span> <strong style="color: #00A972;">Feature Table</strong></td>
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;"><span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: #1B3139; opacity: 0.6; vertical-align: middle;"></span> <strong style="color: #1B3139;">Downstream</strong></td>
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;">——→ <strong>Data flow</strong></td>
# MAGIC     <td style="padding: 8px 12px; text-align: center; border: 1px solid #E8E8E8;">- - -→ <strong>Consumption</strong></td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC </div>
# MAGIC </div>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### B4. Integration with MLflow and Model Serving
# MAGIC
# MAGIC **Purpose:** Make model deployment easier. Feature Store integrates with both MLflow and Model Serving to support seamless model training, packaging, and inference.
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 24px 0;">
# MAGIC
# MAGIC <!-- Integration with MLflow -->
# MAGIC <div style="flex: 1; min-width: 340px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Integration with MLflow</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 30%;"><strong style="color: #2272B4;">Metadata Packaging</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">When features from Feature Store are used for training, the model is packaged with feature metadata — source, transformations, and version of each feature</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Traceability</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">The model retains references to the features it used during training, helping trace and understand each feature's origin and use</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Inference Time</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">At inference time, the model can look up required feature values from the Feature Store at runtime — it only needs the primary key (e.g., <code>user_id</code>)</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Integration with Model Serving -->
# MAGIC <div style="flex: 1; min-width: 340px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th colspan="2" style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #00A972;">Integration with Model Serving</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; width: 30%;"><strong style="color: #2272B4;">Auto-Retrieval</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">When a model is deployed for batch or online inference, it automatically retrieves the needed features from the Feature Store — increasing efficiency and streamlining inference</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #00A972;">Batch Mode</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>High throughput</strong> — features retrieved from the offline store and joined with new data before scoring</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #00A972;">Online Inference</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Low latency</strong> — features retrieved from the online store in real-time for responsive predictions</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC #### How It Works Together
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621; width: 15%; white-space: nowrap;">Phase</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621; width: 55%;">What Happens</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621; width: 30%;">Key Benefit</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">1. Training</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Features from FS are used to train the model; MLflow packages the model with feature metadata (source, transformations, version)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Full reproducibility &amp; traceability</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">2. Deployment</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Model is deployed to Model Serving; it knows which features it needs via the packaged metadata</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Zero manual feature wiring</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">3. Inference</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Model receives only the primary key; Feature Store automatically provides the rest (batch from offline store, real-time from online store)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Simplified client — just send the key</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B5. Workspace FS vs. Unity Catalog FS
# MAGIC
# MAGIC > ⚠️ **Databricks recommends using Feature Engineering in Unity Catalog. Workspace Feature Store will be deprecated in the future.**
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <div style="display: flex; gap: 24px; flex-wrap: wrap; margin: 24px 0;">
# MAGIC
# MAGIC <!-- Workspace FS -->
# MAGIC <div style="flex: 1; min-width: 320px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Workspace FS</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">
# MAGIC         <ul style="margin: 0; padding-left: 18px; line-height: 2;">
# MAGIC           <li>Specific to a <strong>single workspace</strong></li>
# MAGIC           <li>Challenges in sharing feature tables across workspaces</li>
# MAGIC           <li>Controls access using Databricks workspace access controls</li>
# MAGIC           <li>Uses <code>FeatureStoreClient</code> to create feature tables</li>
# MAGIC           <li><strong style="color: #FF3621;">Has been deprecated</strong></li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC <!-- Unity Catalog FS -->
# MAGIC <div style="flex: 1; min-width: 320px;">
# MAGIC <table style="border-collapse: collapse; width: 100%; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 13px;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #00A972;">Unity Catalog FS <span style="background: #00A972; color: #fff; padding: 2px 8px; border-radius: 4px; font-size: 10px; margin-left: 8px;">Recommended</span></th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">
# MAGIC         <ul style="margin: 0; padding-left: 18px; line-height: 2;">
# MAGIC           <li>Any Delta table with a primary key can be a feature table</li>
# MAGIC           <li>Enables <strong>sharing and access across workspaces</strong></li>
# MAGIC           <li>All UC capabilities available: discovery, governance, lineage</li>
# MAGIC           <li>More robust governance and larger-scale feature management</li>
# MAGIC           <li>Uses <code>FeatureEngineeringClient</code> to create feature tables</li>
# MAGIC         </ul>
# MAGIC       </td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>
# MAGIC
# MAGIC </div>
# MAGIC
# MAGIC ---
# MAGIC
# MAGIC <p style="font-size: 12px; color: #618794; margin-top: 8px;">Unity Catalog Feature Store supports Unity Catalog features like discovery, governance, lineage, and access across workspaces. Any future updates to Unity Catalog's governance capabilities will automatically extend to feature data. | <a href="https://docs.databricks.com/aws/en/release-notes/runtime/" target="_blank">Databricks Runtime Release Notes</a></p>

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the foundational concepts and architecture of Feature Engineering in Unity Catalog:
# MAGIC
# MAGIC 1. **Why a Feature Store** — solves discovery, lineage, train/serve skew, and online serving through reusable feature logic and Delta-backed feature tables.
# MAGIC 2. **Feature Tables = UC Tables** — any UC Delta table with a primary key is automatically a feature table, inheriting governance, lineage, permissions, time travel, and cross-workspace access with no extra configuration.
# MAGIC 3. **Unified Governance** — Feature Store uses UC's `GRANT`/`REVOKE` permission model and lineage graph, so all UC security rules and future improvements apply automatically to feature data.
# MAGIC 4. **MLflow and Model Serving Integration** — feature metadata is packaged with the model via MLflow, enabling automatic feature lookup at inference time in both batch (offline store) and online (real-time) modes.
# MAGIC 5. **Workspace FS vs. UC FS** — new work should use `FeatureEngineeringClient` (UC FS), which replaces the legacy Workspace Feature Store with cross-workspace sharing, unified lineage, and robust governance.
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>