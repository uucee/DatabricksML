# Databricks notebook source
# MAGIC %md
# MAGIC
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC   <img
# MAGIC     src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png"
# MAGIC     alt="Databricks Learning"
# MAGIC   >
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC # Lecture — Managing and Exploring Data
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This lecture introduces the four platform building blocks used throughout the course.
# MAGIC
# MAGIC This lecture covers 4 sections that build on each other:
# MAGIC
# MAGIC - **A. The Databricks Data Intelligence Platform**. The unified lakehouse architecture and its impact on ML workflows
# MAGIC - **B. Notebooks for ML Workflows**. How Databricks notebooks enable exploratory data analysis, collaboration, and reproducibility
# MAGIC - **C. Unity Catalog**. The governance model for data, models, and code, including the three-level namespace
# MAGIC - **D. Delta Lake for ML**. Reliable, reproducible storage and time travel for machine learning datasets
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC
# MAGIC - Identify the four platform building blocks for ML workflows on Databricks and explain their roles
# MAGIC - Use Databricks notebooks (including Genie Code) for fast, collaborative exploratory data analysis
# MAGIC - Describe Unity Catalog's governance model and explain its three-level namespace for organizing assets
# MAGIC - Explain Delta Lake's value for ML, including reliable storage and time travel for reproducible datasets
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. The Databricks Data Intelligence Platform for ML

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. The Databricks Data Intelligence Platform
# MAGIC
# MAGIC The **Databricks Data Intelligence Platform** is built on a *lakehouse* served by a **Data Intelligence Engine** that uses generative AI to understand your data, organized around three properties:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Property</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What it means</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Intelligent</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">A Data Intelligence Engine — Genie, Genie Code, AI/BI Genie — that understands your data and lets you work in natural language.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Simple</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">One platform for data engineering, warehousing, AI, BI, and apps — no separate stacks to integrate.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Private</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Unified governance and security (Unity Catalog) over data, AI, and code.</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### A2. Workloads on the Platform
# MAGIC
# MAGIC The platform supports many workload categories on top of a single open storage and governance foundation. The current product navigation on databricks.com lists Data Engineering, Data Warehousing, AI, BI, Database, Application Development, Governance, Sharing, and more.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 400" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Databricks Platform Workloads</title>
# MAGIC   <desc>A four-layer stack: the Data Intelligence Engine on top, five workload cards below it (Data Engineering, Data Warehousing, Artificial Intelligence, Business Intelligence, Database), then Unity Catalog governance, then open storage formats. Downward arrows connect each layer, and the Artificial Intelligence card is highlighted as the focus of this module.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="wl-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <rect x="15" y="15" width="830" height="370" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">Databricks Data Intelligence Platform</text>
# MAGIC
# MAGIC   <!-- Layer 1: Data Intelligence Engine (y=58 h=48) -->
# MAGIC   <rect x="40" y="58" width="780" height="48" rx="10" fill="#E3F2FD" stroke="#1976D2" stroke-width="1.5"/>
# MAGIC   <text x="430" y="78" text-anchor="middle" font-size="14" font-weight="700" fill="#0b2026">Data Intelligence Engine</text>
# MAGIC   <text x="430" y="95" text-anchor="middle" font-size="12" fill="#618794">Genie · Genie Code · AI/BI Genie — natural-language understanding of your data</text>
# MAGIC
# MAGIC   <path d="M430 106 L430 128" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#wl-arrow)"/>
# MAGIC
# MAGIC   <!-- Layer 2: workload subgroup (y=132 h=126) -->
# MAGIC   <rect x="40" y="132" width="780" height="126" rx="12" fill="#4299E0" fill-opacity="0.08"/>
# MAGIC   <rect x="40" y="132" width="780" height="126" rx="12" fill="none" stroke="#4299E0" stroke-width="1.5" stroke-dasharray="6 3"/>
# MAGIC   <text x="455" y="152" text-anchor="end" font-size="14" font-weight="600" fill="#0b2026">Workloads</text>
# MAGIC
# MAGIC   <!-- 5 cards: w=140, x=60/208/356/504/652 (8px gaps), y=166 h=76 -->
# MAGIC   <rect x="60" y="166" width="140" height="76" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="130" y="190" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Data</text>
# MAGIC   <text x="130" y="206" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Engineering</text>
# MAGIC   <text x="130" y="227" text-anchor="middle" font-size="11" fill="#618794">Lakeflow</text>
# MAGIC
# MAGIC   <rect x="208" y="166" width="140" height="76" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="278" y="190" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Data</text>
# MAGIC   <text x="278" y="206" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Warehousing</text>
# MAGIC   <text x="278" y="227" text-anchor="middle" font-size="11" fill="#618794">Databricks SQL</text>
# MAGIC
# MAGIC   <rect x="356" y="166" width="140" height="76" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="426" y="190" text-anchor="middle" font-size="12" font-weight="700" fill="#0b2026">Artificial</text>
# MAGIC   <text x="426" y="206" text-anchor="middle" font-size="12" font-weight="700" fill="#0b2026">Intelligence</text>
# MAGIC   <text x="426" y="227" text-anchor="middle" font-size="11" fill="#618794">Mosaic AI · MLflow</text>
# MAGIC
# MAGIC   <rect x="504" y="166" width="140" height="76" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="574" y="190" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Business</text>
# MAGIC   <text x="574" y="206" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Intelligence</text>
# MAGIC   <text x="574" y="227" text-anchor="middle" font-size="11" fill="#618794">AI/BI · Dashboards</text>
# MAGIC
# MAGIC   <rect x="652" y="166" width="140" height="76" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="722" y="190" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Database</text>
# MAGIC   <text x="722" y="211" text-anchor="middle" font-size="11" fill="#618794">Lakebase</text>
# MAGIC   <text x="722" y="227" text-anchor="middle" font-size="11" fill="#618794">Postgres</text>
# MAGIC
# MAGIC   <path d="M430 258 L430 280" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#wl-arrow)"/>
# MAGIC
# MAGIC   <!-- Layer 3: Unity Catalog (y=284 h=48) -->
# MAGIC   <rect x="40" y="284" width="780" height="48" rx="10" fill="#FFAB00" fill-opacity="0.16" stroke="#FFAB00" stroke-width="1.5"/>
# MAGIC   <text x="430" y="304" text-anchor="middle" font-size="14" font-weight="700" fill="#0b2026">Unity Catalog</text>
# MAGIC   <text x="430" y="321" text-anchor="middle" font-size="12" fill="#618794">One governance and security model for data, AI, and code</text>
# MAGIC
# MAGIC   <path d="M430 332 L430 344" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#wl-arrow)"/>
# MAGIC
# MAGIC   <!-- Layer 4: Open storage (y=348 h=22 label row) -->
# MAGIC   <rect x="40" y="348" width="780" height="24" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="430" y="360" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Open storage — Delta Lake (default) · Iceberg · Parquet</text>
# MAGIC </svg>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### A3. Platform Workloads and Their Relevance to ML
# MAGIC
# MAGIC Each workload category has a distinct role in an ML project:
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Workload</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What it does</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Most relevant to this module?</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Data Engineering</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Data ingestion, ETL, streaming — Lakeflow Connect, Lakeflow Spark Declarative Pipelines, Lakeflow Jobs, Lakeflow Designer</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Indirectly — your data arrives via Lakeflow</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Data Warehousing</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">SQL analytics — Databricks SQL serverless warehouses</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Sometimes — <code>%sql</code> cells in notebooks</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Artificial Intelligence</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Data prep, training, serving, agents — MLflow, Model Serving, Vector Search, Agent Bricks, Databricks Runtime for ML</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8; color: #00A972; font-weight: 600;">Yes — this is your home</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Business Intelligence</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Dashboards and <strong>AI/BI Genie</strong> (text-to-SQL chat for business users)</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No — distinct from <strong>Genie Code</strong></td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Database</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Lakebase</strong> — serverless Postgres for applications and AI agents; powers low-latency feature lookups via Synced Tables</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Later modules — online feature serving</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A4. Where This Module Fits
# MAGIC
# MAGIC ML on Databricks spans **data → features → training → serving → governance**. This module covers only the leftmost stages: **loading and exploring data**. Later modules build on this foundation.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 170" role="img" style="font-family: sans-serif;">
# MAGIC   <title>ML Workflow Stages on Databricks</title>
# MAGIC   <desc>A four-stage ML pipeline: Load and Explore (this module), Feature Engineer (Module 2), Train and Evaluate (Module 3), and Serve and Monitor (other courses). The first stage is highlighted.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="b3-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Outer container -->
# MAGIC   <rect x="15" y="15" width="830" height="140" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">ML Workflow on Databricks</text>
# MAGIC
# MAGIC   <!-- Stage 1: Load &amp; Explore — highlighted x=30 w=178 -->
# MAGIC   <rect x="30" y="55" width="178" height="70" rx="10" fill="#4299E0" fill-opacity="0.18" stroke="#2272B4" stroke-width="2"/>
# MAGIC   <text x="119" y="82" text-anchor="middle" font-size="13" font-weight="700" fill="#0b2026">Load &amp; Explore</text>
# MAGIC   <text x="119" y="100" text-anchor="middle" font-size="11" font-weight="600" fill="#2272B4">← this module</text>
# MAGIC
# MAGIC   <!-- Arrow 1→2 -->
# MAGIC   <path d="M208 90 L228 90" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#b3-arrow)"/>
# MAGIC
# MAGIC   <!-- Stage 2: Feature Engineer x=233 w=178 -->
# MAGIC   <rect x="233" y="55" width="178" height="70" rx="10" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="322" y="82" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Feature Engineering</text>
# MAGIC   <text x="322" y="100" text-anchor="middle" font-size="11" fill="#618794">Module 2</text>
# MAGIC
# MAGIC   <!-- Arrow 2→3 -->
# MAGIC   <path d="M411 90 L431 90" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#b3-arrow)"/>
# MAGIC
# MAGIC   <!-- Stage 3: Train &amp; Evaluate x=436 w=178 -->
# MAGIC   <rect x="436" y="55" width="178" height="70" rx="10" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="525" y="82" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Train &amp; Evaluate</text>
# MAGIC   <text x="525" y="100" text-anchor="middle" font-size="11" fill="#618794">Module 3</text>
# MAGIC
# MAGIC   <!-- Arrow 3→4 -->
# MAGIC   <path d="M614 90 L634 90" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#b3-arrow)"/>
# MAGIC
# MAGIC   <!-- Stage 4: Serve &amp; Monitor x=639 w=178 -->
# MAGIC   <rect x="639" y="55" width="178" height="70" rx="10" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="728" y="82" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Serve &amp; Monitor</text>
# MAGIC   <text x="728" y="100" text-anchor="middle" font-size="11" fill="#618794">Other Learning Paths</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC **Next:** Feature Engineering (Module 2)

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Notebooks for ML Workflows

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Why Databricks Notebooks?
# MAGIC
# MAGIC Notebooks are the primary surface for exploratory ML work on Databricks.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Capability</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">What it means for ML</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Multi-language</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Mix Python, SQL, Scala, and R in one notebook via <code>%python</code>, <code>%sql</code>, <code>%scala</code>, <code>%r</code>. Use SQL for fast aggregations, Python for modeling.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Collaborative</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Real-time co-editing and comments. Useful for paired EDA with a domain expert.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Reproducible</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Automatic version history; <strong>Git Folders</strong> for source control.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Built-in visualizations</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><code>display()</code> exposes a <strong>Visualization</strong> tab and a <strong>Data Profile</strong> tab without writing plotting code.</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">AI-assisted authoring</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Genie Code</strong> generates, explains, and debugs code from natural-language prompts.</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC Useful magic commands you'll see in this module: `%run`, `%pip`, `%sql`, `%md`, `%sh`, `%fs`.

# COMMAND ----------

# MAGIC %md
# MAGIC ### B2. Quick Exploratory Data Analysis
# MAGIC
# MAGIC Two clicks worth of EDA you'll use constantly:
# MAGIC
# MAGIC - **Data Profile** — summarizes each column (count, distinct, nulls, min/max, histograms)
# MAGIC - **Visualization** — interactive charts directly from a DataFrame
# MAGIC
# MAGIC Both are exposed by `display(df)`. The next few cells run the pattern on the telco dataset the demo and lab will use.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B3. Read the CSV file into a Spark DataFrame
# MAGIC
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>dataset_path = "../telco-customer-churn.csv"</code>
# MAGIC </br>
# MAGIC <code>telco_df = spark.read.csv(dataset_path, header="true", inferSchema="true", multiLine="true", escape='"')</code>
# MAGIC <code>print(f"Rows: {telco_df.count():,}   Columns: {len(telco_df.columns)}")</code>
# MAGIC </pre>
# MAGIC </div>
# MAGIC The output from the code is:
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 6px; padding: 14px 18px; margin: 12px 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; color: #0b2026; font-size: 13px;">
# MAGIC Rows: 7,043   Columns: 21
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC ### B4. Display the DataFrame
# MAGIC
# MAGIC Use the **`display()`** function on the DataFrame to view the table. Click the "+" icon above the output to add a visualization.
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 6px; padding: 14px 18px; margin: 12px 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; color: #0b2026; font-size: 13px;">
# MAGIC display(telco_df)
# MAGIC </div>
# MAGIC
# MAGIC <br/>
# MAGIC
# MAGIC <div style="display: flex; align-items: center; margin-bottom: 8px;">
# MAGIC   <span style="font-weight: bold; font-size: 1.1em;">Table</span>
# MAGIC   <span style="margin-left: 8px; font-size: 1.2em;">+</span>
# MAGIC </div>
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Index</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">customerID</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">gender</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">SeniorCitizen</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Partner</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Dependents</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">tenure</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">7590-VHVEG</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Female</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">5575-GNVDE</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Male</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">34</td>
# MAGIC     </tr>
# MAGIC     <tr style="background: #fff;">
# MAGIC       <td style="padding: 8px 12px;">3</td>
# MAGIC       <td style="padding: 8px 12px;">3668-QPYBK</td>
# MAGIC       <td style="padding: 8px 12px;">Male</td>
# MAGIC       <td style="padding: 8px 12px;">0</td>
# MAGIC       <td style="padding: 8px 12px;">Yes</td>
# MAGIC       <td style="padding: 8px 12px;">No</td>
# MAGIC       <td style="padding: 8px 12px;">2</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B5. Multi-Language Notebooks in Practice
# MAGIC
# MAGIC The code below demonstrates how to use SQL to quickly aggregate and summarize the Churn class distribution from the telco dataset. 
# MAGIC
# MAGIC 1. We first register the DataFrame as a temporary view.
# MAGIC
# MAGIC ```python
# MAGIC     telco_df.createOrReplaceTempView("telco_view")
# MAGIC ```
# MAGIC
# MAGIC 2. Then run a SQL query to count the number of customers in each Churn category.
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 8px; padding: 16px; margin: 16px 0;">
# MAGIC <pre style="background: none; border: none; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0b2026; white-space: pre;">
# MAGIC <code>%sql
# MAGIC SELECT Churn, COUNT(*) AS n
# MAGIC FROM telco_view
# MAGIC GROUP BY Churn
# MAGIC ORDER BY n DESC;
# MAGIC </code>
# MAGIC </pre>
# MAGIC </div>
# MAGIC
# MAGIC <br/>
# MAGIC <div style="display: flex; align-items: center; margin-bottom: 8px;">
# MAGIC   <span style="font-weight: bold; font-size: 1.1em;">Table</span>
# MAGIC   <span style="margin-left: 8px; font-size: 1.2em;">+</span>
# MAGIC </div>
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Index</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Churn</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">n</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">No</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">5,174</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">2</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Yes</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">1,869</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B6. Genie Code for ML EDA
# MAGIC
# MAGIC **Genie Code** is the AI authoring assistant available in the notebook side panel. For ML EDA, it can generate visualization and analysis code from natural language — no need to remember matplotlib or seaborn syntax.
# MAGIC
# MAGIC </br>
# MAGIC
# MAGIC <div style="width: 100%; font-family: sans-serif;"><div style="background: #F9F7F4; border-radius: 10px; padding: 24px 28px; box-shadow: 0 2px 8px rgba(27,49,57,0.06); border-top: 6px solid #FF5F46;">  <img src="https://files.training.databricks.com/binder/prod_main/data-preparation-for-machine-learning-en_us-3.0.2/images/20260912T115850Z/Data Preparation for Machine Learning/Includes/images/genie-code.png" style="height: 64px; margin-bottom: 10px;">  <div style="font-size: 14pt; color: #0B2026; line-height: 1.7; margin-bottom: 16px;">
# MAGIC A good Genie Code prompt for EDA includes the following:
# MAGIC <ul>
# MAGIC   <li>The DataFrame to use (e.g., <code>telco_df</code>)</li>
# MAGIC   <li>The target variable (e.g., <code>Churn</code>)</li>
# MAGIC   <li>The analyses to run (class balance, missing values, feature-vs-target comparisons)</li>
# MAGIC   <li>The libraries to use (matplotlib / seaborn)</li>
# MAGIC </ul>
# MAGIC <br><br>
# MAGIC <strong>Example prompt:</strong>
# MAGIC <pre style="background: #fff; border: 1px solid #ddd; border-radius: 6px; padding: 10px 14px; font-size: 12pt; font-family: monospace; color: #0B2026;">
# MAGIC Using the Spark DataFrame `telco_df`, convert it to pandas and perform EDA as follows:
# MAGIC 1. Plot a bar chart showing the count and percentage of each class in the `Churn` column.
# MAGIC 2. Plot a horizontal bar chart showing the percentage of missing values for each column.
# MAGIC 3. Use matplotlib for all visualizations. 
# MAGIC 4. Add clear titles, axis labels, and display value annotations where helpful.
# MAGIC 5. Briefly describe any insights from the plots in comments.
# MAGIC </pre>
# MAGIC </div>
# MAGIC </div></div>
# MAGIC
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Unity Catalog

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C1. The Unity Catalog Architecture
# MAGIC
# MAGIC - Unity Catalog sits between the **compute engine** you use to query data and the **open storage formats** your data is written in.
# MAGIC - Compute engines (Databricks Runtime, Spark, and others) talk to UC over the **Unity REST** and **Iceberg REST** APIs.
# MAGIC - UC governs data and AI assets such as tables, volumes/files, functions, and models across open formats (Delta Lake, Iceberg, Parquet), and also provides discovery and lineage across related assets such as notebooks, jobs, and dashboards.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 470" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Unity Catalog Architecture</title>
# MAGIC   <desc>A four-layer architecture: compute engines at the top connect through REST APIs to Unity Catalog, which provides four capability groups (Security, Collaboration, Quality, Management). Unity Catalog governs five asset types (tables, models, files, functions, views), which resolve to four open storage formats (Delta Lake, Iceberg, Parquet, PostgreSQL).</desc>
# MAGIC   <defs>
# MAGIC     <marker id="uca-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <rect x="15" y="15" width="830" height="440" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">Unity Catalog Architecture</text>
# MAGIC
# MAGIC   <!-- Layer 1: compute engines (y=56 h=52) -->
# MAGIC   <rect x="250" y="56" width="360" height="52" rx="10" fill="#ffffff" stroke="#618794" stroke-width="1.5"/>
# MAGIC   <text x="430" y="78" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Compute Engines</text>
# MAGIC   <text x="430" y="96" text-anchor="middle" font-size="12" fill="#618794">Databricks Runtime · Apache Spark · external engines</text>
# MAGIC
# MAGIC   <path d="M430 108 L430 138" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#uca-arrow)"/>
# MAGIC   <text x="444" y="125" text-anchor="start" font-size="12" fill="#618794">Unity REST · Iceberg REST</text>
# MAGIC
# MAGIC   <!-- Layer 2: Unity Catalog subgroup (y=142 h=150) -->
# MAGIC   <rect x="40" y="142" width="780" height="150" rx="12" fill="#2272B4" fill-opacity="0.10"/>
# MAGIC   <rect x="40" y="142" width="780" height="150" rx="12" fill="none" stroke="#2272B4" stroke-width="1.5" stroke-dasharray="6 3"/>
# MAGIC   <text x="470" y="162" text-anchor="end" font-size="14" font-weight="600" fill="#0b2026">Unity Catalog</text>
# MAGIC
# MAGIC   <!-- 4 capability groups: w=180, x=60/250/440/630 (10px gaps), y=176 h=98 -->
# MAGIC   <rect x="60" y="176" width="180" height="98" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="150" y="198" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Security</text>
# MAGIC   <text x="150" y="224" text-anchor="middle" font-size="12" fill="#618794">Access control</text>
# MAGIC   <text x="150" y="244" text-anchor="middle" font-size="12" fill="#618794">Auditing</text>
# MAGIC   <text x="150" y="264" text-anchor="middle" font-size="12" fill="#618794">Row / column masking</text>
# MAGIC
# MAGIC   <rect x="250" y="176" width="180" height="98" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="340" y="198" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Collaboration</text>
# MAGIC   <text x="340" y="224" text-anchor="middle" font-size="12" fill="#618794">Search and discovery</text>
# MAGIC   <text x="340" y="244" text-anchor="middle" font-size="12" fill="#618794">Delta Sharing</text>
# MAGIC   <text x="340" y="264" text-anchor="middle" font-size="12" fill="#618794">Tags and comments</text>
# MAGIC
# MAGIC   <rect x="440" y="176" width="180" height="98" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="530" y="198" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Quality</text>
# MAGIC   <text x="530" y="224" text-anchor="middle" font-size="12" fill="#618794">Automated lineage</text>
# MAGIC   <text x="530" y="244" text-anchor="middle" font-size="12" fill="#618794">Quality monitoring</text>
# MAGIC   <text x="530" y="264" text-anchor="middle" font-size="12" fill="#618794">Data profiling</text>
# MAGIC
# MAGIC   <rect x="630" y="176" width="180" height="98" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="720" y="198" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Management</text>
# MAGIC   <text x="720" y="224" text-anchor="middle" font-size="12" fill="#618794">Cost controls</text>
# MAGIC   <text x="720" y="244" text-anchor="middle" font-size="12" fill="#618794">Business semantics</text>
# MAGIC   <text x="720" y="264" text-anchor="middle" font-size="12" fill="#618794">Lifecycle policies</text>
# MAGIC
# MAGIC   <path d="M430 292 L430 318" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#uca-arrow)"/>
# MAGIC   <text x="444" y="308" text-anchor="start" font-size="12" fill="#618794">governs</text>
# MAGIC
# MAGIC   <!-- Layer 3: governed assets — 5 chips w=140, x=60/208/356/504/652, y=322 h=40 -->
# MAGIC   <rect x="60" y="322" width="140" height="40" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="130" y="342" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Tables</text>
# MAGIC
# MAGIC   <rect x="208" y="322" width="140" height="40" rx="8" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="278" y="342" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="700" fill="#0b2026">AI Models</text>
# MAGIC
# MAGIC   <rect x="356" y="322" width="140" height="40" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="426" y="342" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Files / Volumes</text>
# MAGIC
# MAGIC   <rect x="504" y="322" width="140" height="40" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="574" y="342" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Functions</text>
# MAGIC
# MAGIC   <rect x="652" y="322" width="140" height="40" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="722" y="342" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Views</text>
# MAGIC
# MAGIC   <path d="M430 362 L430 386" fill="none" stroke="#1B3139" stroke-width="1.8" marker-end="url(#uca-arrow)"/>
# MAGIC
# MAGIC   <!-- Layer 4: open storage (y=390 h=50) -->
# MAGIC   <rect x="40" y="390" width="780" height="50" rx="10" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="430" y="406" text-anchor="middle" font-size="13" font-weight="600" fill="#618794">Open storage formats</text>
# MAGIC   <text x="152" y="426" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Delta Lake</text>
# MAGIC   <text x="337" y="426" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Iceberg</text>
# MAGIC   <text x="522" y="426" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Parquet</text>
# MAGIC   <text x="707" y="426" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">PostgreSQL</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #1B5162; background: #F8F9FC; padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#1B5162; margin-bottom:6px; font-size:15pt;">Note</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     Unity Catalog applies governance, permissions, lineage, and audit once at the catalog layer. Any compute engine accessing data through UC inherits these controls automatically, ensuring consistent security and discoverability across all workloads.
# MAGIC   </div>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C2. What Unity Catalog Governs
# MAGIC
# MAGIC For ML projects, this means training data, feature tables, and models can share a unified governance model in UC, while related assets such as notebooks and dashboards can still appear in lineage and discovery experiences.
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Object type</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Examples</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Tables</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Delta · Iceberg · Parquet (Lakehouse Federation: external warehouses too)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Volumes</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Managed storage for unstructured / non-tabular data</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Models</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Models in Unity Catalog</strong> (replaces "Model Registry")</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Views</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Logical datasets defined in SQL</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Functions</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">SQL UDFs and AI functions</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Lineage-covered assets</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Notebooks, jobs, dashboards, and models that UC can connect through lineage</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">External access objects</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Connections, shares, and other governed integration points</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C3. Why Governance Matters for ML
# MAGIC
# MAGIC ML projects touch many asset types: training data, feature tables, notebooks, models, dashboards, and increasingly AI agents and MCP servers. Without unified governance you end up answering the same questions for each system separately:
# MAGIC
# MAGIC <div style="background: #F9F7F4; color: #0b2026; border-radius: 6px; padding: 14px 18px; margin: 12px 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px;">
# MAGIC   <em>"Where do I find the dataset? Can I trust it? Who's allowed to read it? Who already accessed it? Are we compliant?"</em>
# MAGIC </div>
# MAGIC
# MAGIC **Unity Catalog (UC)** is Databricks' single permission model for data **and** AI. It governs:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Object type</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Examples</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Tables</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Delta · Iceberg · Parquet (Lakehouse Federation: external warehouses too)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Files</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Volumes</strong> for unstructured / non-tabular data</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Models</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong>Models in Unity Catalog</strong> (replaces "Model Registry")</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Notebooks</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Workspace assets</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">Dashboards</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">AI/BI Dashboards</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">AI Agents</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Agent Bricks artifacts</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;">MCP servers</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Governed via <strong>Unity AI Gateway</strong></td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C4. The Three-Level Namespace
# MAGIC
# MAGIC Every object in UC is addressed as `catalog.schema.object`. The hierarchy below shows how assets are organized.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 340" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Unity Catalog Three-Level Namespace</title>
# MAGIC   <desc>A top-down hierarchy showing the Unity Catalog namespace: metastore at the top, containing a catalog (e.g. dbacademy), which contains a schema (e.g. labuser123_telco), which contains five object types: table, view, volume, function, and model.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="uc-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#8B9DAA" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <!-- Outer container -->
# MAGIC   <rect x="15" y="15" width="830" height="310" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">Unity Catalog — Three-Level Namespace</text>
# MAGIC
# MAGIC   <!-- Level 0: Metastore x=330 w=200 y=55 h=40 -->
# MAGIC   <rect x="330" y="55" width="200" height="40" rx="8" fill="#ffffff" stroke="#8B9DAA" stroke-width="1.5"/>
# MAGIC   <text x="430" y="71" text-anchor="middle" font-size="13" font-weight="600" fill="#0b2026">Metastore</text>
# MAGIC   <text x="430" y="87" text-anchor="middle" font-size="11" fill="#618794">one per region / account</text>
# MAGIC
# MAGIC   <!-- Connector: metastore → catalog -->
# MAGIC   <path d="M430 95 L430 118" fill="none" stroke="#8B9DAA" stroke-width="1.5" marker-end="url(#uc-arrow)"/>
# MAGIC
# MAGIC   <!-- Level 1: Catalog x=280 w=300 y=122 h=40 -->
# MAGIC   <rect x="280" y="122" width="300" height="40" rx="8" fill="#2272B4" fill-opacity="0.10" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="430" y="138" text-anchor="middle" font-size="13" font-weight="700" fill="#0b2026">Catalog</text>
# MAGIC   <text x="430" y="154" text-anchor="middle" font-size="11" fill="#618794">e.g. dbacademy</text>
# MAGIC
# MAGIC   <!-- Connector: catalog → schema -->
# MAGIC   <path d="M430 162 L430 185" fill="none" stroke="#8B9DAA" stroke-width="1.5" marker-end="url(#uc-arrow)"/>
# MAGIC
# MAGIC   <!-- Level 2: Schema x=230 w=400 y=189 h=40 -->
# MAGIC   <rect x="230" y="189" width="400" height="40" rx="8" fill="#2272B4" fill-opacity="0.10" stroke="#2272B4" stroke-width="1.5"/>
# MAGIC   <text x="430" y="205" text-anchor="middle" font-size="13" font-weight="700" fill="#0b2026">Schema</text>
# MAGIC   <text x="430" y="221" text-anchor="middle" font-size="11" fill="#618794">e.g. labuser123_telco</text>
# MAGIC
# MAGIC   <!-- Fan-out connectors: schema → 5 object types -->
# MAGIC   <path d="M430 229 L430 240 L115 240 L115 252" fill="none" stroke="#8B9DAA" stroke-width="1.2" marker-end="url(#uc-arrow)"/>
# MAGIC   <path d="M430 229 L430 240 L255 240 L255 252" fill="none" stroke="#8B9DAA" stroke-width="1.2" marker-end="url(#uc-arrow)"/>
# MAGIC   <path d="M430 229 L430 252"                   fill="none" stroke="#8B9DAA" stroke-width="1.2" marker-end="url(#uc-arrow)"/>
# MAGIC   <path d="M430 229 L430 240 L605 240 L605 252" fill="none" stroke="#8B9DAA" stroke-width="1.2" marker-end="url(#uc-arrow)"/>
# MAGIC   <path d="M430 229 L430 240 L745 240 L745 252" fill="none" stroke="#8B9DAA" stroke-width="1.2" marker-end="url(#uc-arrow)"/>
# MAGIC
# MAGIC   <!-- Level 3 object boxes y=255 h=52 w=120 -->
# MAGIC   <!-- table x=55 -->
# MAGIC   <rect x="55" y="255" width="120" height="52" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="115" y="277" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">table</text>
# MAGIC   <text x="115" y="295" text-anchor="middle" font-size="10" fill="#618794">Delta · Iceberg · Parquet</text>
# MAGIC
# MAGIC   <!-- view x=195 -->
# MAGIC   <rect x="195" y="255" width="120" height="52" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="255" y="277" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">view</text>
# MAGIC   <text x="255" y="295" text-anchor="middle" font-size="10" fill="#618794">virtual table</text>
# MAGIC
# MAGIC   <!-- volume x=370 -->
# MAGIC   <rect x="370" y="255" width="120" height="52" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="430" y="277" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">volume</text>
# MAGIC   <text x="430" y="295" text-anchor="middle" font-size="10" fill="#618794">managed file storage</text>
# MAGIC
# MAGIC   <!-- function x=545 -->
# MAGIC   <rect x="545" y="255" width="120" height="52" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="605" y="277" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">function</text>
# MAGIC   <text x="605" y="295" text-anchor="middle" font-size="10" fill="#618794">UDF / SQL function</text>
# MAGIC
# MAGIC   <!-- model x=685 — green tint for ML relevance -->
# MAGIC   <rect x="685" y="255" width="120" height="52" rx="8" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="745" y="277" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">model</text>
# MAGIC   <text x="745" y="295" text-anchor="middle" font-size="10" fill="#618794">registered MLflow model</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC When you call `saveAsTable("telco_missing_bronze")` without qualifying the name, it lands in your **current catalog and schema** — which the classroom setup configured for you. You can run the following code with **`%sql`** magic command to confirm your current context.
# MAGIC
# MAGIC <div style="background: #F8F9FC; border-radius: 6px; padding: 14px 18px; margin: 16px 0;">
# MAGIC <pre style="background: none; border: none; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0b2026; white-space: pre;">
# MAGIC <code>%sql
# MAGIC SELECT current_catalog() AS catalog, current_schema() AS schema;
# MAGIC </code>
# MAGIC </pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C5. Permissions on a Delta Table
# MAGIC
# MAGIC UC permissions use standard SQL `GRANT` / `REVOKE`. Common privileges for ML data:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Privilege</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Use case</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;"><code>SELECT</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Read the table (e.g., for training)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;"><code>MODIFY</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Write / update rows</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #2272B4;"><code>ALL PRIVILEGES</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Full control</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC The example below is illustrative — do not run it against tables you don't own:
# MAGIC
# MAGIC
# MAGIC <div style="background: #F9F7F4; border-radius: 6px; padding: 14px 18px; margin: 16px 0;">
# MAGIC <pre style="background: none; border: none; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0b2026; white-space: pre;">
# MAGIC GRANT SELECT
# MAGIC   ON TABLE &lt;catalog&gt;.&lt;schema&gt;.telco_missing_bronze
# MAGIC   TO `account users`;
# MAGIC </pre>
# MAGIC </div>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Delta Lake

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D1. What Delta Lake Is and the Features You Will Use
# MAGIC
# MAGIC **Delta Lake** is the open-source storage format that is the **default** for tables on Databricks. It is the layer that makes a data lake reliable enough to use as a *system of record* — including for ML training data.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 320" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Delta Lake Architecture</title>
# MAGIC   <desc>A three-layer stack: client tools such as Spark, pandas, SQL, and MLflow read and write through the Delta Lake transaction log layer, which provides ACID transactions, schema enforcement, versioning, and time travel, and which stores data as Parquet files on cloud object storage such as S3, ADLS, or GCS.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="dl-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <rect x="15" y="15" width="830" height="290" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">Delta Lake Architecture</text>
# MAGIC
# MAGIC   <!-- Layer 1: clients (y=58 h=64) — 4 chips w=180, x=50/242/434/626 (12px gaps) -->
# MAGIC
# MAGIC   <rect x="50" y="78" width="180" height="44" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="140" y="100" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Spark SQL / DataFrames</text>
# MAGIC
# MAGIC   <rect x="242" y="78" width="180" height="44" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="332" y="100" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">pandas</text>
# MAGIC
# MAGIC   <rect x="434" y="78" width="180" height="44" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="524" y="100" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">MLflow training runs</text>
# MAGIC   <text x="525" y="60" text-anchor="end" font-size="14" font-weight="600" fill="#0b2026">Queries and model training</text>
# MAGIC
# MAGIC   <rect x="626" y="78" width="180" height="44" rx="8" fill="#ffffff" stroke="#618794" stroke-width="1.2"/>
# MAGIC   <text x="716" y="100" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">External engines</text>
# MAGIC
# MAGIC   <path d="M428 122 L428 148" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#dl-arrow)"/>
# MAGIC   <text x="442" y="138" text-anchor="start" font-size="12" fill="#618794">read / write</text>
# MAGIC
# MAGIC   <!-- Layer 2: Delta Lake subgroup (y=152 h=94) -->
# MAGIC   <rect x="40" y="152" width="780" height="94" rx="12" fill="#2272B4" fill-opacity="0.10"/>
# MAGIC   <rect x="40" y="152" width="780" height="94" rx="12" fill="none" stroke="#2272B4" stroke-width="1.5" stroke-dasharray="6 3"/>
# MAGIC   <text x="525" y="172" text-anchor="end" font-size="14" font-weight="600" fill="#0b2026">Delta Lake — transaction log</text>
# MAGIC
# MAGIC
# MAGIC   <!-- 4 capability chips w=180, x=60/252/444/636 (12px gaps), y=186 h=44 -->
# MAGIC   <rect x="60" y="186" width="180" height="44" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="150" y="208" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">ACID transactions</text>
# MAGIC
# MAGIC   <rect x="252" y="186" width="180" height="44" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="342" y="208" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Schema enforcement</text>
# MAGIC
# MAGIC   <rect x="444" y="186" width="180" height="44" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="534" y="208" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Versioning</text>
# MAGIC
# MAGIC   <rect x="636" y="186" width="180" height="44" rx="8" fill="#ffffff" stroke="#1B5162" stroke-width="1.2"/>
# MAGIC   <text x="726" y="208" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="700" fill="#0b2026">Time travel</text>
# MAGIC
# MAGIC   <path d="M428 246 L428 268" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#dl-arrow)"/>
# MAGIC
# MAGIC   <!-- Layer 3: storage (y=272 h=44) -->
# MAGIC   <rect x="40" y="250" width="0" height="20" fill="none"/>
# MAGIC   <rect x="40" y="268" width="780" height="24" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="430" y="280" text-anchor="middle" dominant-baseline="central" font-size="12" font-weight="600" fill="#0b2026">Parquet files on cloud object storage — S3 · ADLS · GCS</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC The following features are used in this module's demo and lab:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 8px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Feature</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">Where you will see it</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;">ACID transactions</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Safe concurrent writes (atomicity, consistency, isolation, durability)</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;">Default format on <code>saveAsTable</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Writing the bronze table</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;">Schema enforcement + <code>overwriteSchema</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Replacing a table whose schema changed</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;"><code>DESCRIBE HISTORY</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Inspecting versions</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;"><code>versionAsOf</code> / <code>timestampAsOf</code></strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">Time-travel reads</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;"><strong style="color: #0b2026;">Multi-language access</strong></td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">%sql and Python on the same table</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC <details style="margin: 8px 0;">
# MAGIC <summary style="background: linear-gradient(135deg, #1B3139, #2272B4); color: white; padding: 10px 16px; cursor: pointer; font-weight: 600; font-size: 13pt; border-radius: 8px; user-select: none;">
# MAGIC Delta Lake: Advanced Features
# MAGIC </summary>
# MAGIC <div style="border: 2px solid #1B3139; border-top: none; border-radius: 0 0 8px 8px; padding: 12px 16px; background: #F9F7F4; font-size: 13pt; line-height: 1.6; color: #333;">
# MAGIC <ul style="margin: 4px 0 0 16px;">
# MAGIC <li><strong>Liquid Clustering</strong> — replaces static partitioning and ZORDER. Self-tuning and skew-resistant: only rewrites the data that needs reorganization, and clustering keys can be changed at any time without rewriting the full table. Recommended for all new Delta tables (DBR 15.2+). Use <code>CLUSTER BY AUTO</code> to let Databricks pick keys automatically (DBR 15.4+).</li>
# MAGIC <li><strong>Predictive Optimization</strong> — automatically runs OPTIMIZE and VACUUM on Unity Catalog managed tables based on observed query patterns across the platform. No manual maintenance scheduling needed. Requires the Premium plan and UC managed tables.</li>
# MAGIC <li><strong>Change Data Feed</strong> — when enabled, records every row-level insert, update, and delete between table versions. Ideal for incremental ETL (process only changed rows), audit trails, and syncing changes to downstream tables or external systems. Read changes with <code>table_changes()</code> or <code>.option("readChangeFeed", True)</code>.</li>
# MAGIC <li><strong>MERGE</strong> — SQL upsert that matches source rows against the target on a join key, then updates matched rows and inserts new ones. Supports <code>WHEN NOT MATCHED BY SOURCE</code> for soft-deletes, and handles deduplication in ETL pipelines.</li>
# MAGIC </ul>
# MAGIC </div>
# MAGIC </details>
# MAGIC

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D2. Writing a Delta Table
# MAGIC
# MAGIC `saveAsTable(...)` writes Delta by default and registers the table in your current UC catalog and schema. Two write options are worth knowing:
# MAGIC
# MAGIC - `mode("overwrite")` — replaces the table if it exists, making reruns idempotent
# MAGIC - `option("overwriteSchema", "true")` — allows the new write to redefine column types (Delta options accept strings or booleans; the docs use `"true"` as a string)
# MAGIC
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code>full_table_path = "catalog.schema.table_name"</code>
# MAGIC </br>
# MAGIC <code># Write using the explicit path</code>
# MAGIC <code>(</code>
# MAGIC <code>    telco_df.write</code>
# MAGIC <code>        .mode("overwrite")</code>
# MAGIC <code>        .option("overwriteSchema", "true")  # Delta options accept strings or booleans</code>
# MAGIC <code>        .saveAsTable(full_table_path)</code>
# MAGIC <code>)</code>
# MAGIC </br>
# MAGIC <code>print(f"Wrote Delta table: {full_table_path}")</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### D3. Time Travel in Practice
# MAGIC
# MAGIC Every write to a Delta table creates a new **version**. `DESCRIBE HISTORY` lists all versions; reads can specify any prior version by number or timestamp. This is the mechanism that makes training data **reproducible** — if you trained a model on Monday's snapshot and want to retrain on exactly the same input two weeks later, you can.
# MAGIC
# MAGIC <div style="max-width: 900px; margin: 0 auto;">
# MAGIC <svg width="100%" viewBox="0 0 860 300" role="img" style="font-family: sans-serif;">
# MAGIC   <title>Delta Lake Time Travel Timeline</title>
# MAGIC   <desc>A left-to-right version timeline with three versions: v0 the initial write of 21 columns, v1 an overwrite that dropped columns, and v2 a restore back to the v0 schema. Below the timeline, two read patterns are shown — reading by version number with versionAsOf and reading by timestamp with timestampAsOf.</desc>
# MAGIC   <defs>
# MAGIC     <marker id="tt-arrow" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#1B3139" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC     <marker id="tt-arrow-blue" viewBox="0 0 10 10" refX="8" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
# MAGIC       <path d="M2 1L8 5L2 9" fill="none" stroke="#2272B4" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/>
# MAGIC     </marker>
# MAGIC   </defs>
# MAGIC
# MAGIC   <rect x="15" y="15" width="830" height="270" rx="14" fill="#F9F7F4" stroke="#1B3139" stroke-width="1.5" stroke-opacity="0.4"/>
# MAGIC   <text x="34" y="42" text-anchor="start" font-size="14" font-weight="700" fill="#FF5F46">Delta Lake Time Travel</text>
# MAGIC
# MAGIC   <!-- Version timeline: 3 boxes w=230, x=50/300/550 (20px gaps), y=58 h=76 -->
# MAGIC   <rect x="50" y="58" width="230" height="76" rx="10" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="165" y="80" text-anchor="middle" font-size="14" font-weight="700" fill="#0b2026">v0 — Initial write</text>
# MAGIC   <text x="165" y="101" text-anchor="middle" font-size="12" fill="#618794">7,043 rows · 21 columns</text>
# MAGIC   <text x="165" y="119" text-anchor="middle" font-size="12" fill="#618794">the snapshot you trained on</text>
# MAGIC
# MAGIC   <path d="M280 96 L295 96" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#tt-arrow)"/>
# MAGIC
# MAGIC   <rect x="300" y="58" width="230" height="76" rx="10" fill="#FFAB00" fill-opacity="0.20" stroke="#FFAB00" stroke-width="1.5"/>
# MAGIC   <text x="415" y="80" text-anchor="middle" font-size="14" font-weight="700" fill="#0b2026">v1 — Overwrite</text>
# MAGIC   <text x="415" y="101" text-anchor="middle" font-size="12" fill="#618794">columns dropped by mistake</text>
# MAGIC   <text x="415" y="119" text-anchor="middle" font-size="12" fill="#618794">data is not lost, only superseded</text>
# MAGIC
# MAGIC   <path d="M530 96 L545 96" fill="none" stroke="#1B3139" stroke-width="2" marker-end="url(#tt-arrow)"/>
# MAGIC
# MAGIC   <rect x="550" y="58" width="230" height="76" rx="10" fill="#00A972" fill-opacity="0.12" stroke="#00A972" stroke-width="1.5"/>
# MAGIC   <text x="665" y="80" text-anchor="middle" font-size="14" font-weight="700" fill="#0b2026">v2 — Restored</text>
# MAGIC   <text x="665" y="101" text-anchor="middle" font-size="12" fill="#618794">RESTORE TABLE ... TO VERSION 0</text>
# MAGIC   <text x="665" y="119" text-anchor="middle" font-size="12" fill="#618794">back to 21 columns</text>
# MAGIC
# MAGIC   <!-- Time axis -->
# MAGIC   <path d="M50 148 L790 148" fill="none" stroke="#8B9DAA" stroke-width="1.5" marker-end="url(#tt-arrow)"/>
# MAGIC   <text x="40" y="164" text-anchor="start" font-size="12" fill="#618794">table history</text>
# MAGIC   <text x="40" y="174" text-anchor="start" font-size="12" fill="#618794">oldest to newest</text>
# MAGIC
# MAGIC   <!-- Read-back arrows from read patterns up to versions -->
# MAGIC   <path d="M165 218 L165 140" fill="none" stroke="#2272B4" stroke-width="1.8" stroke-dasharray="6 3" marker-end="url(#tt-arrow-blue)"/>
# MAGIC   <path d="M665 218 L400 140" fill="none" stroke="#2272B4" stroke-width="1.8" stroke-dasharray="6 3" marker-end="url(#tt-arrow-blue)"/>
# MAGIC
# MAGIC   <!-- Read patterns: 2 boxes w=360, x=50/470 (60px gap), y=222 h=52 -->
# MAGIC   <rect x="50" y="222" width="360" height="52" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="230" y="240" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Read by version number</text>
# MAGIC   <text x="230" y="260" text-anchor="middle" font-size="11" fill="#1B3139">.option("versionAsOf", 0).table(name)</text>
# MAGIC
# MAGIC   <rect x="470" y="222" width="360" height="52" rx="8" fill="#EEEDE9" stroke="#8B9DAA" stroke-width="1.2"/>
# MAGIC   <text x="650" y="240" text-anchor="middle" font-size="12" font-weight="600" fill="#0b2026">Read by timestamp</text>
# MAGIC   <text x="650" y="260" text-anchor="middle" font-size="11" fill="#1B3139">.option("timestampAsOf", "2026-05-28").table(name)</text>
# MAGIC </svg>
# MAGIC </div>
# MAGIC
# MAGIC <div style="border-left: 4px solid #4299E0; background: rgba(66,153,224,0.10); padding: 14px 18px; border-radius: 4px; margin: 16px 0; font-family: sans-serif;">
# MAGIC   <strong style="display:block; color:#2272B4; margin-bottom:6px; font-size:15pt;">Info</strong>
# MAGIC   <div style="color:#0b2026; font-size:12pt; line-height:1.55;">
# MAGIC     <b>Time travel tip:</b> When you use <code>timestampAsOf</code> to read a Delta table, Databricks returns the version that was current at that exact moment. This is especially useful if you know the date and time of a training run, but not the version number. Use <code>timestampAsOf</code> for reproducibility when tracking ML experiments by timestamp.
# MAGIC   </div>
# MAGIC </div>
# MAGIC
# MAGIC `DESCRIBE HISTORY` returns one row per version. The table below shows a representative sample of the columns:
# MAGIC
# MAGIC <table style="border-collapse: collapse; width: 100%; max-width: 860px; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; font-size: 14px; margin: 16px 0;">
# MAGIC   <thead>
# MAGIC     <tr style="background-color: #1B3139;">
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">version</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">timestamp</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">operation</th>
# MAGIC       <th style="padding: 12px 16px; text-align: left; color: #ffffff; border-bottom: 3px solid #FF3621;">operationParameters</th>
# MAGIC     </tr>
# MAGIC   </thead>
# MAGIC   <tbody>
# MAGIC     <tr style="background-color: #F9F7F4;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">1</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">2026-05-28 14:02:11</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">WRITE</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">{"mode":"Overwrite","partitionBy":"[]"}</td>
# MAGIC     </tr>
# MAGIC     <tr style="background-color: #ffffff;">
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">0</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">2026-05-28 13:58:44</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">WRITE</td>
# MAGIC       <td style="padding: 12px 16px; border-bottom: 1px solid #E8E8E8;">{"mode":"Overwrite","partitionBy":"[]"}</td>
# MAGIC     </tr>
# MAGIC   </tbody>
# MAGIC </table>
# MAGIC
# MAGIC To read a specific version by number or by timestamp:
# MAGIC
# MAGIC <div style="background: #FFF3E0; border-left: 4px solid #F57C00; border-radius: 6px; padding: 16px; margin: 12px 0; overflow-x: auto;">
# MAGIC <pre style="margin: 0; font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace; font-size: 13px; color: #0a0a0a; white-space: pre-wrap;">
# MAGIC <code># Read version 0 — the very first write of the table</code>
# MAGIC <code>telco_v0 = (</code>
# MAGIC <code>    spark.read</code>
# MAGIC <code>        .option("versionAsOf", 0)</code>
# MAGIC <code>        .table("lecture_telco_demo")</code>
# MAGIC <code>)</code>
# MAGIC </br>
# MAGIC <code>print(f"Version 0 rows: {telco_v0.count():,}   Columns: {len(telco_v0.columns)}")</code>
# MAGIC <code># Output: Version 0 rows: 7,043   Columns: 21</code></pre>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Conclusion
# MAGIC
# MAGIC In this lecture, you covered the four platform building blocks that underpin every demo and lab in this module:
# MAGIC
# MAGIC 1. **Databricks Data Intelligence Platform** — a unified lakehouse with a Data Intelligence Engine, open formats, and a single governance layer for all ML assets.
# MAGIC 2. **Databricks Notebooks** — multi-language, collaborative, and AI-assisted via Genie Code; `display()` and `summary()` are your fastest EDA tools.
# MAGIC 3. **Unity Catalog** — a three-level namespace (`catalog.schema.object`) with SQL-based permissions, automated lineage, and governance for tables, volumes, models, and AI agents.
# MAGIC 4. **Delta Lake** — the default table format on Databricks; ACID transactions, schema enforcement, and time travel make training data reliable and reproducible.
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>